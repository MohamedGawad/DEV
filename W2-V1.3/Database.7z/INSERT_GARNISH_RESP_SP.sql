create or replace PROCEDURE INSERT_GARNISH_RESP_SP  (INPUT_VAL IN XMLTYPE) AS    
BEGIN

 DBMS_OUTPUT.PUT_LINE('INSERT_GARNISH_RESP_SP starts');

  /*
<FIRespDetailsInput>
<garnish_Exec_Resp>
<exetr_srvc_task_id> </exetr_srvc_task_id>
<cust_name> </cust_name>
<cust_id> </cust_id>
<cust_id_type> </cust_id_type>
<cust_nat_cd> </cust_nat_cd>
<total_amt></total_amt> <!--[float]-->
<sar_total_amt></sar_total_amt>  <!--[float]-->
<rq_total_amt></rq_total_amt>   <!--[float]-->
<has_acc_flag></has_acc_flag>
<has_depost_flag></has_depost_flag>
<has_safs_flag></has_safs_flag>
<has_jnt_acc_flag></has_jnt_acc_flag>
<has_jnt_depost_flag></has_jnt_depost_flag>
<has_shrs_flag></has_shrs_flag>
<safs_exe_date_time></safs_exe_date_time>
</garnish_Exec_Resp>
</FIRespDetailsInput>

  */



  FOR r IN
      (SELECT ExtractValue(Value(p),'/garnish_Exec_Resp/cust_name/text()') AS  CUST_NAME,
      Extract(Value(p),'/garnish_Exec_Resp/exetr_srvc_task_id/text()').getnumberval() As EXEC_SRVC_TASK_ID,
      Extract(Value(p),'/garnish_Exec_Resp/cust_id/text()') As CUST_ID,
      Extract(Value(p),'/garnish_Exec_Resp/cust_id_type/text()') As CUST_ID_TYPE,
      Extract(Value(p),'/garnish_Exec_Resp/cust_nat_cd/text()') As CUST_NAT_CD,
      
      Extract(Value(p),'/garnish_Exec_Resp/total_amt/text()').getnumberval() As TOTAL_AMT,
      Extract(Value(p),'/garnish_Exec_Resp/sar_total_amt/text()').getnumberval() As SAR_TOTAL_AMT,
      Extract(Value(p),'/garnish_Exec_Resp/rq_total_amt/text()').getnumberval() As RQ_TOTAL_AMT,
      Extract(Value(p),'/garnish_Exec_Resp/has_acc_flag/text()') As HAS_ACC_FLAG,
      Extract(Value(p),'/garnish_Exec_Resp/has_depost_flag/text()') As HAS_DEPOSIT_FLAG,
      Extract(Value(p),'/garnish_Exec_Resp/has_safs_flag/text()') As HAS_SAFS_FLAG,
      Extract(Value(p),'/garnish_Exec_Resp/has_jnt_acc_flag/text()') As HAS_JNT_ACC_FLAG,
      Extract(Value(p),'/garnish_Exec_Resp/has_jnt_depost_flag/text()') As HAS_JNT_DEPOST_FLAG,
      Extract(Value(p),'/garnish_Exec_Resp/has_shrs_flag/text()') As HAS_SHRS_FLAG,
      Extract(Value(p),'/garnish_Exec_Resp/safs_exe_date_time/text()') As SAFS_EXE_DATE_TIME
      
      FROM TABLE(XMLSequence(Extract(INPUT_VAL,'/FIRespDetailsInput/garnish_Exec_Resp'))) p)

 

      LOOP
      DBMS_OUTPUT.PUT_LINE('INSERT_GARNISH_RESP_SP starts >>>>>1');
   begin
    INSERT INTO GARNISH_EXEC_RESP 
    (
      EXETR_SRVC_TASK_ID, 
      CUST_NAME, 
      CUST_ID, 
      CUST_ID_TYPE, 
      CUST_NAT_CD, 
      TOTAL_AMT,
      SAR_TOTAL_AMT,
      RQ_TOTAL_AMT,
      HAS_ACC_FLAG,
      HAS_DEPOST_FLAG,
      HAS_SAFS_FLAG,
      HAS_JNT_ACC_FLAG,
      HAS_JNT_DEPOST_FLAG,
      HAS_SHRS_FLAG,
      SAFS_EXE_DATE_TIME
    )
    VALUES
    (
      r.EXEC_SRVC_TASK_ID,
      r.CUST_NAME,
      r.CUST_ID,
      r.CUST_ID_TYPE,
      r.CUST_NAT_CD,
      r.TOTAL_AMT,
      r.SAR_TOTAL_AMT,
      r.RQ_TOTAL_AMT,
      r.HAS_ACC_FLAG,
      r.HAS_DEPOSIT_FLAG,
      r.HAS_SAFS_FLAG,
      r.HAS_JNT_ACC_FLAG,
      r.HAS_JNT_DEPOST_FLAG,
      r.HAS_SHRS_FLAG,
      to_date(r.SAFS_EXE_DATE_TIME,'YYYY-MM-DD HH24:MI:SS')
    );
DBMS_OUTPUT.PUT_LINE('INSERT_GARNISH_RESP_SP starts >>>>>2');
  end;
  END LOOP;

DBMS_OUTPUT.PUT_LINE('INSERT_GARNISH_RESP_SP Ends');





  EXCEPTION
  WHEN OTHERs THEN
      Raise_application_error(-20322, 'UNKNOWN ERROR>>'|| SQLERRM); 



END INSERT_GARNISH_RESP_SP;