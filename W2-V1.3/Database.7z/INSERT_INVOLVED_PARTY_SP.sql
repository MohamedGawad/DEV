create or replace PROCEDURE INSERT_INVOLVED_PARTY_SP
(
  prty_cd IN VARCHAR2,
  INPUT_VAL IN XMLTYPE ,
  pk_v IN AGCY_SRVC_REQST.AGCY_SRVC_REQST_ID%TYPE
)

AS 

FULL_NAME_VALUE VARCHAR2(400);

BEGIN


-- __________________PERSON___________________________________________________--
if (prty_cd = GLOBAL_CONSTANTS.PERSON_PARTY_CD) then
FOR x IN
  (SELECT  ExtractValue(Value(person_),'/person/first_name/text()') AS FIRST_NAME , 
  ExtractValue(Value(person_),'/person/second_name/text()') AS SECOND_NAME,
  ExtractValue(Value(person_),'/person/last_name/text()') AS LAST_NAME,
  ExtractValue(Value(person_),'/person/person_id_no/text()') AS PERSON_ID_NO,
  ExtractValue(Value(person_),'/person/nat_cd/text()') AS NAT_CD,
  ExtractValue(Value(person_),'/person/person_id_type_cd/text()') AS PERSON_ID_TYPE_CD,
  ExtractValue(Value(person_),'/person/third_name/text()') AS THIRD_NAME
  FROM TABLE(XMLSequence(Extract(INPUT_VAL,'/RPRqstDetailsInput/person'))) person_
  )
 LOOP
  begin
  
  if x.SECOND_NAME is null
  then 
   DBMS_OUTPUT.PUT_LINE( 'null');
   else
  DBMS_OUTPUT.PUT_LINE( x.SECOND_NAME);
  end if;
  
  
  if (x.SECOND_NAME is NULL or x.SECOND_NAME = '')  then 
  FULL_NAME_VALUE := trim(x.FIRST_NAME) || ' ' || trim(x.THIRD_NAME) || ' ' || trim(x.LAST_NAME);
  end if;
  if (x.THIRD_NAME is NULL or x.THIRD_NAME = '')  then
  FULL_NAME_VALUE := trim(x.FIRST_NAME) || ' ' || trim(x.SECOND_NAME) || ' ' || trim(x.LAST_NAME);
   end if;
  if (x.SECOND_NAME is NULL or x.SECOND_NAME = '') AND (x.THIRD_NAME is NULL or x.THIRD_NAME = '')  then
  FULL_NAME_VALUE := trim(x.FIRST_NAME) || ' ' || trim(x.LAST_NAME);
   end if;
  if (x.FIRST_NAME is NOT NULL) AND (x.SECOND_NAME is NOT NULL) AND (x.THIRD_NAME is not NULL) AND (x.LAST_NAME is not NULL)
  then
  FULL_NAME_VALUE := trim(x.FIRST_NAME) || ' ' || trim(x.SECOND_NAME) || ' ' || trim(x.THIRD_NAME) || ' ' || trim(x.LAST_NAME);
  end if;
  INSERT
INTO INVOLVED_PARTY
  (
    AGCY_SRVC_REQST_ID,
    ID_NO,
    ID_TYPE_CD,
    FIRST_NAME,
    SECOND_NAME,
    THIRD_NAME,
    LAST_NAME,
    NAT_CD,
    FULL_NAME
  )
  VALUES
  (
    pk_v,
    x.PERSON_ID_NO,
    x.PERSON_ID_TYPE_CD,
    x.FIRST_NAME,
    x.SECOND_NAME,
    x.THIRD_NAME,
    x.LAST_NAME,
    x.NAT_CD,
    FULL_NAME_VALUE
  );
     end;
  END LOOP;
-- __________________PERSON___________________________________________________--

-- __________________COMPANY__________________________________________________--
elsif (prty_cd = GLOBAL_CONSTANTS.COMPANY_PARTY_CD) then
FOR co IN
  (SELECT  ExtractValue(Value(company_),'/company/company_id_no/text()') AS ID_NO , 
  ExtractValue(Value(company_),'/company/company_id_type_cd/text()') AS ID_TYPE,
  ExtractValue(Value(company_),'/company/company_name/text()') AS CO_NAME
  FROM TABLE(XMLSequence(Extract(INPUT_VAL,'/RPRqstDetailsInput/company'))) company_
  )
 LOOP
  begin
 INSERT
INTO INVOLVED_PARTY
  (
    AGCY_SRVC_REQST_ID,
    ID_NO,
    ID_TYPE_CD,
    FULL_NAME
  )
  VALUES
  (
    pk_v,
    co.ID_NO,
    co.ID_TYPE,
    co.CO_NAME
  );
     end;
  END LOOP;
-- __________________COMPANY__________________________________________________--



-- __________________GOV______________________________________________________--
elsif (prty_cd = GLOBAL_CONSTANTS.GOV_PARTY_CD) then
FOR g IN
  (SELECT  ExtractValue(Value(govt_),'/govt/id_no/text()') AS ID_NO , 
  ExtractValue(Value(govt_),'/govt/govt_id_type_cd/text()') AS ID_TYPE,
  ExtractValue(Value(govt_),'/govt/govt_org_name/text()') AS GOV_NAME
  FROM TABLE(XMLSequence(Extract(INPUT_VAL,'/RPRqstDetailsInput/govt'))) govt_
  )

 LOOP
  begin

INSERT
INTO INVOLVED_PARTY
  (
    AGCY_SRVC_REQST_ID,
    ID_NO,
    ID_TYPE_CD,
    FULL_NAME
  )
  VALUES
  (
    pk_v,
    g.ID_NO,
    g.ID_TYPE,
    g.GOV_NAME
  );     
  end;
  END LOOP;
-- __________________GOV______________________________________________________--


-- __________________CHAMBER__________________________________________________--
elsif (prty_cd = GLOBAL_CONSTANTS.CHAMBER_PARTY_CD) then
FOR chm IN
  (SELECT  ExtractValue(Value(chamber_),'/chamber/id_no/text()') AS ID_NO , 
  ExtractValue(Value(chamber_),'/chamber/id_type/text()') AS ID_TYPE,
  ExtractValue(Value(chamber_),'/chamber/name/text()') AS CHAMB_NAME
  FROM TABLE(XMLSequence(Extract(INPUT_VAL,'/RPRqstDetailsInput/chamber'))) chamber_
  )
 LOOP
  begin

INSERT
INTO INVOLVED_PARTY
  (
    AGCY_SRVC_REQST_ID,
    ID_NO,
    ID_TYPE_CD,
    FULL_NAME
  )
  VALUES
  (
    pk_v,
    chm.ID_NO,
    chm.ID_TYPE,
    chm.CHAMB_NAME
  );
     end;
  END LOOP;
-- __________________CHAMBER__________________________________________________--


-- __________________CHARITY__________________________________________________--
elsif (prty_cd = GLOBAL_CONSTANTS.CHARITY_PARTY_CD) then
FOR chr IN
  (SELECT  ExtractValue(Value(charity_),'/charity/id_no/text()') AS ID_NO , 
  ExtractValue(Value(charity_),'/charity/id_type/text()') AS ID_TYPE,
  ExtractValue(Value(charity_),'/charity/name/text()') AS CHARIT_NAME
  FROM TABLE(XMLSequence(Extract(INPUT_VAL,'/RPRqstDetailsInput/charity'))) charity_
  )
 LOOP
  begin

INSERT
INTO INVOLVED_PARTY
  (
    AGCY_SRVC_REQST_ID,
    ID_NO,
    ID_TYPE_CD,
    FULL_NAME
  )
  VALUES
  (
    pk_v,
    chr.ID_NO,
    chr.ID_TYPE,
    chr.CHARIT_NAME
  );
     end;
  END LOOP;
-- __________________CHARITY__________________________________________________--


end if;



EXCEPTION
  WHEN OTHERs THEN
      Raise_application_error(-20322, 'UNKNOWN ERROR>>'|| SQLERRM); 

END INSERT_INVOLVED_PARTY_SP;