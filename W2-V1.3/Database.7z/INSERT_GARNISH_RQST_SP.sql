create or replace PROCEDURE INSERT_GARNISH_RQST_SP(INPUT_VAL IN XMLTYPE, AGCY_SRVC_RQST_ID_INPUT IN VARCHAR2) AS 
BEGIN

/*
<RPRqstDetailsInput>
<garnish_Exec_Reqst>
	<dcsn_num> </dcsn_num>
	<dcsn_date> </dcsn_date>
	<case_type> </case_type>
	<duration_type> </duration_type>
	<start_date> </start_date>
	<period> </period> <!--decimal-->
	<end_date> </end_date>
	<amt_val> </amt_val> <!--double-->
	<amt_cur> </amt_cur>
	<bai_num> </bai_num>
	<bai_iban> </bai_iban>
	<bai_bic> </bai_bic>
  <acc_flag> </acc_flag>
  <depost_flag> </depost_flag>
  <safs_flag> </safs_flag>
</garnish_Exec_Reqst>
</RPRqstDetailsInput>
*/

DBMS_OUTPUT.PUT_LINE('Garnish SP Starts  0>>>______________________________________>' );

 FOR r IN
      (SELECT ExtractValue(Value(p),'/garnish_Exec_Reqst/dcsn_num/text()') AS DECISION_NUMBER ,
      Extract(Value(p),'/garnish_Exec_Reqst/dcsn_date/text()') As DECISION_DATE,
      Extract(Value(p),'/garnish_Exec_Reqst/case_type/text()') As CASE_TYPE,
      Extract(Value(p),'/garnish_Exec_Reqst/duration_type/text()') As DURATION_TYPE,
      Extract(Value(p),'/garnish_Exec_Reqst/start_date/text()') As START_DATE,
      Extract(Value(p),'/garnish_Exec_Reqst/period/text()').getnumberval() As PERIOD,
      Extract(Value(p),'/garnish_Exec_Reqst/end_date/text()') As END_DATE,
      Extract(Value(p),'/garnish_Exec_Reqst/amt_val/text()').getnumberval() As AMT_VALUE,
      Extract(Value(p),'/garnish_Exec_Reqst/amt_cur/text()') As AMT_CUR,
      Extract(Value(p),'/garnish_Exec_Reqst/bai_num/text()') As BAI_NUMBER,
      Extract(Value(p),'/garnish_Exec_Reqst/bai_iban/text()') As BAI_IBAN,
      Extract(Value(p),'/garnish_Exec_Reqst/bai_bic/text()') As BAI_BIC,
      Extract(Value(p),'/garnish_Exec_Reqst/acc_flag/text()') As ACC_FLAG,
      Extract(Value(p),'/garnish_Exec_Reqst/depost_flag/text()') As DEPOST_FLAG,
      Extract(Value(p),'/garnish_Exec_Reqst/safs_flag/text()') As SAFS_FLAG
      FROM TABLE(XMLSequence(Extract(INPUT_VAL,'/RPRqstDetailsInput/garnish_Exec_Reqst'))) p
      WHERE EXISTSNODE(INPUT_VAL,'/RPRqstDetailsInput/garnish_Exec_Reqst/dcsn_num') =1
      )


      LOOP
   begin
  DBMS_OUTPUT.PUT_LINE('Garnish SP Starts  1>>>______________________________________>' );
    INSERT INTO GARNISH_EXEC_REQST
  (
    AGCY_SRVC_REQST_ID,
    DCSN_NUM,
    DCSN_DATE,
    CASE_TYPE,
    DURATION_TYPE,
    START_DATE,
    PERIOD,
    END_DATE,
    AMT_VAL,
    AMT_CUR,
    BAI_NUM,
    BAI_IBAN,
    BAI_BIC,
    ACC_FLAG,
    DEPOST_FLAG,
    SAFS_FLAG
  )
  VALUES
  (
    AGCY_SRVC_RQST_ID_INPUT,
    r.DECISION_NUMBER,
    to_date(r.DECISION_DATE,'YYYY-MM-DD'),
    r.CASE_TYPE,
    r.DURATION_TYPE,
    to_date(r.START_DATE,'YYYY-MM-DD'),
    r.PERIOD,
    to_date(r.END_DATE,'YYYY-MM-DD'),
    r.AMT_VALUE,
    r.AMT_CUR,
    r.BAI_NUMBER,
    r.BAI_IBAN,
    r.BAI_BIC,
    r.ACC_FLAG,
    r.DEPOST_FLAG,
    r.SAFS_FLAG
  );
  DBMS_OUTPUT.PUT_LINE('Garnish SP Starts  2>>>______________________________________>' );
  end;
  END LOOP;

DBMS_OUTPUT.PUT_LINE('Garnish SP Starts  3>>>______________________________________>' );
EXCEPTION
  WHEN OTHERs THEN
      Raise_application_error(-20322, 'UNKNOWN ERROR>>'|| SQLERRM); 

DBMS_OUTPUT.PUT_LINE('Garnish SP Ens  >>>______________________________________>' );
END INSERT_GARNISH_RQST_SP;