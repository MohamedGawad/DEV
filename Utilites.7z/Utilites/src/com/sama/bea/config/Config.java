package com.sama.bea.config;

import java.util.HashMap;
import java.util.Map;
 
public class Config
{
    private Map attributes = null;
    public Config()
    {
        attributes = new HashMap(10);
    }
    protected void setAttribute(String attributeName, String attributeValue)
    {
        attributes.put(attributeName, attributeValue);
    }
    public Object getAttribute(String attributeName)
    {
        return attributes.get(attributeName);
    }
}
