package com.sama.bea.utilites;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import com.ibm.icu.util.Calendar;
import com.ibm.wbit.comptest.common.tc.utils.Log;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.ServiceManager;
import com.sama.bea.constant.OperationNamesEnum;
import commonj.sdo.DataObject;

import conm.sama.bea.domains.CorrelationReferenceNumberBO;

public class KeysUtil {

	public static String generateMuId() {
		long timeStamp = System.nanoTime();
		int min = 1;
		int max = 1000;
		int randomNum = ThreadLocalRandom.current().nextInt(min, max + 1);
		LogUtilities
				.logUtil("timeStamp+randomNum>>>" + (timeStamp + randomNum));
		return "S" + timeStamp + randomNum;
	}

	// deprecated
	public static String generateCorrelationReferenceNumber(
			CorrelationReferenceNumberBO correlationReferenceNumberBO) {
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		StringBuilder generatedCorrRefNum = new StringBuilder();
		generatedCorrRefNum
				.append(correlationReferenceNumberBO.getPartner() == null ? ""
						: correlationReferenceNumberBO.getPartner());
		generatedCorrRefNum.append(year);
		generatedCorrRefNum.append(month);
		generatedCorrRefNum.append(day);
		generatedCorrRefNum.append(correlationReferenceNumberBO
				.getServiceCode() == null ? "" : correlationReferenceNumberBO
				.getServiceCode());
		generatedCorrRefNum.append(correlationReferenceNumberBO
				.getOperationCode() == null ? "" : correlationReferenceNumberBO
				.getOperationCode());
		generatedCorrRefNum.append(correlationReferenceNumberBO
				.getSequenceKey() == null ? "" : correlationReferenceNumberBO
				.getSequenceKey());
		LogUtilities.logUtil("generatedCorrRefNum>>>"
				+ generatedCorrRefNum.toString());
		return generatedCorrRefNum.toString();
	}

	public static String getCurrentDateTimeFormatted(String format) {
		// LogUtilities.logUtil("Format+++" + format);
//		System.out.println("format........" + format);
		SimpleDateFormat sdfDate = new SimpleDateFormat(format);
		Date now = new Date();
		String strDate = sdfDate.format(now);
		return strDate;
	}

	public static Date getCurrentDateTimeFormattedDate(String format) {
		Date result = null;
		try {
			LogUtilities.logUtil("Format+++" + format);
			SimpleDateFormat sdfDate = new SimpleDateFormat(format);
			Date now = new Date();
			String strDate = sdfDate.format(now);

			result = sdfDate.parse(strDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public static String getMsgDateFormatted(String date, String format) {
		String result = null;
		Date tmpDate = null;
		try {
			String msgDtFormat = "yyyy-MM-dd'T'HH:mm:ss";
			SimpleDateFormat sdfDate = new SimpleDateFormat(msgDtFormat);
			// LogUtilities.logUtil("date++++format"+date+"-------"+format);
			tmpDate = sdfDate.parse(date);
			sdfDate = new SimpleDateFormat(format);
			result = sdfDate.format(tmpDate);
			// LogUtilities.logUtil("result+++++"+result);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	
	public static Date getMsgDateFormattedAsDate() {
	//	Date tmpDate = null;
		Date currDate=new Date();
		
		LogUtilities.logUtil("tmpDate>>>>>>>>>>>" + currDate);
		return currDate;
	}
	
	public static Date getMsgDateFormattedAsDate(String date) {
		Date tmpDate = null;
		try {
			// LogUtilities.logUtil("getMsgDateFormattedAsDate>>>>>>>>>>>");
			// LogUtilities.logUtil("Date>>>>>>>>>>>"+date);
			String msgDtFormat = "yyyy-MM-dd'T'HH:mm:ss";
			SimpleDateFormat sdfDate = new SimpleDateFormat(msgDtFormat);
			tmpDate = sdfDate.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		LogUtilities.logUtil("tmpDate>>>>>>>>>>>" + tmpDate);
		return tmpDate;
	}
	
	
	public static Date getMsgDateFormattedAsDate(String date, String format) {
		Date tmpDate = null;
		try {
			// LogUtilities.logUtil("getMsgDateFormattedAsDate>>>>>>>>>>>");
			// LogUtilities.logUtil("Date>>>>>>>>>>>"+date);
			LogUtilities.logUtil("date+++++++++++++++++++++++" + date,OperationNamesEnum.DENYSERVICE.code);
			LogUtilities.logUtil("format+++++++++++++++++++++++" + format,OperationNamesEnum.DENYSERVICE.code);
			
			SimpleDateFormat sdfDate = new SimpleDateFormat(format);
			
			tmpDate = sdfDate.parse(date);
			
			
			LogUtilities.logUtil("tmpDate+++++++++++++++++++++++" + tmpDate,OperationNamesEnum.DENYSERVICE.code);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			//LogUtilities.logUtil("tmpDate+++++++++++++++++++++++ Exception Catch Clause" + e);
			e.printStackTrace();
		}
		LogUtilities.logUtil("tmpDate>>>>>>>>>>>" + tmpDate);
		return tmpDate;
	}
	
	

	public static String getDateTimeFormattedDate(String date,
			String fromFormat, String toFormat) {
		String result = null;
		Date tmpDate = null;
		try {
			SimpleDateFormat sdfDate = new SimpleDateFormat(fromFormat);
			// LogUtilities.logUtil("date++++format"+date+"-------"+toFormat);
			tmpDate = sdfDate.parse(date);
			sdfDate = new SimpleDateFormat(toFormat);
			result = sdfDate.format(tmpDate);
			// LogUtilities.logUtil("result+++++"+result);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
//			LogUtilities.logUtil(e.getMessage());
		}
		return result;
	}

	
	public static String printIndex(long index) {
		String result = "";
		LogUtilities.logUtil("index.........."+index,"ddd");
		return result;
	}
	
	public static BigDecimal convertDoubleToBigDecimal(double num) {
		BigDecimal result = new  BigDecimal(num);
		LogUtilities.logUtil("num.........."+num,"ddd");
		return result;
	}

	public static void main(String[] args) {
		
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject reply = factory.create("http://BEA-Solution_Library/ProcessLib/Garnish","ReceiveFIGarnishReplyRq");
		
		DataObject rsHdr = factory.create("http://www.sama.bea.sa/common/Header","T_RsHdr");
		rsHdr.setString("PID", "90005");
		rsHdr.setString("Status", "S1000000");
		rsHdr.setString("SRN", "1800100001012");
		rsHdr.setString("CRN", "1800100001012-S2343234324242");
		
		reply.setDataObject("rsHdr", rsHdr);
		
		List attributes = reply.getInstanceProperties();
		
		for(int i=0;i<attributes.size();i++){
			
			System.out.println(((DataObject)attributes.get(i)).toString());
		}
	
		// for (int i = 0; i < 20; i++) {
		// LogUtilities.logUtil("generated>>" + generateMuId());
		// }
		// prepareGeoLoc("01001-004001000000");
		// CorrelationReferenceNumberBO bo = new CorrelationReferenceNumberBO();
		// bo.setPartner("1002");
		// bo.setServiceCode("001");
		// bo.setOperationCode("003");
		// generateCorrelationReferenceNumber(bo);
//		getMsgDateFormatted("2018-02-26T14:34", "dd-MMM-yyyy hh:mm a");
		List<String> list = new ArrayList<>();
		list.add("12");
		//System.out.println(convertListToString(list));
		// getDateTimeFormattedDate("2018-02-26 14:34","yyyy-MM-dd HH:mm","yyyy-MM-dd HH:mm:ss.SSS");
	}

	private static void prepareGeoLoc(String geoLoc) {
		LogUtilities.logUtil("geoLOC>>>01001-004001000000" + geoLoc);
		LogUtilities.logUtil("geoLOC.substring(0,2)>>>"
				+ geoLoc.substring(0, 2));
		LogUtilities.logUtil("geoLOC.substring(2,5)" + geoLoc.substring(2, 5));
		LogUtilities.logUtil("geoLOC.substring(6,9)" + geoLoc.substring(6, 9));
		LogUtilities
				.logUtil("geoLOC.substring(6,12)" + geoLoc.substring(6, 12));
	}

}
