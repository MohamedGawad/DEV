package com.sama.bea.utilites;

import java.io.ByteArrayOutputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.ServiceManager;
import com.sama.bea.constant.OperationNamesEnum;
import commonj.sdo.DataObject;
import commonj.sdo.Property;

import conm.sama.bea.domains.FIAmtBO;

public class LogUtilities {

	static Logger logger = Logger.getLogger("BPELLOGGER");
	static Logger slaLogger = Logger.getLogger("SLALOGGER");
	static Logger banLogger = Logger.getLogger("BANLOGGER");
	static Logger denyLogger = Logger.getLogger("DENYLOGGER");
	static Logger blockLogger = Logger.getLogger("BLOCKLOGGER");
	static Logger garnishLogger = Logger.getLogger("GARNISHLOGGER");
	static Logger liftLogger = Logger.getLogger("LIFTLOGGER");
	static Logger commonLogger = Logger.getLogger("COMMONLOGGER");
	static Logger accInfoLogger = Logger.getLogger("ACCINFOLOGGER");
	static Logger balInfoLogger = Logger.getLogger("BALINFOLOGGER");
	static Logger depoInfoLogger = Logger.getLogger("DEPOINFOLOGGER");
	static Logger safInfoLogger = Logger.getLogger("SAFINFOLOGGER");
	static Logger liabInfoLogger = Logger.getLogger("LIABINFOLOGGER");
	static Logger transferLogger = Logger.getLogger("TRANSFERLOGGER");
	static String logLevel =FileUtilities.readPropertyValue("log.level");

	public static void logObject(String label, DataObject dataObject,
			String... processId) {
		String myXMLString = null;
		// Log in console in and log file
		logger.debug("Log4j appender configuration is successful !!");
		if(dataObject != null){
		try {
			if(logLevel!= null && logLevel.equals("info"))
				myXMLString = "log object disable"; 
			else{
				myXMLString = printDataObjectProperties(dataObject);
			if (processId.length ==0) {
				logger.info(label + "----------------" + myXMLString);
			} else {
				if(processId[0].equals(OperationNamesEnum.BANSERVICE.code)){
					banLogger.info(label + "----------------" + myXMLString);
				}
				else if(processId[0].equals(OperationNamesEnum.DENYSERVICE.code)){
					denyLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.LIFTSERVICE.code)){
					liftLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.BLOCKSERVICE.code)){
					blockLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.GARNISHSERVICE.code)){
					garnishLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.COMMONSHSERVICE.code)){
					commonLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.GETACCOUNTINFO.code)){
					accInfoLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.GETBALSINFO.code)){
					balInfoLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.GETDEPOTSINFO.code)){
					depoInfoLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.GETSAFSINFO.code)){
					safInfoLogger.info(label + "----------------" + myXMLString);
				}else if(processId[0].equals(OperationNamesEnum.GETLIABSINFO.code)){
					liabInfoLogger.info(label + "----------------" + myXMLString);
				}
				else if(processId[0].equals(OperationNamesEnum.TRANSFERSERVICE.code)){
					transferLogger.info(label + "----------------" + myXMLString);
				}
				else{
				slaLogger.info(label + "----------------" + myXMLString);
				}
			}
		}
		

		} catch (Exception e) {
			logger.info("Logging ----------------");
		}
		}
	}

	public static void logUtil(String message, String... processId) {

		try {
			if (processId.length ==0) {
				logger.info("Logging ----------------" + message);
			} else if(processId[0].equals(OperationNamesEnum.BANSERVICE.code)){
					banLogger.info("Logging ----------------" + message);
				}
				else if(processId[0].equals(OperationNamesEnum.DENYSERVICE.code)){
					denyLogger.info("Logging ----------------" + message);
				}
				else if(processId[0].equals(OperationNamesEnum.LIFTSERVICE.code)){
					liftLogger.info("Logging ----------------" + message);
				}
				else if(processId[0].equals(OperationNamesEnum.BLOCKSERVICE.code)){
					blockLogger.info("Logging ----------------" + message);
				}
				else if(processId[0].equals(OperationNamesEnum.GARNISHSERVICE.code)){
					garnishLogger.info("Logging ----------------" + message);
				}else if(processId[0].equals(OperationNamesEnum.COMMONSHSERVICE.code)){
					commonLogger.info("Logging ----------------" + message);
				}else if(processId[0].equals(OperationNamesEnum.GETACCOUNTINFO.code)){
					accInfoLogger.info("Logging ----------------" + message);
				}else if(processId[0].equals(OperationNamesEnum.GETBALSINFO.code)){
					balInfoLogger.info("Logging ----------------" + message);
				}else if(processId[0].equals(OperationNamesEnum.GETDEPOTSINFO.code)){
					depoInfoLogger.info("Logging ----------------" + message);
				}else if(processId[0].equals(OperationNamesEnum.GETSAFSINFO.code)){
					safInfoLogger.info("Logging ----------------" + message);
				}else if(processId[0].equals(OperationNamesEnum.GETLIABSINFO.code)){
					liabInfoLogger.info("Logging ----------------" + message);
				}
				else if(processId[0].equals(OperationNamesEnum.TRANSFERSERVICE.code)){
					transferLogger.info("Logging ----------------" + message);
				}
				else{
				slaLogger.info("Logging ----------------" + message);
				}
		} catch (Exception e) {
//			e.printStackTrace();
		}
	}
	
	public static String logException(com.ibm.bpe.api.BpelException bpelexception){
		String result= "";
		bpelexception.printStackTrace( System.out);
		Throwable rootCause = bpelexception.getRootCause();
		rootCause.printStackTrace( System.out);
		result = bpelexception.getFaultName()+":"+rootCause.getMessage()+"\n"+bpelexception.getMessage();
		return result;
	}

	public static void main(String[] args) {
//		String test = "VALID_00_|90040_%";
//		
//		System.out.println(Utilities.getGarnishAmountType(test));
		// DOMConfigurator is used to configure logger from xml configuration
		// file
		// DOMConfigurator.configure("ApplicationIntegration_log4j.xml");

		// Log in console in and log file
		// logger.debug("Log4j appender configuration is successful !!");
		// checkTime("18:00");
	}
public static void logPOC() {
	
	BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
	DataObject actionData = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FrstFIBlockResponses");
	List responses = new ArrayList();
	List responses2 = new ArrayList();
	List responses3 = new ArrayList();
	DataObject ReceiveFIBlockReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Block","ReceiveFIBlockReplyRq");
	DataObject T_FIBlockCallBackRq = factory.create("http://www.sama.bea.sa/execution/services/FIBlock","T_FIBlockCallBackRq");
	DataObject T_FIBlockSmryInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIBlockSmryInfo");
	DataObject T_RqHdr = factory.create("http://www.sama.bea.sa/common/Header","T_RqHdr");
	T_RqHdr.setString("PID","90050");
	ReceiveFIBlockReplyRq.setDataObject("FIBlockCallBackRq",T_FIBlockCallBackRq);
	ReceiveFIBlockReplyRq.setDataObject("rqHdr",T_RqHdr);
	T_FIBlockCallBackRq.setDataObject("SmryInfo", T_FIBlockSmryInfo);
	
	DataObject ReceiveFIBlockReplyRq2 = factory.create("http://BEA-Solution_Library/ProcessLib/Block","ReceiveFIBlockReplyRq");
	DataObject T_FIBlockCallBackRq2 = factory.create("http://www.sama.bea.sa/execution/services/FIBlock","T_FIBlockCallBackRq");
	DataObject T_FIBlockSmryInfo2 = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIBlockSmryInfo");
	DataObject T_RqHdr2 = factory.create("http://www.sama.bea.sa/common/Header","T_RqHdr");
	T_RqHdr2.setString("PID","90040");
	ReceiveFIBlockReplyRq2.setDataObject("FIBlockCallBackRq",T_FIBlockCallBackRq2);
	ReceiveFIBlockReplyRq2.setDataObject("rqHdr",T_RqHdr2);
	T_FIBlockCallBackRq2.setDataObject("SmryInfo", T_FIBlockSmryInfo2);
	
	
	DataObject ReceiveFIBlockReplyRq3 = factory.create("http://BEA-Solution_Library/ProcessLib/Block","ReceiveFIBlockReplyRq");
	DataObject T_FIBlockCallBackRq3 = factory.create("http://www.sama.bea.sa/execution/services/FIBlock","T_FIBlockCallBackRq");
	DataObject T_FIBlockSmryInfo3 = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIBlockSmryInfo");
	DataObject T_RqHdr3 = factory.create("http://www.sama.bea.sa/common/Header","T_RqHdr");
	T_RqHdr3.setString("PID","90020");
	ReceiveFIBlockReplyRq3.setDataObject("FIBlockCallBackRq",T_FIBlockCallBackRq3);
	ReceiveFIBlockReplyRq3.setDataObject("rqHdr",T_RqHdr3);
	T_FIBlockCallBackRq3.setDataObject("SmryInfo", T_FIBlockSmryInfo3);
	
	
	
	responses.add(ReceiveFIBlockReplyRq);
	responses.add(ReceiveFIBlockReplyRq2);
	responses.add(ReceiveFIBlockReplyRq3);
	actionData.setList("responses", responses);
	
	
	DataObject reply = factory.create("http://BEA-Solution_Library/ProcessLib/Block","ReceiveFIBlockReplyRq");
//	System.out.println("11111111111111111");
	DataObject rsHdr = factory.create("http://www.sama.bea.sa/common/Header","T_RsHdr");
	DataObject attributes = factory.create("http://www.sama.bea.sa/common/BaseLib","T_Attributes");
//	List stringlsts = new ArrayList<>();
//	stringlsts.add("string1");
//	stringlsts.add("string2");
//	stringlsts.add("string3");
//	reply.setList("stringlst", stringlsts);
	List attributesLst = new ArrayList<>();
	DataObject attribute = factory.create("http://www.sama.bea.sa/common/BaseLib","T_Attribute");
	attribute.setString("Name", "key1");
	attribute.setString("Value", "value1");
	attributesLst.add(attribute);
	DataObject attribute2 = factory.create("http://www.sama.bea.sa/common/BaseLib","T_Attribute");
	attribute2.setString("Name", "key2");
	attribute2.setString("Value", "value2");
	attributesLst.add(attribute2);
	attributes.setList("Attribute",attributesLst);
//	System.out.println("11111111111111111");
	rsHdr.setString("PID", "90005");
	rsHdr.setString("Status", "S1000000");
	rsHdr.setString("SRN", "1800100001012");
	rsHdr.setString("CRN", "1800100001012-S2343234324242");
	rsHdr.setDataObject("Info", attributes);
//	System.out.println("22222222222222");
	reply.setDataObject("rsHdr", rsHdr);
	System.out.println("3333333333333333");
	//List attributes = reply.getInstanceProperties();
	System.out.println(printDataObjectProperties(reply));
	
	
	
	// test algorithm locallly
	BigDecimal targetAmt = new BigDecimal(4000);
	BigDecimal blockedTotAmt = new BigDecimal(9000);
	List<FIAmtBO> fiAmtLst = new ArrayList<>();
	FIAmtBO FIAmtBO1 = new FIAmtBO();
	// SAMBA
	FIAmtBO1.setFiCode("90040");
	FIAmtBO1.setAmt(new BigDecimal(3000));
	FIAmtBO1.setTotSarAmt(new BigDecimal(1000));
	FIAmtBO1.setTotRqCurAmt(new BigDecimal(1000));
	FIAmtBO1.setMsgUId("4444444444444444");
	fiAmtLst.add(FIAmtBO1);
	
	FIAmtBO FIAmtBO2 = new FIAmtBO();
	//AlAWAL
	FIAmtBO2.setFiCode("90050");
	FIAmtBO2.setAmt(new BigDecimal(4000));
	FIAmtBO2.setTotSarAmt(new BigDecimal(500));
	FIAmtBO2.setTotRqCurAmt(new BigDecimal(500));
	FIAmtBO2.setMsgUId("555555555555555");
	fiAmtLst.add(FIAmtBO2);
	
	// Riyadh Bank
	FIAmtBO FIAmtBO3 = new FIAmtBO();
	FIAmtBO3.setFiCode("90020");
	FIAmtBO3.setAmt(new BigDecimal(0));
	FIAmtBO3.setTotSarAmt(new BigDecimal(0));
	FIAmtBO3.setTotRqCurAmt(new BigDecimal(0));
	FIAmtBO3.setMsgUId("222222222222222");
	fiAmtLst.add(FIAmtBO3);
	
	List fiCodeSmryLst = new ArrayList<>();
	Collections.sort(fiAmtLst);
//	fiCodeSmryLst = Utilities.prepareTransferActions(targetAmt,fiAmtLst,fiCodeSmryLst,"SAR");
//	fiCodeSmryLst = Utilities.prepareOverrideActions(targetAmt, blockedTotAmt, responses2, fiCodeSmryLst, "010");
//	fiCodeSmryLst = Utilities.prepareOverrideCrossCurencyActions(targetAmt,fiAmtLst,fiCodeSmryLst,responses2,responses3,"010","SAR");
	for(int i=0;i<fiCodeSmryLst.size();i++){
		System.out.println("fiCodeSmryLst.FICODE"+((DataObject)fiCodeSmryLst.get(i)).getString("FICODE"));
		System.out.println("fiCodeSmryLst.ActionAmt"+((DataObject)fiCodeSmryLst.get(i)).getBigDecimal("ActionAmt"));
		System.out.println("fiCodeSmryLst.FICODE"+((DataObject)fiCodeSmryLst.get(i)).getString("Action"));
		System.out.println("fiCodeSmryLst.MsgUID"+((DataObject)fiCodeSmryLst.get(i)).getString("MsgUID"));
	}
}


public static void logPOC2() {
	
	BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
	DataObject reply = factory.create("http://testUtil/TestBO","MainBO");
	List FIGCodes = new ArrayList();
	FIGCodes.add("aaa");
	FIGCodes.add("bbb");
	FIGCodes.add("ccc");
	reply.setList("FIGCode", FIGCodes);
	System.out.println("____________________HERE_____________________________________");
	System.out.println("=============================================================");
	System.out.println(printDataObjectProperties(reply));
	System.out.println("=============================================================");
	System.out.println("--------------------END--------------------------------------");
}



	private static String printDataObjectProperties(DataObject object){
		StringBuilder strB = new StringBuilder();
		List properties = object.getInstanceProperties();
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();
            
            // Create Person root element 
            Element rootElement = doc.createElement(object.getType().getName());
            doc.appendChild(rootElement);
	
		for(int i=0;i<properties.size();i++){
			Property p = (Property) properties.get(i);
			if(p.getType().getProperties() != null && p.getType().getProperties().size()>0 && !p.isMany()){
				
				//l_line
				//DataObject childObject = object.getDataObject(p.getName());
				DataObject childObject = (DataObject)object.getDataObject(p.getName());
				if(childObject!=null){
					doc = buildChildDataObject(childObject,doc,rootElement);
				}
			}
			else if (p.getType().getProperties() != null && p.getType().getProperties().size() > 0 && p.isMany()) {
				List list = object.getList(p.getName());
				
				for(int k=0;k<list.size();k++){
					DataObject childObject = ((DataObject)list.get(k));
					if (childObject != null){
						doc = buildChildDataObject(childObject,doc,rootElement);
					}
				}
			}
			else{
				
				if(object.get(p.getName())!=null && !p.isMany()){
					
					Element element = doc.createElement(p.getName());
		            element.appendChild(doc.createTextNode(object.get(p.getName()).toString()));
		            rootElement.appendChild(element);
				}
				else if (p.isMany()) {
					
					List list = object.getList(p.getName());
					for(int j=0;j<list.size();j++){
						Element element = doc.createElement(p.getName());
						element.appendChild(doc.createTextNode((list.get(j)).toString()));
						//element.appendChild(doc.createTextNode(((Object)list.get(j)).toString()));
						rootElement.appendChild(element);
					}
				}
			}
		}
		 // Transform Document to XML String
	        TransformerFactory tf = TransformerFactory.newInstance();
	        Transformer transformer = tf.newTransformer();
	        StringWriter writer = new StringWriter();
	        transformer.transform(new DOMSource(doc), new StreamResult(writer));
	        strB.append(writer.getBuffer().toString());
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		
		return strB.toString();
	}
	
	private static Document buildChildDataObject(DataObject object,Document doc,Element rootElement){
		Element childElement = null;
		List properties = object.getInstanceProperties();
//		System.out.println("getType>>>>"+object.getType());
//		System.out.println("getInstanceProperties>>>>"+object.getInstanceProperties());
		
		try {
			if (properties != null && properties.size() > 0) {
				 childElement = doc.createElement(object.getType().getName());
				for (int i = 0; i < properties.size(); i++) {
					Property p = (Property) properties.get(i);
					if (p.getType().getProperties() != null && p.getType().getProperties().size() > 0 && !p.isMany()) {
						DataObject childObject = object.getDataObject(p.getName());
						if (childObject != null){
							doc = buildChildDataObject(childObject,doc,childElement);
						}
					}
					else if (p.getType().getProperties() != null && p.getType().getProperties().size() > 0 && p.isMany()) {
						List list = object.getList(p.getName());
						for(int k=0;k<list.size();k++){
							DataObject childObject = ((DataObject)list.get(k));
							if (childObject != null){
								doc = buildChildDataObject(childObject,doc,childElement);
							}
						}
					}
					else {
						if (object.get(p.getName()) != null && !p.isMany()) {
							Element element = doc.createElement(p.getName());
							element.appendChild(doc.createTextNode(object.get(p.getName()).toString()));
							childElement.appendChild(element);
						}else if (p.isMany()) {
							List list = object.getList(p.getName());
							for(int j=0;j<list.size();j++){
								Element element = doc.createElement(p.getName());
								// remove (
								//element.appendChild(doc.createTextNode(((Object)list.get(j)).toString()));
								element.appendChild(doc.createTextNode((list.get(j)).toString()));
								childElement.appendChild(element);
							}
						}
					}
			}
			rootElement.appendChild(childElement);
		}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		
		return doc;
	}
	
	private static void buildXML(){
//		String personXMLStringValue
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();
            // Create Person root element 
            Element personRootElement = doc.createElement("Person");
            doc.appendChild(personRootElement);
            // Create First Name Element
            Element firstNameElement = doc.createElement("FirstName");
            firstNameElement.appendChild(doc.createTextNode("Sergey"));
            personRootElement.appendChild(firstNameElement);
            // Create Last Name Element
            Element lastNameElement = doc.createElement("LastName");
            lastNameElement.appendChild(doc.createTextNode("Kargopolov"));
            personRootElement.appendChild(lastNameElement);
            // Transform Document to XML String
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            // Get the String value of final xml document
//            personXMLStringValue = writer.getBuffer().toString();
        } catch (ParserConfigurationException | TransformerException e) {
            e.printStackTrace();
        }
//        System.out.println("personXMLStringValue = " + personXMLStringValue);
	}
	
	private static void checkTime(String time) {

		boolean __result__1 = false;
		String currentDate = time;
		String hour = currentDate.split(":")[0];
		String minutes = currentDate.split(":")[1];
		LogUtilities.logUtil("currentDate>>>>>>>>>>>" + currentDate);
		String EndOfworkingHour = "17";
		String EndOfworkingMinute = "00";
		if (Integer.parseInt(hour) >= Integer.parseInt(EndOfworkingHour)
				&& Integer.parseInt(minutes) >= Integer
						.parseInt(EndOfworkingMinute)) {
			LogUtilities.logUtil("SLA End ............................");
			__result__1 = true;
		}
		LogUtilities.logUtil(Boolean.toString(__result__1));
	}

	public static String convertObjectToString(DataObject  dataObject) {

	BOXMLSerializer serializer = (BOXMLSerializer) new ServiceManager()
			.locateService("com/ibm/websphere/bo/BOXMLSerializer");
		String myXMLString = "aaa";
//		logUtil("dataObject1 ........."+dataObject1.toString());
		// Log in console in and log file
	//	logger.debug("Log4j appender configuration is successful !!");

		try {
//			DataObject	dataObject=(DataObject)dataObject1;
			//logUtil("dataObject ........."+dataObject);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			//logUtil("before serializer .........");
			serializer.writeDataObject(dataObject, dataObject.getType()
				.getURI(), dataObject.getType().getName(), outputStream);
			myXMLString = outputStream.toString("UTF-8");
			//logUtil("After serializer .........");
		} catch (Exception e) {
			//logUtil("Exception ........."+e.getMessage());
//			e.printStackTrace();
		}
		//logUtil("myXMLString ........."+myXMLString);
		return myXMLString;
	}
	
//	public static void logObject(String label, DataObject dataObject,
//			String... processId) {
//		String myXMLString = null;
//		ByteArrayOutputStream baos = new ByteArrayOutputStream(100000);
//		BufferedOutputStream bos = new BufferedOutputStream(baos);
//		BOXMLSerializer serializer = (BOXMLSerializer)ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOXMLSerializer");
//		//InputData is the BusinessObject name.
//		
//		
////		BOXMLSerializer serializer = (BOXMLSerializer) new ServiceManager()
////				.locateService("com/ibm/websphere/bo/BOXMLSerializer");
//		
//
//		// Log in console in and log file
//		logger.debug("Log4j appender configuration is successful !!");
//		if(dataObject != null){
//		try {
//			
//			serializer.writeDataObject(dataObject,dataObject.getType()==null?"NoNamespace":dataObject.getType()
//					.getURI(),dataObject.getType()==null?"noDataType":dataObject.getType().getName(),bos);
//			bos.flush();
//			bos.close();
//			 myXMLString = baos.toString("UTF-8");
//			 
////			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
////
////			serializer.writeDataObject(dataObject, dataObject.getType()==null?"":dataObject.getType()
////					.getURI(), dataObject.getType()==null?"":dataObject.getType().getName(), outputStream);
////			myXMLString = outputStream.toString("UTF-8");
//			
//			// LogUtilities.logUtil(label + "----------------" + myXMLString);
////			System.out.println("processId>>>>>>>>>>>"+processId);
//			if (processId.length ==0) {
////				System.out.println("Normal>>>>>>>>>>>"+processId);
//				logger.info(label + "----------------" + myXMLString);
//			} else {
//				if(processId[0].equals(OperationNamesEnum.BANSERVICE.code)){
//					banLogger.info(label + "----------------" + myXMLString);
//				}
//				else if(processId[0].equals(OperationNamesEnum.DENYSERVICE.code)){
//					denyLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.LIFTSERVICE.code)){
//					liftLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.BLOCKSERVICE.code)){
//					blockLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.GARNISHSERVICE.code)){
//					garnishLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.COMMONSHSERVICE.code)){
//					commonLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.GETACCOUNTINFO.code)){
//					accInfoLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.GETBALSINFO.code)){
//					balInfoLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.GETDEPOTSINFO.code)){
//					depoInfoLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.GETSAFSINFO.code)){
//					safInfoLogger.info(label + "----------------" + myXMLString);
//				}else if(processId[0].equals(OperationNamesEnum.GETLIABSINFO.code)){
//					liabInfoLogger.info(label + "----------------" + myXMLString);
//				}
//				else{
//				slaLogger.info(label + "----------------" + myXMLString);
//				}
//			}
//		
//
//		} catch (Exception e) {
//			logger.info("Logging ----------------");
//		}
//		}
//	}
}
