package com.sama.bea.utilites;

import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.ibm.ejs.ras.SystemOutStream;
import com.ibm.ejs.util.Util;
import com.ibm.websphere.batch.devframework.datastreams.patterns.SystemOutWriter;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.bo.BOXMLSerializer;
import com.ibm.websphere.sca.ServiceManager;
import com.sama.bea.constant.BlockModeConst;
import com.sama.bea.constant.InvolvedPartyEnum;
import com.sama.bea.constant.MoreInfoKeysEnum;
import com.sama.bea.constant.OperationNamesEnum;
import commonj.sdo.DataObject;
// trial
// trial
import conm.sama.bea.domains.FIAmtBO;
import conm.sama.bea.domains.Totals;


public class Utilities {
	static boolean  isThereisActiveProces=false;
	public static boolean isThereisActiveProces() {
		return isThereisActiveProces;
	}

	public static void setThereisActiveProces(boolean isThereisActiveProces) {
		Utilities.isThereisActiveProces = isThereisActiveProces;
	}
	
	public static DataObject constructSendAdminEmailRq(DataObject thrownException)
	{
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject sendMailCommonRq = factory.create("http://BEA-Solution_Library/ProcessLib/Common", "SendMailCommonRq");
		DataObject placeHolder = factory.create("http://BEA-Solution_Library/DBServices/BO", "Attributes");
		DataObject placeHolderItemSRN = factory.create("http://BEA-Solution_Library/DBServices/BO", "Attribute");
		DataObject placeHolderItemPlaceHolder = factory.create("http://BEA-Solution_Library/DBServices/BO", "Attribute");
		List attributeList = new ArrayList<>();
							
		placeHolderItemSRN.setString("Name","SRN");
		placeHolderItemSRN.setString("Value",thrownException.getString("ExProcessSRN"));
		attributeList.add(placeHolderItemSRN);
			
		placeHolderItemPlaceHolder.setString("Name","exception_details");
		placeHolderItemPlaceHolder.setString("Value",LogUtilities.convertObjectToString(thrownException));
		attributeList.add(placeHolderItemPlaceHolder);
			
		

		
		placeHolder.setList("Attribute", attributeList);
		
		sendMailCommonRq.setString("EmailHeaderId", "EXP");
		sendMailCommonRq.setDataObject("PlaceHolder", placeHolder);

		return sendMailCommonRq;
	}

	
	public static DataObject prepareFIList(DataObject fiList, DataObject xferFinInfo, DataObject rqHdr){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		if (fiList == null){
			fiList = factory.create("http://www.sama.bea.sa/common/BaseLib","T_FIList");
		}
		List<String> fiCodes = new ArrayList<String>();
		
		
		if(xferFinInfo != null){
		//case #1 finInfo
		if(xferFinInfo.getDataObject("FIListFinInfo") != null && xferFinInfo.getDataObject("FIListFinInfo").getList("FIFinInfo") != null){
			List<DataObject> fiFinInfo = xferFinInfo.getDataObject("FIListFinInfo").getList("FIFinInfo");
			if(fiFinInfo != null && fiFinInfo.size()>0){
				for(int i = 0; i < fiFinInfo.size(); i++){
					fiCodes.add(fiFinInfo.get(i).getString("FICode"));
				}
			}
		}
		
		
		//case #2 accountInfo
		else if (xferFinInfo.getDataObject("AccFinInfo") != null){
			if(xferFinInfo.getDataObject("AccFinInfo").getDataObject("AccId") != null){
				fiCodes.add(xferFinInfo.getDataObject("AccFinInfo").getDataObject("AccId").getString("BIC"));
			}
		}
		
		}
		//Case #3 all null ...
		else
		{ 
			if (rqHdr.getDataObject("Info") !=null && rqHdr.getDataObject("Info").getList("Attribute").size()>0) {
					List moreInfo = rqHdr.getDataObject("Info").getList("Attribute");
					
					
					for(int i=0;i<moreInfo.size();i++){
						
						if(((DataObject)moreInfo.get(i)).getString("Name").equals(MoreInfoKeysEnum.ALL_BANK_CODES.code)){
						
							String codes = ((DataObject)moreInfo.get(i)).getString("Value");
							String[] values = codes.split(",");
							
							List<String> list = Arrays.asList(values);
							
							fiCodes.addAll(list);
						
						}
					}
				}
		}
		
		fiList.setList("FICode", fiCodes);
		
		return fiList;
	}
	public static DataObject prepareXferAmt(DataObject outline){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject xferAmt = factory.create("http://www.sama.bea.sa/common/BaseLib","T_Amt");
		BigDecimal totAmt = new BigDecimal(0);
		String currency = "";
		//case #1 finInfo
		if(outline.getDataObject("XferFinInfo")!= null)
		{
			if(outline.getDataObject("XferFinInfo")!= null && outline.getDataObject("XferFinInfo").getDataObject("FIListFinInfo") != null 
				&& outline.getDataObject("XferFinInfo").getDataObject("FIListFinInfo").getList("FIFinInfo") != null){
				List<DataObject> fiFinInfo = outline.getDataObject("XferFinInfo").getDataObject("FIListFinInfo").getList("FIFinInfo");
				LogUtilities.logObject("outline", outline, "016");
				System.out.println("fiFinInfo.size()"+fiFinInfo.size());
				if(fiFinInfo != null && fiFinInfo.size()>0){
					currency = fiFinInfo.get(0).getDataObject("Amt").getString("Cur");
					for(int i = 0; i < fiFinInfo.size(); i++){
						System.out.println("fiFinInfo.get(i)"+fiFinInfo.get(i).getDataObject("Amt").getBigDecimal("Val"));
						totAmt = totAmt.add(fiFinInfo.get(i).getDataObject("Amt").getBigDecimal("Val"));
					}
				}
				System.out.println("totamt"+totAmt);
				System.out.println("currency"+currency);
			}
		
		
		
			//case #2 accountInfo
			else if (outline.getDataObject("XferFinInfo").getDataObject("AccFinInfo") != null){
				if(outline.getDataObject("XferFinInfo").getDataObject("AccFinInfo").getDataObject("Amt") != null){
					currency = outline.getDataObject("XferFinInfo").getDataObject("AccFinInfo").getDataObject("Amt").getString("Cur");
					totAmt = totAmt.add(outline.getDataObject("XferFinInfo").getDataObject("AccFinInfo").getDataObject("Amt").getBigDecimal("Val"));
				}
			}
		}
		// case #3 All Null .. 
		// amout = 0
		// cur = empty
		
		xferAmt.setBigDecimal("Val",totAmt);
		xferAmt.setString("Cur", currency);
		return xferAmt;
	}
	
	
	public static DataObject consalidateDenyResponse (DataObject receiveDenyReplyRq,String status,DataObject dispatchRpDenyReplyRq,DataObject dispatchFIDenyInputRq,boolean noData,boolean ackm){
		DataObject RPDenyDlngCallBackRq = null;
		String denyCode=OperationNamesEnum.DENYSERVICE.code;
		LogUtilities.logObject("Inside Consalidate",receiveDenyReplyRq,denyCode);
		LogUtilities.logObject("Inside Consalidate",dispatchFIDenyInputRq,denyCode);
		LogUtilities.logObject("Inside Consalidate",dispatchRpDenyReplyRq,denyCode);
		
		
			String fiCode = "";
			if(ackm){
				fiCode= receiveDenyReplyRq.getDataObject("rsHdr").getString("PID");
			}
			else{
				fiCode =receiveDenyReplyRq.getDataObject("rqHdr").getString("PID");
			}
			
			LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode,denyCode);

			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if(dispatchRpDenyReplyRq == null){
				dispatchRpDenyReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Deny","dispatchRPDenyReplyRq");
			}else{
				RPDenyDlngCallBackRq = dispatchRpDenyReplyRq.getDataObject("RPDenyDlngCallBackRq");
			}
			if(RPDenyDlngCallBackRq==null){
				RPDenyDlngCallBackRq =  factory.create("http://www.sama.bea.sa/execution/services/RPDenyDlng","T_RPDenyDlngCallBackRq");
			}else{
				RPDenyDlngCallBackRq = dispatchRpDenyReplyRq.getDataObject("RPDenyDlngCallBackRq");
			}

		
			List FIRsDenyDlng_list = RPDenyDlngCallBackRq.getList("FIRsDenyDlng");
			if(FIRsDenyDlng_list==null){
				FIRsDenyDlng_list = new ArrayList();
			}
			DataObject FIRsDenyDlng = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsExecution");
			if(!noData){
				FIRsDenyDlng.setString("ExeDtTm",receiveDenyReplyRq.getDataObject("FIDenyDlngCallBackRq").getString("ExeDtTm"));
				FIRsDenyDlng.setDataObject("CustInfo",receiveDenyReplyRq.getDataObject("FIDenyDlngCallBackRq").getDataObject("CustInfo"));
				}
			FIRsDenyDlng.setString("FICode",fiCode);
			FIRsDenyDlng.setString("FIRsStatus",status);
			LogUtilities.logObject("Inside Consalidate FIRsDenyDlng",FIRsDenyDlng,denyCode);

			FIRsDenyDlng_list.add(FIRsDenyDlng);
			LogUtilities.logUtil("Inside Consalidate FIRsDenyDlng_list"+FIRsDenyDlng_list,denyCode);

			RPDenyDlngCallBackRq.setList("FIRsDenyDlng",FIRsDenyDlng_list);
			LogUtilities.logObject(" Inside Consalidate RPDenyDlngCallBackRq",RPDenyDlngCallBackRq,denyCode);

						
			
			dispatchRpDenyReplyRq.setDataObject("RPDenyDlngCallBackRq",RPDenyDlngCallBackRq);
		LogUtilities.logObject(" Inside Consalidate",dispatchRpDenyReplyRq,denyCode);
		return dispatchRpDenyReplyRq;
		
	}
	
	
	
	
	// ban starts
	public static DataObject consalidateBanResponse (DataObject receiveBanReplyRq,String status,DataObject dispatchRpBanReplyRq,DataObject dispatchFIBanInputRq,boolean noData,boolean ackm){
		DataObject RPBanDlngCallBackRq = null;
		String banCode=OperationNamesEnum.BANSERVICE.code;
		LogUtilities.logObject("Inside Consalidate - receiveBanReplyRq",receiveBanReplyRq,banCode);
		LogUtilities.logObject("Inside Consalidate - dispatchFIBanInputRq",dispatchFIBanInputRq,banCode);
		LogUtilities.logObject("Inside Consalidate - dispatchRpBanReplyRq",dispatchRpBanReplyRq,banCode);
		
		
			String fiCode = "";
			if(ackm){
				fiCode= receiveBanReplyRq.getDataObject("rqHdr").getString("PID");
			}
			else{
				fiCode =receiveBanReplyRq.getDataObject("rqHdr").getString("PID");
			}
			
			LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode,banCode);

			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if(dispatchRpBanReplyRq == null){
				dispatchRpBanReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Ban","DispatchRPBanReplyRq");
			}else{
				RPBanDlngCallBackRq = dispatchRpBanReplyRq.getDataObject("RPBanDlngCallBackRq");
			}
			if(RPBanDlngCallBackRq==null){
				RPBanDlngCallBackRq =  factory.create("http://www.sama.bea.sa/execution/services/RPBanDlng","T_RPBanDlngCallBackRq");
//			
//				dispatchRpBanReplyRq.setDataObject("RPBanDlngCallBackRq",RPBanDlngCallBackRq);
			}else{
				RPBanDlngCallBackRq = dispatchRpBanReplyRq.getDataObject("RPBanDlngCallBackRq");
			}

//			List FIRsBanDlng_list = new ArrayList();
//			if (RPBanDlngCallBackRq.getList("FIRsBanDlng") == null){
//				FIRsBanDlng_list = (List) factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsExecution");
//			}
//			else{
//				FIRsBanDlng_list = RPBanDlngCallBackRq.getList("FIRsBanDlng");
//			}
			List FIRsBanDlng_list = RPBanDlngCallBackRq.getList("FIRsBanDlng");
			if(FIRsBanDlng_list==null){
				FIRsBanDlng_list = new ArrayList();
			}
			DataObject FIRsBanDlng = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsExecution");
			if(!noData){
				FIRsBanDlng.setString("ExeDtTm",receiveBanReplyRq.getDataObject("FIBanDlngCallBackRq").getString("ExeDtTm"));
				FIRsBanDlng.setDataObject("CustInfo",receiveBanReplyRq.getDataObject("FIBanDlngCallBackRq").getDataObject("CustInfo"));
				}
			FIRsBanDlng.setString("FICode",fiCode);
			FIRsBanDlng.setString("FIRsStatus",status);
			LogUtilities.logObject("Inside Consalidate FIRsBanDlng",FIRsBanDlng,banCode);

			FIRsBanDlng_list.add(FIRsBanDlng);
			LogUtilities.logUtil("Inside Consalidate FIRsBanDlng_list"+FIRsBanDlng_list,banCode);

			RPBanDlngCallBackRq.setList("FIRsBanDlng",FIRsBanDlng_list);
			LogUtilities.logObject(" Inside Consalidate -  RPBanDlngCallBackRq",RPBanDlngCallBackRq,banCode);

						
			
			dispatchRpBanReplyRq.setDataObject("RPBanDlngCallBackRq",RPBanDlngCallBackRq);
		LogUtilities.logObject(" _-_-_ Consalidate End - dispatchRpBanReplyRq",dispatchRpBanReplyRq,banCode);
		return dispatchRpBanReplyRq;
		
	}
	// ban ends
	
	
	
	
	
	
	
	
	

	
	public static DataObject consalidateLiftResponse (DataObject receiveLiftReplyRq,String status,DataObject dispatchRpLiftReplyRq,DataObject dispatchFILiftInputRq,boolean noData,boolean ackm){
		try{
		DataObject RPLiftCallbackrq = null;
		DataObject FIRsLiftDtls=null;
		String liftCode=OperationNamesEnum.LIFTSERVICE.code;
		LogUtilities.logObject("Inside Consalidate",receiveLiftReplyRq,liftCode);
		LogUtilities.logObject("Inside Consalidate",dispatchFILiftInputRq,liftCode);
		LogUtilities.logObject("Inside Consalidate",dispatchRpLiftReplyRq,liftCode);
		
		
			String fiCode = "";
			if(ackm){
				fiCode= receiveLiftReplyRq.getDataObject("rsHdr").getString("PID");
			}
			else{
				fiCode =receiveLiftReplyRq.getDataObject("rqHdr").getString("PID");
			}
			
			LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode,liftCode);

			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if(dispatchRpLiftReplyRq == null){
				dispatchRpLiftReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Lift","dispatchRPLiftReplyRq");
				LogUtilities.logUtil("dispatchRpLiftReplyRq",liftCode);

			}else{
				RPLiftCallbackrq = dispatchRpLiftReplyRq.getDataObject("RPLiftCallBackRq");
				LogUtilities.logUtil("RPLiftCallBackRq",liftCode);

			}
			LogUtilities.logUtil("dispatchRpLiftReplyRq.getDataObject(RPLiftCallbackrq)==null",liftCode);

			if(dispatchRpLiftReplyRq.getDataObject("RPLiftCallBackRq")==null){
				
				RPLiftCallbackrq =  factory.create("http://www.sama.bea.sa/execution/services/RPLift","T_RPLiftCallBackRq");
				
						LogUtilities.logUtil("dispatchRpLiftReplyRq.setDataObject(RPLiftCallbackrq,RPLiftCallbackrq);",liftCode);

				dispatchRpLiftReplyRq.setDataObject("RPLiftCallBackRq",RPLiftCallbackrq);
			
			}
			else
			{
				FIRsLiftDtls=RPLiftCallbackrq.getDataObject("FIRsLiftDtls");
			//	RPLiftCallbackrq.setDataObject("FIRsLiftDtls",FIRsLiftDtls);
				
			}
			LogUtilities.logUtil("RPLiftCallbackrq.getDataObject(FIRsLiftDtls)==null",liftCode);

			if(RPLiftCallbackrq.getDataObject("FIRsLiftDtls")==null){
				FIRsLiftDtls =  factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsLiftDtls");
				
//			
				RPLiftCallbackrq.setDataObject("FIRsLiftDtls",FIRsLiftDtls);
				LogUtilities.logUtil("FIRsLiftDtlsinside_IF",liftCode);	
			}
			
			LogUtilities.logUtil("FIRsLiftDtls",liftCode);
			List FIRsLift_list = FIRsLiftDtls.getList("FIRsLiftInfo");
			LogUtilities.logUtil("FIRsLiftDtlsafteeeer",liftCode);

			if(FIRsLift_list==null){
				FIRsLift_list = new ArrayList();
				LogUtilities.logUtil("FIRsLift_list",liftCode);
			}
			LogUtilities.logUtil("FIRsLiftDlng",liftCode);

		//	http://www.sama.bea.sa/execution/common/ExecutionLibrary/ExecutionLib	
			DataObject FIRsLiftDlng = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsLiftInfo");
			if(!noData){
				LogUtilities.logObject("rrrrrrrrrrrrre",receiveLiftReplyRq,liftCode);

				LogUtilities.logUtil("nodata",liftCode);
				FIRsLiftDlng.setString("ExeDtTm",receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getString("ExeDtTm"));
				LogUtilities.logUtil("ExeDtTm",liftCode);
				if(receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("CustInfo")!=null)
				{
				FIRsLiftDlng.setDataObject("CustInfo",receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("CustInfo"));
				LogUtilities.logUtil("CustInfo",liftCode);
				}
				LogUtilities.logObject("rrrrrrrrrrrrre",receiveLiftReplyRq,liftCode);

				if(receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo")!=null){
					LogUtilities.logUtil("BlockLiftInfo",liftCode);
					LogUtilities.logObject("rrrrrrrrrrrrre",receiveLiftReplyRq,liftCode);
					  
					LogUtilities.logObject("rrrrrrrrrrrrre11111",receiveLiftReplyRq,liftCode);

					LogUtilities.logUtil("BlockLiftInfo888888888888888888888",liftCode);
					LogUtilities.logObject("Inside Consalidate",receiveLiftReplyRq,liftCode);

				
					if(dispatchRpLiftReplyRq.getDataObject("RPLiftCallBackRq").getDataObject("LiftSmryInfo")==null)
					{
						LogUtilities.logObject("------------------------nulllllll summaaaaaaarrrrryyyyyyyy",receiveLiftReplyRq,liftCode);

						
					DataObject	LiftSmryInfo =  factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_LiftSmryInfo");
						
						LogUtilities.logUtil("dispatchRpLiftReplyRq.setDataObject(LiftSmryInfo,LiftSmryInfo);",liftCode);
					BigDecimal totAmt=receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("SmryInfo").getBigDecimal("TotAmt");
						LiftSmryInfo.set("TotAmt", totAmt);
						LogUtilities.logUtil("tottttttttttttt  "+receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("SmryInfo").getBigDecimal("TotAmt") ,liftCode);
BigDecimal blockAmt= receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("SmryInfo").getBigDecimal("BlockAmt");
						LiftSmryInfo.set("BlockAmt",blockAmt);
				dispatchRpLiftReplyRq.getDataObject("RPLiftCallBackRq").setDataObject("LiftSmryInfo",LiftSmryInfo);
					
					
					}
					else
					{
						LogUtilities.logObject("----------------noooot--------nulllllll summaaaaaaarrrrryyyyyyyy",receiveLiftReplyRq,liftCode);
DataObject	LiftSmryInfo =  dispatchRpLiftReplyRq.getDataObject("RPLiftCallBackRq").getDataObject("LiftSmryInfo");
LogUtilities.logObject("Inside Consalidate",receiveLiftReplyRq,liftCode);

						LogUtilities.logUtil("dispatchRpLiftReplyRq.setDataObject(LiftSmryInfo,LiftSmryInfo);",liftCode);
						BigDecimal totAmt=LiftSmryInfo.getBigDecimal("TotAmt").add(receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("SmryInfo").getBigDecimal("TotAmt"));
						BigDecimal blockAmt=LiftSmryInfo.getBigDecimal("BlockAmt").add(receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("SmryInfo").getBigDecimal("BlockAmt"));
						LiftSmryInfo.set("TotAmt",totAmt );
						LiftSmryInfo.set("BlockAmt",blockAmt);
				dispatchRpLiftReplyRq.getDataObject("RPLiftCallBackRq").setDataObject("LiftSmryInfo",LiftSmryInfo);

						
					}
					DataObject receiveLiftReplyRqTmp=receiveLiftReplyRq;
					DataObject BlockLiftInfo =receiveLiftReplyRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo");
					FIRsLiftDlng.setDataObject("BlockLiftInfo",BlockLiftInfo);
					receiveLiftReplyRq=receiveLiftReplyRqTmp;
					
				}
			
			}
			FIRsLiftDlng.setString("FICode",fiCode);
			FIRsLiftDlng.setString("FIRsStatus",receiveLiftReplyRq.getDataObject("rqHdr").getString("Status"));
			LogUtilities.logObject("Inside Consalidate FIRsLiftDlng",FIRsLiftDlng,liftCode);

			FIRsLift_list.add(FIRsLiftDlng);
			LogUtilities.logUtil("Inside Consalidate FIRsLiftDlng_list"+FIRsLift_list,liftCode);
			
			FIRsLiftDtls.setList("FIRsLiftInfo",FIRsLift_list);
			RPLiftCallbackrq.setDataObject("FIRsLiftDtls",FIRsLiftDtls);
			LogUtilities.logObject(" Inside Consalidate RPLiftDlngCallBackRq",RPLiftCallbackrq,liftCode);

						
			
			dispatchRpLiftReplyRq.setDataObject("RPLiftCallBackRq",RPLiftCallbackrq);
		LogUtilities.logObject(" Inside Consalidate",dispatchRpLiftReplyRq,liftCode);
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
		throw(e);	
		}
		return dispatchRpLiftReplyRq;
		
	}

	
	public static DataObject consalidateBlockResponse(DataObject receiveBlockReplyRq, DataObject dispatchRPBlockReplyRq,BigDecimal pendingAmt, boolean noData, boolean ackm) 
	{
		DataObject RPBlockCallbackRq = null;
		DataObject BlockSmryInfo = null;
		String blockCode = OperationNamesEnum.BLOCKSERVICE.code;
		 LogUtilities.logObject("Inside Consalidate receiveBlockReplyRq",receiveBlockReplyRq,blockCode);
	 //LogUtilities.logObject("Inside Consalidate dispatchRPBlockReplyRq",dispatchRPBlockReplyRq,blockCode);
		String status = "";
		String fiCode = "";
		if (ackm) 
		{
			fiCode = receiveBlockReplyRq.getDataObject("rsHdr").getString("PID");
			status = receiveBlockReplyRq.getDataObject("rsHdr").getString("Status");
		} 
		else 
		{	 LogUtilities.logUtil("not ack", blockCode);

			if(receiveBlockReplyRq.getDataObject("rqHdr") != null) 
			{
					 LogUtilities.logUtil("Header", blockCode);

				fiCode = receiveBlockReplyRq.getDataObject("rqHdr").getString("PID");
				status = receiveBlockReplyRq.getDataObject("rqHdr").getString("Status");
			} 
			else 
			{
				fiCode = receiveBlockReplyRq.getDataObject("rsHdr").getString("PID");
				status = receiveBlockReplyRq.getDataObject("rsHdr").getString("Status");
			}
		}

		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		if (dispatchRPBlockReplyRq == null) 
		{
			 LogUtilities.logUtil("dispatchRPBlockReplyRq    nulllll", blockCode);
			dispatchRPBlockReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Block","DispatchRPBlockReplyRq");
		} 
		else {
//		{ LogUtilities.logUtil("RPBlockCallbackRq    dispatchRPBlockReplyRq.getDataObject", blockCode);
			RPBlockCallbackRq = dispatchRPBlockReplyRq.getDataObject("RPBlockCallBackRq");
		}
		if (dispatchRPBlockReplyRq.getDataObject("RPBlockCallBackRq") == null) {
			LogUtilities.logUtil("dispatchRPBlockReplyRq.getDataObject  RPBlockCallBackRq  nullll", blockCode);
			RPBlockCallbackRq = factory.create("http://www.sama.bea.sa/execution/services/RPBlock","T_RPBlockCallBackRq");
			dispatchRPBlockReplyRq.setDataObject("RPBlockCallBackRq",RPBlockCallbackRq);
		}
		if (RPBlockCallbackRq.getDataObject("SmryInfo") == null) 
		{
			LogUtilities.logUtil("SmryInfo null", blockCode);
			BlockSmryInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_RPBlockSmryInfo");
			BlockSmryInfo.setBigDecimal("BlockAmt",new BigDecimal(0));
			BlockSmryInfo.setBigDecimal("PndngAmt", new BigDecimal(0));
			BlockSmryInfo.setBigDecimal("XferAmt", new BigDecimal(0));
		} 
		else 
		{
			LogUtilities.logUtil("SmryInfo not null", blockCode);
			BlockSmryInfo = RPBlockCallbackRq.getDataObject("SmryInfo");
		}
		LogUtilities.logUtil("BlockSmryInfo<<<<<",blockCode);
		DataObject FIRsBlockDtls = RPBlockCallbackRq.getDataObject("FIRsBlockDtls");
		List FIRsBlock_list=null;
		if (FIRsBlockDtls == null) {
			LogUtilities.logUtil("FIRsBlockDtls null", blockCode);
			FIRsBlockDtls = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsBlockDtls");
		} 
		else{
			LogUtilities.logUtil("FIRsBlockInfo<<<<< ", blockCode);
			FIRsBlock_list = FIRsBlockDtls.getList("FIRsBlockInfo");
		}
		if (FIRsBlock_list == null || FIRsBlock_list.isEmpty()) {
			LogUtilities.logUtil("FIRsBlock_list null ", blockCode);
			FIRsBlock_list = new ArrayList<DataObject>();
		}
		if (checkExistFICodeResponse(FIRsBlock_list, fiCode) == false) {
			LogUtilities.logUtil("checkExistFICodeResponse  ", blockCode);
			DataObject FIRsBlockInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsBlockInfo");
			LogUtilities.logUtil("noData >>>"+noData, blockCode);
			if (!noData && receiveBlockReplyRq.getDataObject("FIBlockCallBackRq") != null) {
				
				if (receiveBlockReplyRq.getDataObject("FIBlockCallBackRq").getDataObject("CustInfo") != null)
				{
					FIRsBlockInfo.setDataObject("CustInfo",receiveBlockReplyRq.getDataObject("FIBlockCallBackRq").getDataObject("CustInfo"));
				}		
				if (receiveBlockReplyRq.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo") != null) 
				{
					// append Totals for each FICODE
					DataObject Totals = null;
					List fitotalLst = new ArrayList<>();
					DataObject BlockInternalData = dispatchRPBlockReplyRq.getDataObject("BlockInternalData");
					if (BlockInternalData == null) {
						LogUtilities.logUtil("dispatchRPBlockReplyRq.getDataObject  T_BlockInternalData  nullll", blockCode);
						BlockInternalData = factory.create("http://BEA-Solution_Library/ProcessLib/Block","T_BlockInternalData");
						Totals = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FITotals");
					}else{
						Totals = BlockInternalData.getDataObject("fiTotals");
						if(Totals==null){
							Totals = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FITotals");
						}else{
							fitotalLst = Totals.getList("FITotal");
						}
					}
					DataObject FITotal = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FITotal");
					FITotal.setString("FICODE", fiCode);
					DataObject totalBO = receiveBlockReplyRq.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo").getDataObject("Totals");
					String hasAccts = receiveBlockReplyRq.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo").getDataObject("AcctsSmryInfo").getString("hasAccts");
					FITotal.setDataObject("Totals",totalBO);
					FITotal.setString("hasAccts", hasAccts);
					fitotalLst.add(FITotal);
					Totals.setList("FITotal",fitotalLst);
					BlockInternalData.setDataObject("fiTotals", Totals);
					dispatchRPBlockReplyRq.setDataObject("BlockInternalData",BlockInternalData);
					FIRsBlockInfo.setDataObject("SmryInfo",(factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_BlockSmryInfo")));
					FIRsBlockInfo.getDataObject("SmryInfo").setBigDecimal("TotAmt", totalBO.getBigDecimal("TotAmt"));
					FIRsBlockInfo.getDataObject("SmryInfo").setBigDecimal("PndngAmt", pendingAmt);
					FIRsBlockInfo.getDataObject("SmryInfo").setBigDecimal("XferAmt", new BigDecimal(0));
					BlockSmryInfo.setBigDecimal("BlockAmt",BlockSmryInfo.getBigDecimal("BlockAmt").add( FIRsBlockInfo.getDataObject("SmryInfo").getBigDecimal("TotAmt")));
				}
		
				LogUtilities.logUtil("BlockSmryInfo<<<<< ", blockCode);
				// Initializing  FIRsBlockInfo.BlockDtlsInfo BO
				DataObject BlockDtlsInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_BlockDtlsInfo");
				DataObject BlocksInqLists = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_BlocksInqLists");
				DataObject BlocksList = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ExeDtlsInfo");
				DataObject InqList = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_InqDtlsInfo");
				
				DataObject Tmp = receiveBlockReplyRq.getDataObject("FIBlockCallBackRq");
				//  BlocksList 	
				if(Tmp.getDataObject("BlockDtlsInfo") != null 
						&& Tmp.getDataObject("BlockDtlsInfo").getDataObject("AcctsList") !=null)
				{
					BlocksList.setDataObject("AcctsList", Tmp.getDataObject("BlockDtlsInfo").getDataObject("AcctsList"));
				}
				
				if(Tmp.getDataObject("BlockDtlsInfo") != null 
						&& Tmp.getDataObject("BlockDtlsInfo").getDataObject("DepotsList")  != null)
				{
					BlocksList.setDataObject("DepotsList", Tmp.getDataObject("BlockDtlsInfo").getDataObject("DepotsList"));
				}
				
				if(Tmp.getDataObject("BlockDtlsInfo") != null && Tmp.getDataObject("BlockDtlsInfo").getDataObject("SafInfo") != null)
				{
					BlocksList.setDataObject("SafInfo", Tmp.getDataObject("BlockDtlsInfo").getDataObject("SafInfo"));
				}
				
				LogUtilities.logUtil("BlocksList<<<<< ", blockCode);
				// InqList
				if(Tmp.getDataObject("InqDtlsInfo") != null)
				{
					InqList = Tmp.getDataObject("InqDtlsInfo");
				}

				LogUtilities.logUtil("InqList<<<<< ", blockCode);
					
				// Set BlockList and InqList to FIRsBlockInfo
				if(BlocksList != null)
					BlocksInqLists.setDataObject("BlocksList", BlocksList);
				if(InqList!=null)
					BlocksInqLists.setDataObject("InqList", InqList);
				if(BlocksInqLists!=null)
					BlockDtlsInfo.setDataObject("BlocksInqLists",BlocksInqLists);
				if(BlockDtlsInfo!=null)
					FIRsBlockInfo.setDataObject("BlockDtlsInfo",BlockDtlsInfo);
				LogUtilities.logUtil("FIRsBlockInfo<<<<< ", blockCode);
			}
			FIRsBlockInfo.setString("FICode", fiCode);
			FIRsBlockInfo.setString("FIRsStatus", status);
			LogUtilities.logUtil("Inside Consalidate FIRsBlock",blockCode);
			FIRsBlock_list.add(FIRsBlockInfo);
			// LogUtilities.logObject("Inside Consalidate FIRsBlock_list",FIRsBlock_list,blockCode);
			FIRsBlockDtls.setList("FIRsBlockInfo", FIRsBlock_list);
			RPBlockCallbackRq.setDataObject("FIRsBlockDtls", FIRsBlockDtls);
			RPBlockCallbackRq.setDataObject("SmryInfo", BlockSmryInfo);
			// LogUtilities.logObject(" Inside Consalidate RPBlockCallBackRq",RPBlockCallBackRq,blockCode);
			dispatchRPBlockReplyRq.setDataObject("RPBlockCallBackRq",RPBlockCallbackRq);
			LogUtilities.logUtil(" Inside Consalidate",blockCode);
		}

		return dispatchRPBlockReplyRq;
	}
	
	
	
	
	
	
	
	
	// consolidateGarnishResponse Starts ..
	public static DataObject consalidateGarnishResponse(DataObject receiveFIGarnishReplyRq, DataObject DispatchRPGarnishReplyRq,BigDecimal pendingAmt, boolean noData, boolean ackm) 
	{
		try{
		
			DataObject RPGarnishCallBackRq = null;
			DataObject GarnishSmryInfo = null;
			String garnishCode = OperationNamesEnum.GARNISHSERVICE.code;
			LogUtilities.logUtil("inside Consolidate Starts...", garnishCode);
			String status = "";
			String fiCode = "";
			if (ackm) 
			{
				fiCode = receiveFIGarnishReplyRq.getDataObject("rsHdr").getString("PID");
				status = receiveFIGarnishReplyRq.getDataObject("rsHdr").getString("Status");
			} 
			else 
			{
				LogUtilities.logUtil("<>inside Consolidate 2 <>", garnishCode);
				if(receiveFIGarnishReplyRq.getDataObject("rqHdr") != null) 
				{
					fiCode = receiveFIGarnishReplyRq.getDataObject("rqHdr").getString("PID");
					status = receiveFIGarnishReplyRq.getDataObject("rqHdr").getString("Status");
				} 
				else 
				{
					fiCode = receiveFIGarnishReplyRq.getDataObject("rsHdr").getString("PID");
					status = receiveFIGarnishReplyRq.getDataObject("rsHdr").getString("Status");
				}
			}

			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if (DispatchRPGarnishReplyRq == null) 
			{
				DispatchRPGarnishReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Garnish","DispatchRPGarnishReplyRq");
			} 
			else 
			{
				RPGarnishCallBackRq = DispatchRPGarnishReplyRq.getDataObject("RPGarnishCallBackRq");
			}
			if (DispatchRPGarnishReplyRq.getDataObject("RPGarnishCallBackRq") == null) 
			{
				RPGarnishCallBackRq = factory.create("http://www.sama.bea.sa/execution/services/RPGarnish","T_RPGarnishCallBackRq");
				DispatchRPGarnishReplyRq.setDataObject("RPGarnishCallBackRq",RPGarnishCallBackRq);
			}
			if (RPGarnishCallBackRq.getDataObject("SmryInfo") == null) 
			{
				GarnishSmryInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_RPGarnishSmryInfo");
				GarnishSmryInfo.setBigDecimal("GarnishAmt",new BigDecimal (0));
				GarnishSmryInfo.setBigDecimal("PndngAmt", new BigDecimal(0));
				//LogUtilities.logUtil("<>inside Consolidate 3 <>", garnishCode);
				//LogUtilities.logObject("<>SmryInfo ==null condition <> GarnishSmryInfo", GarnishSmryInfo, garnishCode);
			} 
			else 
			{
				GarnishSmryInfo = RPGarnishCallBackRq.getDataObject("SmryInfo");
			}
			DataObject FIRsGarnishDtls = RPGarnishCallBackRq.getDataObject("FIRsGarnishDtls");
			if (FIRsGarnishDtls == null) 
			{
				FIRsGarnishDtls = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsGarnishDtls");
			} 

			List FIRsGarnish_list = FIRsGarnishDtls.getList("FIRsGarnishInfo");
			if (FIRsGarnish_list == null) 
			{
				FIRsGarnish_list = new ArrayList();
			}
			
			if (checkExistFICodeResponse(FIRsGarnish_list, fiCode) == false) 
			{
				//LogUtilities.logUtil("<>inside Consolidate 4 <>", garnishCode);
				DataObject FIRsGarnishInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_FIRsGarnishInfo");
				
				if (!noData && receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq") != null) 
				{
					//LogUtilities.logUtil("<>inside Consolidate 5 <>", garnishCode);
					if (receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("CustInfo") != null)
					{
						//LogUtilities.logUtil("<>inside Consolidate 6 <>", garnishCode);
						FIRsGarnishInfo.setDataObject("CustInfo",receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("CustInfo"));
						//LogUtilities.logObject("inside consolidate 6 <> FIRsGarnishInfo", FIRsGarnishInfo, garnishCode);
					}		
						
					if (receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo") != null && receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo").getDataObject("Totals") != null) 
					{
							
						// Set FiTotals .......................................
						DataObject Totals = null;
						List fitotalLst = new ArrayList<>();
						DataObject garnishInternalData = DispatchRPGarnishReplyRq.getDataObject("GarnishInternalData");
						if (garnishInternalData == null) {
							//LogUtilities.logUtil("DispatchRPGarnishReplyRq.getDataObject  T_GarnishInternalData  nullll", garnishCode);
							garnishInternalData = factory.create("http://BEA-Solution_Library/ProcessLib/Garnish","T_GarnishInternalData");
							Totals = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FITotals");
						}else{
							Totals = garnishInternalData.getDataObject("fiTotals");
							if(Totals==null){
								Totals = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FITotals");
							}else{
								fitotalLst = Totals.getList("FITotal");
							}
						}
						//LogUtilities.logObject("<><><>Totals<><><>",Totals , garnishCode);
						DataObject FITotal = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FITotal");
						FITotal.setString("FICODE", fiCode);
						DataObject totalBO = receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo").getDataObject("Totals");
						String hasAccts = receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo").getDataObject("AcctsSmryInfo").getString("hasAccts");
						FITotal.setDataObject("Totals",totalBO);
						FITotal.setString("hasAccts", hasAccts);
						fitotalLst.add(FITotal);
						Totals.setList("FITotal",fitotalLst);
						garnishInternalData.setDataObject("fiTotals", Totals);
						DispatchRPGarnishReplyRq.setDataObject("GarnishInternalData",garnishInternalData);
						//LogUtilities.logObject("<><><>DispatchRPGarnishReplyRq<><><>",DispatchRPGarnishReplyRq , garnishCode);
							
						if(FIRsGarnishInfo.getDataObject("SmryInfo") == null)
						{
							FIRsGarnishInfo.setDataObject("SmryInfo",(factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_GarnishSmryInfo")));
						}
//						FIRsGarnishInfo.getDataObject("SmryInfo").setBigDecimal("TotAmt", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo").getDataObject("Totals").getBigDecimal("TotAmt"));
						FIRsGarnishInfo.getDataObject("SmryInfo").setBigDecimal("TotAmt", totalBO.getBigDecimal("TotAmt"));
						FIRsGarnishInfo.getDataObject("SmryInfo").setBigDecimal("PndngAmt",pendingAmt);
							
						GarnishSmryInfo.setBigDecimal("GarnishAmt",GarnishSmryInfo.getBigDecimal("GarnishAmt").add(FIRsGarnishInfo.getDataObject("SmryInfo").getBigDecimal("TotAmt")));
					}
				
						
					// Initializing  FIRsGarnishInfo.GarnishDtlsInfo BO tree
					DataObject GarnishDtlsInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_GarnishDtlsInfo");
					DataObject GarnishExeDtlsInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_GarnishExeDtlsInfo");
					DataObject DtlsInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ExeDtlsInfo");
					DataObject DtlsInfoNF = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ExeDtlsInfoNF");
					DataObject InqDtlsInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_InqDtlsInfo");
						
					
					if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo") !=null)
					{
					//  GarnishExeDtlsInfo 	
					if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo") !=null)
					{
						// Financial DetailsInfo
						if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo") !=null)
						{
							if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("AcctsList") !=null)
							{
								
								DtlsInfo.setDataObject("AcctsList", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("AcctsList"));
							}
							if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("DepotsList") !=null)
							{
								
								DtlsInfo.setDataObject("DepotsList", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("DepotsList"));
							}
							if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("SafInfo") !=null)
							{
								
								DtlsInfo.setDataObject("SafInfo", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("SafInfo"));
							}
							// Set Not Financial details to null to pass schema validation 
							DtlsInfoNF = null;
								
						}
						// Not Financial DetailsInfo
						else if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF") !=null)
						{
							if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("AcctsList") !=null)
							{
								
								DtlsInfoNF.setDataObject("AcctsList", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("AcctsList"));
							}
							if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("DepotsList") !=null)
							{
								
								DtlsInfoNF.setDataObject("DepotsList", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("DepotsList"));
							}
							if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("SafInfo") !=null)
							{
								
								DtlsInfoNF.setDataObject("SafInfo", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("SafInfo"));
							}
							// Set Financial details to null to pass schema validation 
							DtlsInfo = null;
						}
					}
								
						
						
					// InqDtlsInfo
					if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("InqDtlsInfo") !=null)
					{
						if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("InqDtlsInfo").getDataObject("JntAcctsList") !=null)
						{
							InqDtlsInfo.setDataObject("JntAcctsList", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("InqDtlsInfo").getDataObject("JntAcctsList"));
						}
						if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("InqDtlsInfo").getDataObject("JntDepotsList") !=null)
						{
							InqDtlsInfo.setDataObject("JntDepotsList", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("InqDtlsInfo").getDataObject("JntDepotsList"));
						}
						if(receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("InqDtlsInfo").getDataObject("ShrsList") !=null)
						{
							InqDtlsInfo.setDataObject("ShrsList", receiveFIGarnishReplyRq.getDataObject("FIGarnishCallBackRq").getDataObject("GarnishDtlsInfo").getDataObject("InqDtlsInfo").getDataObject("ShrsList"));
						}
						
					}			
					
					// Set tree nodes after assignment.
					GarnishExeDtlsInfo.setDataObject("DtlsInfo", DtlsInfo);
					GarnishExeDtlsInfo.setDataObject("DtlsInfoNF", DtlsInfoNF);
					GarnishDtlsInfo.setDataObject("GarnishExeDtlsInfo", GarnishExeDtlsInfo);
					GarnishDtlsInfo.setDataObject("InqDtlsInfo", InqDtlsInfo);
					FIRsGarnishInfo.setDataObject("GarnishDtlsInfo", GarnishDtlsInfo);
						
					}
				}
					
				FIRsGarnishInfo.setString("FICode", fiCode);
				FIRsGarnishInfo.setString("FIRsStatus", status);
				FIRsGarnish_list.add(FIRsGarnishInfo);
				FIRsGarnishDtls.setList("FIRsGarnishInfo", FIRsGarnish_list);
				RPGarnishCallBackRq.setDataObject("FIRsGarnishDtls", FIRsGarnishDtls);	
				RPGarnishCallBackRq.setDataObject("SmryInfo", GarnishSmryInfo);
				DispatchRPGarnishReplyRq.setDataObject("RPGarnishCallBackRq",RPGarnishCallBackRq);
				//LogUtilities.logObject(".........Consolidate_Garnish_Method--------RPGarnishCallBackRq", RPGarnishCallBackRq, OperationNamesEnum.GARNISHSERVICE.code);
					
			}
			//LogUtilities.logObject(".........Consolidate_Garnish_Method--------DispatchRPGarnishReplyRq", DispatchRPGarnishReplyRq, OperationNamesEnum.GARNISHSERVICE.code);
			//LogUtilities.logObject("<><><>DispatchRPGarnishReplyRq <>.....End.....<><><>",DispatchRPGarnishReplyRq , garnishCode);
			LogUtilities.logUtil("inside Consolidate Ends...", garnishCode);
			}catch (Exception e) {
				e.printStackTrace();
			}
			return DispatchRPGarnishReplyRq;
		}
		// consolidateGarnishResponse Ends ..
		
		

			//GarnishFirstCallbackResponse Starts ....
	public static DataObject consalidateFirstCallbackResponseGarnish(DataObject receiveFIGarnishReplyParam, DataObject frstFIResponses,boolean data) 
			{
				DataObject smryInfo = null;
				DataObject reply = prepareGarnishReply(receiveFIGarnishReplyParam);
				List responses = null;
				BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
				if (frstFIResponses == null) 
				{
					frstFIResponses = factory.create("http://BEA-Solution_Library/ProcessLib/Garnish","FrstFIGarnishResponses");
				}
				if (frstFIResponses.getList("responses") == null) 
				{
					responses = new ArrayList();
				} 
				else 
				{
					responses = frstFIResponses.getList("responses");
				}
				if (frstFIResponses.getDataObject("smryInfo") == null) 
				{
					smryInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ExeTotalsInfo");
					smryInfo.setBigDecimal("TotAmt",new BigDecimal(0));
					smryInfo.setBigDecimal("AmtRqCur", new BigDecimal(0));
				} 
				else 
				{
					smryInfo = frstFIResponses.getDataObject("smryInfo");
				}
				if(reply.getDataObject("rqHdr") != null)
					responses = checkExistFICodeResponseThenRemove(responses, reply.getDataObject("rqHdr").getString("PID"));
				// add response to list
				
				responses.add(reply);

				if (data == true) 
				{
					// add received amount to total amount to list
					if (reply.getDataObject("FIGarnishCallBackRq") != null && reply.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo") != null && reply.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo").getDataObject("Totals") != null) 
					{	
							smryInfo.setBigDecimal("TotAmt",smryInfo.getBigDecimal("TotAmt").add(reply.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo").getDataObject("Totals").getBigDecimal("TotAmt")));
							smryInfo.setBigDecimal("AmtRqCur",smryInfo.getBigDecimal("AmtRqCur").add( reply.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo").getDataObject("Totals").getBigDecimal("AmtRqCur")));
					}
				}
				frstFIResponses.setList("responses", responses);
				frstFIResponses.setDataObject("smryInfo", smryInfo);
				return frstFIResponses;
			}

	public static DataObject consalidateFirstCallbackResponse(DataObject receiveBlockReplyRq,DataObject frstFIResponses,boolean data){
		DataObject smryInfo = null;
		DataObject reply = prepareBlockReply(receiveBlockReplyRq);
			String blockCode=OperationNamesEnum.BLOCKSERVICE.code;
//			LogUtilities.logObject("Inside consalidateFirstCallbackResponse receiveBlockReplyRq",receiveBlockReplyRq,blockCode);
//			LogUtilities.logObject("Inside consalidateFirstCallbackResponse dispatchRPBlockReplyRq",frstFIResponses,blockCode);
			List responses=null;
			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if(frstFIResponses ==null){
				frstFIResponses =  factory.create("http://BEA-Solution_Library/ProcessLib/Block","FrstFIBlockResponses");
			}
			if(frstFIResponses.getList("responses")==null){
				responses= new ArrayList();
				
			}else{
				responses = frstFIResponses.getList("responses");
			}
			if(frstFIResponses.getDataObject("smryInfo")==null){
				smryInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ExeTotalsInfo");
				smryInfo.setBigDecimal("TotAmt",new BigDecimal(0));
				smryInfo.setBigDecimal("AmtRqCur",new BigDecimal(0));
//				LogUtilities.logObject(" if smryInfo",smryInfo,blockCode);

			}else{
				smryInfo = frstFIResponses.getDataObject("smryInfo");
//				LogUtilities.logObject(" else smryInfo",smryInfo,blockCode);

			}
			if(reply.getDataObject("rqHdr") != null)
				responses = checkExistFICodeResponseThenRemove(responses, reply.getDataObject("rqHdr").getString("PID"));
			// add response to list
			
			responses.add(reply);
			
			if(data==true){
			// add received amount to total amount to list 
			if(reply.getDataObject("FIBlockCallBackRq")!=null && reply.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo")!= null && reply.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo").getDataObject("Totals")!= null){
//				System.out.println("in data condition");
//				LogUtilities.logObject(" data smryInfo",smryInfo,blockCode);
//				LogUtilities.logUtil("totAmt"+smryInfo.getBigDecimal("TotAmt").doubleValue(), blockCode);
//				LogUtilities.logUtil("AmtRqCur"+smryInfo.getBigDecimal("AmtRqCur"), blockCode);

//				LogUtilities.logUtil("sum"+smryInfo.getDouble("TotAmt")+receiveBlockReplyRq.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo").getDataObject("Totals").getDouble("TotAmt"), blockCode);

				
				smryInfo.setBigDecimal("TotAmt",smryInfo.getBigDecimal("TotAmt").add(reply.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo").getDataObject("Totals").getBigDecimal("TotAmt")));
				smryInfo.setBigDecimal("AmtRqCur",smryInfo.getBigDecimal("AmtRqCur").add(reply.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo").getDataObject("Totals").getBigDecimal("AmtRqCur")));
				LogUtilities.logObject(" data smryInfo",smryInfo,blockCode);

			}
		}
			
			
			frstFIResponses.setList("responses",responses);
			frstFIResponses.setDataObject("smryInfo",smryInfo);
			LogUtilities.logObject(" Inside consalidateFirstCallbackResponse",frstFIResponses,blockCode);
		return frstFIResponses;
		
		
	}
	
	public static DataObject consalidateResponseACCINFO (DataObject receiveGIReplyRq,String status,DataObject dispatchGIReplyRq,DataObject dispatchGIInputRq,DataObject operationCodeConst,boolean noData,boolean ackm){
		DataObject RPGetAcctsInfoCallBackRq = null;
		String fiCode = "";
			if(ackm){
				fiCode= receiveGIReplyRq.getDataObject("rsHdr").getString("PID");
			}
			else{
				fiCode =receiveGIReplyRq.getDataObject("rqHdr").getString("PID");
			}
			
			LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode);

			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if(dispatchGIReplyRq == null){
			dispatchGIReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/ACC","DispatchRPACCReplyRq");
			}
			
			if(dispatchGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName").equals(operationCodeConst.getString("GET_ACCOUNTINFO"))){
				LogUtilities.logObject("in Consalidate--dispatchGIInputRq",dispatchGIInputRq,operationCodeConst.getString("GET_ACCOUNTINFO"));
				LogUtilities.logObject("in Consalidate--receiveGIReplyRq",receiveGIReplyRq,operationCodeConst.getString("GET_ACCOUNTINFO"));
				LogUtilities.logObject("in Consalidate--dispatchGIReplyRq",dispatchGIReplyRq,operationCodeConst.getString("GET_ACCOUNTINFO"));
				
			if(dispatchGIReplyRq.getDataObject("RPGetAcctsInfoCallBackRq")==null){
				RPGetAcctsInfoCallBackRq =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetAcctsInfo","T_RPGetAcctsInfoCallBackRq");
															
				dispatchGIReplyRq.setDataObject("RPGetAcctsInfoCallBackRq",RPGetAcctsInfoCallBackRq);
				}
				
			List T_FIRsGetAcctsInfo_LST = dispatchGIReplyRq.getDataObject("RPGetAcctsInfoCallBackRq").getList("FIRsGetAcctsInfo");
			if(T_FIRsGetAcctsInfo_LST==null){
			 T_FIRsGetAcctsInfo_LST = new ArrayList();
			}
			DataObject T_FIRsGetAcctsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetAcctsInfo");
			if(!noData){
				T_FIRsGetAcctsInfo.setDataObject("AcctsList",receiveGIReplyRq.getDataObject("FIGetAcctsInfoCallBackRq").getDataObject("AcctsList"));
				T_FIRsGetAcctsInfo.setDataObject("ShrsList",receiveGIReplyRq.getDataObject("FIGetAcctsInfoCallBackRq").getDataObject("ShrsList"));
				}
			T_FIRsGetAcctsInfo.setString("FICode",fiCode);
			T_FIRsGetAcctsInfo.setString("FIRsStatus",status);
			T_FIRsGetAcctsInfo_LST.add(T_FIRsGetAcctsInfo);
			LogUtilities.logObject("in Consalidate--T_FIRsGetAcctsInfo",T_FIRsGetAcctsInfo,operationCodeConst.getString("GET_ACCOUNTINFO"));
			dispatchGIReplyRq.getDataObject("RPGetAcctsInfoCallBackRq").setList("FIRsGetAcctsInfo",T_FIRsGetAcctsInfo_LST);
			LogUtilities.logObject("in Consalidate--giRPReply",dispatchGIReplyRq,operationCodeConst.getString("GET_ACCOUNTINFO"));
			}

			
		LogUtilities.logObject("After Consalidate",dispatchGIReplyRq,dispatchGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName"));
		return dispatchGIReplyRq;
		
	}

	
	
	
	
	
	
	
	
	
	

	public static DataObject consalidateResponse (DataObject receiveGIReplyRq,String status,DataObject dispatchGIReplyRq,DataObject dispatchGIInputRq,DataObject operationCodeConst,boolean noData,boolean ackm){
		DataObject giRPReply = null;
		DataObject RPGetAcctsInfoCallBackRq = null;
		DataObject RPGetBalsInfoCallBackRq = null;
		DataObject RPGetDepotsInfoCallBackRq = null;
		DataObject RPGetSafsInfoCallBackRq = null;
		DataObject RPGetLiabsInfoCallBackRq = null;
			String fiCode = "";
			if(ackm){
				fiCode= receiveGIReplyRq.getDataObject("rsHdr").getString("PID");
			}
			else{
				fiCode =receiveGIReplyRq.getDataObject("rqHdr").getString("PID");
			}
			
			LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode);

			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if(dispatchGIReplyRq == null){
			dispatchGIReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/GI","DispatchRPGIReplyRq");
			}
//			else{
//			giRPReply = dispatchGIReplyRq.getDataObject("giReply");
//			}
//			if(dispatchGIReplyRq.getDataObject("giReply")==null){
//			giRPReply =  factory.create("http://BEA-Solution_Library/ProcessLib/GI","T_GIRPReply");
//			dispatchGIReplyRq.setDataObject("giReply",giRPReply);
//			}

			if(dispatchGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName").equals(operationCodeConst.getString("GET_ACCOUNTINFO"))){
				LogUtilities.logObject("in Consalidate--dispatchGIInputRq",dispatchGIInputRq,operationCodeConst.getString("GET_ACCOUNTINFO"));
				LogUtilities.logObject("in Consalidate--receiveGIReplyRq",receiveGIReplyRq,operationCodeConst.getString("GET_ACCOUNTINFO"));
				LogUtilities.logObject("in Consalidate--dispatchGIReplyRq",dispatchGIReplyRq,operationCodeConst.getString("GET_ACCOUNTINFO"));
				
			if(dispatchGIInputRq.getDataObject("RPGetAcctsInfoCallBackRq")==null){
				RPGetAcctsInfoCallBackRq =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetAcctsInfo","T_RPGetAcctsInfoCallBackRq");
				dispatchGIInputRq.setDataObject("RPGetAcctsInfoCallBackRq",RPGetAcctsInfoCallBackRq);
				}
				
			List T_FIRsGetAcctsInfo_LST = dispatchGIInputRq.getDataObject("RPGetAcctsInfoCallBackRq").getList("FIRsGetAcctsInfo");
			if(T_FIRsGetAcctsInfo_LST==null){
			 T_FIRsGetAcctsInfo_LST = new ArrayList();
			}
			DataObject T_FIRsGetAcctsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetAcctsInfo");
			if(!noData){
				T_FIRsGetAcctsInfo.setDataObject("AcctsList",receiveGIReplyRq.getDataObject("FIGetAcctsInfoCallBackRq").getDataObject("AcctsList"));
				T_FIRsGetAcctsInfo.setDataObject("ShrsList",receiveGIReplyRq.getDataObject("FIGetAcctsInfoCallBackRq").getDataObject("ShrsList"));
				}
			T_FIRsGetAcctsInfo.setString("FICode",fiCode);
			T_FIRsGetAcctsInfo.setString("FIRsStatus",status);
			T_FIRsGetAcctsInfo_LST.add(T_FIRsGetAcctsInfo);
			LogUtilities.logObject("in Consalidate--T_FIRsGetAcctsInfo",T_FIRsGetAcctsInfo,operationCodeConst.getString("GET_ACCOUNTINFO"));
			dispatchGIInputRq.getDataObject("RPGetAcctsInfoCallBackRq").setList("FIRsGetAcctsInfo",T_FIRsGetAcctsInfo_LST);
			LogUtilities.logObject("in Consalidate--giRPReply",dispatchGIInputRq,operationCodeConst.getString("GET_ACCOUNTINFO"));
			}
			else if(dispatchGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName").equals(operationCodeConst.getString("GET_BALSINFO"))){
			if(dispatchGIInputRq.getDataObject("RPGetBalsInfoCallBackRq")==null){
				RPGetBalsInfoCallBackRq =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetBalsInfo","T_RPGetBalsInfoCallBackRq");
				dispatchGIInputRq.setDataObject("RPGetBalsInfoCallBackRq",RPGetBalsInfoCallBackRq);
				}
			List T_FIRsGetBalsInfo_LST = dispatchGIInputRq.getDataObject("RPGetBalsInfoCallBackRq").getList("FIRsGetBalsInfo");
			if(T_FIRsGetBalsInfo_LST==null){
			T_FIRsGetBalsInfo_LST = new ArrayList();
			}
			DataObject T_FIRsGetBalsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetBalsInfo");
			if(!noData){
				T_FIRsGetBalsInfo.setDataObject("AcctsList",receiveGIReplyRq.getDataObject("FIGetBalsInfoCallBackRq").getDataObject("AcctsList"));
				T_FIRsGetBalsInfo.setDataObject("ShrsList",receiveGIReplyRq.getDataObject("FIGetBalsInfoCallBackRq").getDataObject("ShrsList"));
			}
			T_FIRsGetBalsInfo.setString("FICode",fiCode);
			T_FIRsGetBalsInfo.setString("FIRsStatus",status);
			T_FIRsGetBalsInfo_LST.add(T_FIRsGetBalsInfo);
			giRPReply.getDataObject("RPGetBalsInfoCallBackRq").setList("FIRsGetBalsInfo",T_FIRsGetBalsInfo_LST);
			}

			else if(dispatchGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName").equals(operationCodeConst.getString("GET_DEPOTSINFO"))){
				if(giRPReply.getDataObject("RPGetDepotsInfoCallBackRq")==null){
					RPGetDepotsInfoCallBackRq =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetDepotsInfo","T_RPGetDepotsInfoCallBackRq");
					giRPReply.setDataObject("RPGetDepotsInfoCallBackRq",RPGetDepotsInfoCallBackRq);
				}
			List T_FIRsGetDepotsInfo_LST = giRPReply.getDataObject("RPGetDepotsInfoCallBackRq").getList("FIRsGetDepotsInfo");
			if(T_FIRsGetDepotsInfo_LST==null){
			T_FIRsGetDepotsInfo_LST = new ArrayList();
			}
			DataObject T_FIRsGetDepotsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetDepotsInfo");
			if(!noData){
				T_FIRsGetDepotsInfo.setDataObject("DepotsList",receiveGIReplyRq.getDataObject("giReply").getDataObject("FIGetDepotsInfoCallBackRq").getDataObject("DepotsList"));
				}
			T_FIRsGetDepotsInfo.setString("FICode",fiCode);
			T_FIRsGetDepotsInfo.setString("FIRsStatus",status);
			T_FIRsGetDepotsInfo_LST.add(T_FIRsGetDepotsInfo);
			giRPReply.getDataObject("RPGetDepotsInfoCallBackRq").setList("FIRsGetDepotsInfo",T_FIRsGetDepotsInfo_LST);
			}
			else if(dispatchGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName").equals(operationCodeConst.getString("GET_SAFSINFO"))){
				if(giRPReply.getDataObject("RPGetSafsInfoCallBackRq")==null){
					RPGetSafsInfoCallBackRq =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetSafsInfo","T_RPGetSafsInfoCallBackRq");
					giRPReply.setDataObject("RPGetSafsInfoCallBackRq",RPGetSafsInfoCallBackRq);
				}
			List T_FIRsGetSafsInfo_LST = giRPReply.getDataObject("RPGetSafsInfoCallBackRq").getList("FIRsGetSafsInfo");
			if(T_FIRsGetSafsInfo_LST==null){
			T_FIRsGetSafsInfo_LST = new ArrayList();
			}
			DataObject T_FIRsGetSafsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetSafsInfo");
			if(!noData){
				T_FIRsGetSafsInfo.setDataObject("SafsList",receiveGIReplyRq.getDataObject("giReply").getDataObject("FIGetSafsInfoCallBackRq").getDataObject("SafsList"));
				}
			T_FIRsGetSafsInfo.setString("FICode",fiCode);
			T_FIRsGetSafsInfo.setString("FIRsStatus",status);
			T_FIRsGetSafsInfo_LST.add(T_FIRsGetSafsInfo);
			 giRPReply.getDataObject("RPGetSafsInfoCallBackRq").setList("FIRsGetSafsInfo",T_FIRsGetSafsInfo_LST);

			}
			else if(dispatchGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName").equals(operationCodeConst.getString("GET_LIABSINFO"))){
				if(giRPReply.getDataObject("RPGetLiabsInfoCallBackRq")==null){
					RPGetLiabsInfoCallBackRq =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetLiabsInfo","T_RPGetLiabsInfoCallBackRq");
					giRPReply.setDataObject("RPGetLiabsInfoCallBackRq",RPGetLiabsInfoCallBackRq);
				}
			List T_FIRsGetLiabsInfo_LST = giRPReply.getDataObject("RPGetLiabsInfoCallBackRq").getList("FIRsGetLiabsInfo");
			if(T_FIRsGetLiabsInfo_LST==null){
			T_FIRsGetLiabsInfo_LST = new ArrayList();
			}
			DataObject T_FIRsGetLiabsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetLiabsInfo");
			if(!noData){
				T_FIRsGetLiabsInfo.setDataObject("LiabsList",receiveGIReplyRq.getDataObject("giReply").getDataObject("FIGetLiabsInfoCallBackRq").getDataObject("LiabsList"));
				}
			T_FIRsGetLiabsInfo.setString("FICode",fiCode);
			T_FIRsGetLiabsInfo.setString("FIRsStatus",status);
			T_FIRsGetLiabsInfo_LST.add(T_FIRsGetLiabsInfo);
			giRPReply.getDataObject("RPGetLiabsInfoCallBackRq").setList("FIRsGetLiabsInfo",T_FIRsGetLiabsInfo_LST);
			}
			
		dispatchGIReplyRq.setDataObject("giReply",giRPReply);
		LogUtilities.logObject("After Consalidate",dispatchGIReplyRq,dispatchGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName"));
		return dispatchGIReplyRq;
		
	}
	
	//ConsolidateAccReponse_PERFORMANCE
	public static DataObject consalidateAccResponse(DataObject receiveACCReplyRq,String status,DataObject dispatchAccReplyRq,DataObject dispatchACCInputRq,boolean noData,boolean ackm)
	{
		DataObject RPGetAccInfoCallBackRq = null;
		String fiCode = "";
		if(ackm){
			fiCode= receiveACCReplyRq.getDataObject("rsHdr").getString("PID");
		}
		else{
			fiCode =receiveACCReplyRq.getDataObject("rqHdr").getString("PID");
		}
		LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode);

		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		if(dispatchAccReplyRq == null){
			dispatchAccReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/ACC","DispatchRPACCReplyRq");
		}else{
			RPGetAccInfoCallBackRq = dispatchAccReplyRq.getDataObject("RPGetAcctsInfoCallBackRq");
		}
		// prepare ACC
			if(dispatchAccReplyRq.getDataObject("RPGetAcctsInfoCallBackRq")==null){
				RPGetAccInfoCallBackRq =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetAcctsInfo","T_RPGetAcctsInfoCallBackRq");
														  
				dispatchAccReplyRq.setDataObject("RPGetAcctsInfoCallBackRq",RPGetAccInfoCallBackRq);
			}
			List T_FIRsGetAccInfo_LST = RPGetAccInfoCallBackRq.getList("FIRsGetAcctsInfo");
			if(T_FIRsGetAccInfo_LST==null){
				T_FIRsGetAccInfo_LST = new ArrayList();
			}
			DataObject T_FIRsGetAccInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetAcctsInfo");
			if(!noData){
				T_FIRsGetAccInfo.setDataObject("AcctsList",receiveACCReplyRq.getDataObject("FIGetAcctsInfoCallBackRq").getDataObject("AcctsList"));
				T_FIRsGetAccInfo.setDataObject("ShrsList",receiveACCReplyRq.getDataObject("FIGetAcctsInfoCallBackRq").getDataObject("ShrsList"));
			}
			T_FIRsGetAccInfo.setString("FICode",fiCode);
			T_FIRsGetAccInfo.setString("FIRsStatus",status);
			T_FIRsGetAccInfo_LST.add(T_FIRsGetAccInfo);
			RPGetAccInfoCallBackRq.setList("FIRsGetAcctsInfo",T_FIRsGetAccInfo_LST);
		
		
		dispatchAccReplyRq.setDataObject("RPGetAcctsInfoCallBackRq",RPGetAccInfoCallBackRq);
		LogUtilities.logObject("After Consalidate",dispatchAccReplyRq,dispatchACCInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName"));
		return dispatchAccReplyRq;
		
	}
	
	
	//ConsolidateBalsReponse_PERFORMANCE
	public static DataObject consalidateBalsResponse (DataObject receiveBalReplyRq,String status,DataObject dispatchBalReplyRq,DataObject dispatchBalInputRq,boolean noData,boolean ackm)
	{
		DataObject RPGetBalsInfoCallBackRq = null;
		String fiCode = "";
		if(ackm){
			fiCode= receiveBalReplyRq.getDataObject("rsHdr").getString("PID");
		}
		else{
				fiCode =receiveBalReplyRq.getDataObject("rqHdr").getString("PID");
		}
		LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode);

		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		if(dispatchBalReplyRq == null){
			dispatchBalReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/BAL","DispatchRPBALReplyRq");
		}else{
			RPGetBalsInfoCallBackRq = dispatchBalReplyRq.getDataObject("RPGetBalsInfoCallBackRq");
		}
		// prepare balsInfo
			if(dispatchBalReplyRq.getDataObject("RPGetBalsInfoCallBackRq")==null){
				RPGetBalsInfoCallBackRq =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetBalsInfo","T_RPGetBalsInfoCallBackRq");
				dispatchBalReplyRq.setDataObject("RPGetBalsInfoCallBackRq",RPGetBalsInfoCallBackRq);
			}
			List T_FIRsGetBalsInfo_LST = RPGetBalsInfoCallBackRq.getList("FIRsGetBalsInfo");
			if(T_FIRsGetBalsInfo_LST==null){
				T_FIRsGetBalsInfo_LST = new ArrayList();
			}
			DataObject T_FIRsGetBalsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetBalsInfo");
			if(!noData){
				T_FIRsGetBalsInfo.setDataObject("AcctsList",receiveBalReplyRq.getDataObject("FIGetBalsInfoCallBackRq").getDataObject("AcctsList"));
				T_FIRsGetBalsInfo.setDataObject("ShrsList",receiveBalReplyRq.getDataObject("FIGetBalsInfoCallBackRq").getDataObject("ShrsList"));
			}
			T_FIRsGetBalsInfo.setString("FICode",fiCode);
			T_FIRsGetBalsInfo.setString("FIRsStatus",status);
			T_FIRsGetBalsInfo_LST.add(T_FIRsGetBalsInfo);
			RPGetBalsInfoCallBackRq.setList("FIRsGetBalsInfo",T_FIRsGetBalsInfo_LST);
		
		
		dispatchBalReplyRq.setDataObject("RPGetBalsInfoCallBackRq",RPGetBalsInfoCallBackRq);
		LogUtilities.logObject("After Consalidate",dispatchBalReplyRq,dispatchBalInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName"));
		return dispatchBalReplyRq;
		
	}
	//ConsolidateTRANSFERResponse_Transfer Process
	public static DataObject consalidateTransferResponse(DataObject receiveTransferReplyRq,String status,DataObject dispatchTransferReplyRq,DataObject dispatchTransferInputRq,boolean noData,boolean ackm)
	{
		try {
			
//		LogUtilities.logObject("inside consolidate - dispatchRPTransferReplyParam-------------", dispatchTransferReplyRq,"016");
		DataObject RPGetTransferInfoCallBackRq = null;
		
		String fiCode = "";
		BigDecimal totalAmt = new BigDecimal(0);
		if(ackm){
			fiCode= receiveTransferReplyRq.getDataObject("rsHdr").getString("PID");
		}
		else{
			fiCode =receiveTransferReplyRq.getDataObject("rqHdr").getString("PID");
		}
		LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode);
//		System.out.println("inside Data totalAmt1"+totalAmt);
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		if(dispatchTransferReplyRq == null){
			dispatchTransferReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Transfer","DispatchRPTransferReplyRq");
		}else{
			RPGetTransferInfoCallBackRq  = dispatchTransferReplyRq.getDataObject("RPTransferCallBackRq");
			totalAmt = RPGetTransferInfoCallBackRq.getBigDecimal("TotalAmt");
//			System.out.println("inside Data totalAmt2"+totalAmt);
		}
//		LogUtilities.logObject("inside consolidate - RPGetTransferInfoCallBackRq-------------", RPGetTransferInfoCallBackRq,"016");
		// prepare Transfer Info
			if(dispatchTransferReplyRq.getDataObject("RPTransferCallBackRq")==null){
				RPGetTransferInfoCallBackRq  =  factory.create("http://www.sama.bea.sa/execution/services/RPTransfer","T_RPTransferCallBackRq");
				dispatchTransferReplyRq.setDataObject("RPTransferCallBackRq",RPGetTransferInfoCallBackRq);
			}else{
				RPGetTransferInfoCallBackRq = dispatchTransferReplyRq.getDataObject("RPTransferCallBackRq");
				
			}
			
			DataObject FIRsTransferDtls = RPGetTransferInfoCallBackRq.getDataObject("FIRsTransferDtls");
			if(FIRsTransferDtls==null){
				FIRsTransferDtls = factory.create("http://www.sama.bea.sa/execution/services/RPTransfer","T_FIRsTransferDtls");
			}
			
			List T_FIRsGetTransfer_LST = FIRsTransferDtls.getList("FIRsTransferInfo");
			if(T_FIRsGetTransfer_LST==null || T_FIRsGetTransfer_LST.isEmpty()){
				T_FIRsGetTransfer_LST = new ArrayList();
			}
			DataObject T_FIRsGetTransferInfo = factory.create("http://www.sama.bea.sa/execution/services/RPTransfer","T_FIRsTransferInfo");
			if(!noData){
				DataObject FITransferCallBackRq= receiveTransferReplyRq.getDataObject("FITransferCallBackRq");
				if(FITransferCallBackRq.getDataObject("CustInfo")!=null)
					T_FIRsGetTransferInfo.setDataObject("CustInfo",FITransferCallBackRq.getDataObject("CustInfo"));
				if(FITransferCallBackRq.getDataObject("XfersList")!=null)
					T_FIRsGetTransferInfo.setDataObject("XfersList",FITransferCallBackRq.getDataObject("XfersList"));
				if(FITransferCallBackRq.getBigDecimal("TotalAmt")!=null){
					BigDecimal fiAmt = FITransferCallBackRq.getBigDecimal("TotalAmt");
					T_FIRsGetTransferInfo.setBigDecimal("TotalFIAmt",fiAmt);
//					System.out.println("inside Data fiAmt"+fiAmt);
					totalAmt = totalAmt.add(fiAmt);
					System.out.println("inside Data totalAmt3"+totalAmt);
				}
				
			}
			T_FIRsGetTransferInfo.setString("FICode",fiCode);
			T_FIRsGetTransferInfo.setString("FIRsStatus",status);
			T_FIRsGetTransfer_LST.add(T_FIRsGetTransferInfo);
			FIRsTransferDtls.setList("FIRsTransferInfo",T_FIRsGetTransfer_LST);
			
			RPGetTransferInfoCallBackRq.setDataObject("FIRsTransferDtls",FIRsTransferDtls);
			RPGetTransferInfoCallBackRq.setBigDecimal("TotalAmt",totalAmt);
			LogUtilities.logObject("inside consolidate - RPGetTransferInfoCallBackRq222-------------", RPGetTransferInfoCallBackRq,"016");
			dispatchTransferReplyRq.setDataObject("RPTransferCallBackRq",RPGetTransferInfoCallBackRq );
						
		} catch (Exception e) {
			e.printStackTrace(System.out);
			System.out.println(e.getMessage());
		}
		return dispatchTransferReplyRq;
		
	}	
	//ConsolidateDepotResponse_PERFORMANCE
	public static DataObject consalidateDepotResponse (DataObject receiveDEPOTReplyRq,String status,DataObject dispatchDEPOTReplyRq,DataObject dispatchDEPOTInputRq,boolean noData,boolean ackm)
	{
		DataObject RPGetDepotsInfoCallBackRq = null;
		String fiCode = "";
		if(ackm){
			fiCode= receiveDEPOTReplyRq.getDataObject("rsHdr").getString("PID");
		}
		else{
			fiCode =receiveDEPOTReplyRq.getDataObject("rqHdr").getString("PID");
		}
		LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode);

		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		if(dispatchDEPOTReplyRq == null){
			dispatchDEPOTReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/DEPOT","DispatchRPDEPOTReplyRq");
		}else{
			RPGetDepotsInfoCallBackRq  = dispatchDEPOTReplyRq.getDataObject("RPGetDepotsCallBackRq");
		}
		// prepare depotsInfo
			if(dispatchDEPOTReplyRq.getDataObject("RPGetDepotsCallBackRq")==null){
				RPGetDepotsInfoCallBackRq  =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetDepotsInfo","T_RPGetDepotsInfoCallBackRq");
				dispatchDEPOTReplyRq.setDataObject("RPGetDepotsCallBackRq",RPGetDepotsInfoCallBackRq);
			}
			List T_FIRsGetDepots_LST = RPGetDepotsInfoCallBackRq.getList("FIRsGetDepotsInfo");
			if(T_FIRsGetDepots_LST==null){
				T_FIRsGetDepots_LST = new ArrayList();
			}
			DataObject T_FIRsGetDepotsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetDepotsInfo");
			if(!noData){
				T_FIRsGetDepotsInfo.setDataObject("DepotsList",receiveDEPOTReplyRq.getDataObject("FIGetDepotsInfoCallBackRq").getDataObject("DepotsList"));
				
			}
			T_FIRsGetDepotsInfo.setString("FICode",fiCode);
			T_FIRsGetDepotsInfo.setString("FIRsStatus",status);
			T_FIRsGetDepots_LST.add(T_FIRsGetDepotsInfo);
			RPGetDepotsInfoCallBackRq.setList("FIRsGetDepotsInfo",T_FIRsGetDepots_LST);
		
		
			dispatchDEPOTReplyRq.setDataObject("RPGetDepotsCallBackRq",RPGetDepotsInfoCallBackRq );
			LogUtilities.logObject("end of consolidate fn - logging dispatchDEPOTReplyRq",dispatchDEPOTReplyRq,dispatchDEPOTInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName"));			
			
		return dispatchDEPOTReplyRq;
		
	}	
	
	//consalidateLiabResponse_PERFORMANCE
		public static DataObject consalidateLiabResponse (DataObject receiveLIABReplyRq,String status,DataObject dispatchLIABReplyRq,DataObject dispatchLIABInputRq,boolean noData,boolean ackm)
		{
			DataObject RPGetLiabsInfoCallBackRq = null;
			String fiCode = "";
			if(ackm){
				fiCode= receiveLIABReplyRq.getDataObject("rsHdr").getString("PID");
			}
			else{
				fiCode =receiveLIABReplyRq.getDataObject("rqHdr").getString("PID");
			}
			LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode);

			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if(dispatchLIABReplyRq == null){
				dispatchLIABReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/LIAB","DispatchRPLIABReplyRq");
			}else{
				RPGetLiabsInfoCallBackRq  = dispatchLIABReplyRq.getDataObject("RPGetLiabsInfoCallBackRq");			
			}
			// prepare liabsInfo
				if(dispatchLIABReplyRq.getDataObject("RPGetLiabsInfoCallBackRq")==null){
					RPGetLiabsInfoCallBackRq  =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetLiabsInfo","T_RPGetLiabsInfoCallBackRq");
					dispatchLIABReplyRq.setDataObject("RPGetLiabsInfoCallBackRq",RPGetLiabsInfoCallBackRq);
				}
				List T_FIRsGetLiabs_LST = RPGetLiabsInfoCallBackRq.getList("FIRsGetLiabsInfo");
				if(T_FIRsGetLiabs_LST==null){
					T_FIRsGetLiabs_LST = new ArrayList();
				}
				DataObject T_FIRsGetLiabsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetLiabsInfo");
				if(!noData){
					T_FIRsGetLiabsInfo.setDataObject("LiabsList",receiveLIABReplyRq.getDataObject("FIGetLiabsInfoCallBackRq").getDataObject("LiabsList"));
					
				}
				T_FIRsGetLiabsInfo.setString("FICode",fiCode);
				T_FIRsGetLiabsInfo.setString("FIRsStatus",status);
				T_FIRsGetLiabs_LST.add(T_FIRsGetLiabsInfo);
				RPGetLiabsInfoCallBackRq.setList("FIRsGetLiabsInfo",T_FIRsGetLiabs_LST);
			
			
			dispatchLIABReplyRq.setDataObject("RPGetLiabsInfoCallBackRq",RPGetLiabsInfoCallBackRq );
			LogUtilities.logObject("end of consolidate fn  logging dispatchLIABReplyRq",dispatchLIABReplyRq,dispatchLIABInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName"));
			return dispatchLIABReplyRq;
			
		}		

		//ConsolidateSafResponse_PERFORMANCE
		public static DataObject consalidateSafResponse (DataObject receiveSAFReplyRq,String status,DataObject dispatchSAFReplyRq,DataObject dispatchSAFInputRq,boolean noData,boolean ackm)
		{
			DataObject RPGetSafsInfoCallBackRq = null;
			String fiCode = "";
			if(ackm){
				fiCode= receiveSAFReplyRq.getDataObject("rsHdr").getString("PID");
			}
			else{
				fiCode =receiveSAFReplyRq.getDataObject("rqHdr").getString("PID");
			}
			LogUtilities.logUtil("Status>>"+status+">>>FiCode>>"+fiCode);

			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			if(dispatchSAFReplyRq == null){
				dispatchSAFReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/SAF","DispatchRPSAFReplyRq");
			}else{
				RPGetSafsInfoCallBackRq  = dispatchSAFReplyRq.getDataObject("RPGetSafsInfoCallBackRq");
			}
			// prepare SafsInfo
				if(dispatchSAFReplyRq.getDataObject("RPGetSafsInfoCallBackRq")==null){
					RPGetSafsInfoCallBackRq  =  factory.create("http://www.sama.bea.sa/inquiry/services/RPGetSafsInfo","T_RPGetSafsInfoCallBackRq");
					dispatchSAFReplyRq.setDataObject("RPGetSafsInfoCallBackRq",RPGetSafsInfoCallBackRq);
				}
				List T_FIRsGetSafs_LST = RPGetSafsInfoCallBackRq.getList("FIRsGetSafsInfo");
				if(T_FIRsGetSafs_LST==null){
					T_FIRsGetSafs_LST = new ArrayList();
				}
				DataObject T_FIRsGetSafsInfo = factory.create("http://www.sama.bea.sa/inquiry/services/GeneralInquiryLib","T_FIRsGetSafsInfo");
				if(!noData){
					T_FIRsGetSafsInfo.setDataObject("SafsList",receiveSAFReplyRq.getDataObject("FIGetSafsInfoCallBackRq").getDataObject("SafsList"));
					
				}
				T_FIRsGetSafsInfo.setString("FICode",fiCode);
				T_FIRsGetSafsInfo.setString("FIRsStatus",status);
				T_FIRsGetSafs_LST.add(T_FIRsGetSafsInfo);
				RPGetSafsInfoCallBackRq.setList("FIRsGetSafsInfo",T_FIRsGetSafs_LST);
			
			
				dispatchSAFReplyRq.setDataObject("RPGetSafsInfoCallBackRq",RPGetSafsInfoCallBackRq );
				LogUtilities.logObject("end of consolidate fn - logging dispatchSAFReplyRq",dispatchSAFReplyRq,dispatchSAFInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName"));			
				
			return dispatchSAFReplyRq;
			
		}			
	
	public static String castObjectToString(DataObject dataObject) {

		BOXMLSerializer serializer = (BOXMLSerializer) new ServiceManager()
				.locateService("com/ibm/websphere/bo/BOXMLSerializer");
		String myXMLString = "";

		try {
			if(dataObject!= null){
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

			serializer.writeDataObject(dataObject, "", dataObject.getType().getName(), outputStream);
			myXMLString = outputStream.toString("UTF-8");
			
			LogUtilities.logUtil("----------------" + myXMLString);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return myXMLString;
	}
	
	 public static DataObject convertStrToDataObject(String input) 
	 {
	  // TODO Auto-generated method stub
	  String bo = input;
	  commonj.sdo.DataObject dataObject = null;
	  try {
	   // create BO from XML string
	   byte[] C_START = new byte[] {'<', '!', '[', 'C', 'D', 'A', 'T', 'A', '['};
	   byte[] C_END = new byte[] {']', ']', '>'};
	   String encoding = "UTF-8";
	   String Cstart = new String(C_START, encoding);
	   String Cend = new String(C_END, encoding);
	   if (bo.startsWith(Cstart)) {
	    bo = bo.substring(Cstart.length(), bo.length()-Cend.length());
	   }
	   com.ibm.websphere.bo.BOXMLSerializer boXMLSerializer = (com.ibm.websphere.bo.BOXMLSerializer) com.ibm.websphere.sca.ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOXMLSerializer");
	   com.ibm.websphere.bo.BOXMLDocument boDoc = boXMLSerializer.readXMLDocument(new java.io.ByteArrayInputStream(bo.getBytes(encoding)));
	   dataObject = boDoc.getDataObject();
	  }
	  catch(java.io.IOException ex){
	  }
	  return dataObject; 
	 }
	
	public static String convertListToString(DataObject input) {
		String result = "";
		List list= input.getList("FICode");
		try {
			if (list != null && list.size() > 0) {
				for (int i = 0; i < list.size(); i++) {
					result += list.get(i) + ",";
				}
				result = result.substring(0, result.length() - 1);
			} else {
				result = "";
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(result);
		return result;
	}
	
	public static DataObject convertStringToList(String input) {
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		//System.out.println("FICODES>>>"+input);
		DataObject result = factory.create("http://www.sama.bea.sa/common/BaseLib","T_FIList");
		List list= new ArrayList<String>();
		try {
			String[] fiCodes = input.split(",");
			for(int i=0;i<fiCodes.length;i++){
				list.add(fiCodes[i]);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		result.setList("FICode",list);
		return result;
	}
	
	public static DataObject appendToFIList(DataObject fiList,String fiCode){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		if(fiList==null){
			fiList = factory.create("http://www.sama.bea.sa/common/BaseLib","T_FIList");
		List fiCodes = new ArrayList();
		fiCodes.add(fiCode);
		fiList.setList("FICode",fiCodes);
		}
		else{
			fiList.getList("FICode").add(fiCode);
		}
		return fiList;
	}
	
	public static DataObject removeFromFIList(DataObject fiList,String fiCode){
		if(fiList != null && fiList.getList("FICode")!= null){
			if(fiList.getList("FICode").contains(fiCode)){
				fiList.getList("FICode").remove(fiCode);
			}
		}
		return fiList;
	}
	
	public static DataObject findCurrentExtrSrvcTask(DataObject fiRqsts,String fiCode){
		DataObject currentSrvcTask = null;
		for(int i=0;i<fiRqsts.getList("exetr_srvc_task").size();i++){
			if(((DataObject)fiRqsts.getList("exetr_srvc_task").get(i)).getString("fin_inst_cd").equals(fiCode)){
				currentSrvcTask = ((DataObject)fiRqsts.getList("exetr_srvc_task").get(i));
				break;
			}
		}
		return currentSrvcTask;
	}
	
	public static DataObject movePortalFICodes(String moreInfoValue,DataObject portalFICodes){
		String[] b2bCodes = moreInfoValue.split(",");
	 	for(int i=0;i<b2bCodes.length;i++){
	 		portalFICodes = Utilities.appendToFIList(portalFICodes,b2bCodes[i]);
	 		}
		return portalFICodes;
	}
	
	public static DataObject returnPortalFICodes(DataObject b2bFICodes,DataObject allFIcodes){
		for(int j=b2bFICodes.getList("FICode").size()-1;j>=0;j--){
	 		if(allFIcodes.getList("FICode").contains(b2bFICodes.getList("FICode").get(j))){
	 			allFIcodes.getList("FICode").remove(b2bFICodes.getList("FICode").get(j));
	 			}else{
	 				b2bFICodes.getList("FICode").remove(b2bFICodes.getList("FICode").get(j));
	 			}
	 		}
		return allFIcodes;
	}
	
	
	public static DataObject preparePostActionExtrSrvcTask(DataObject currentExtrTask ,DataObject extrTaskStatusConst,DataObject channelCodeConst,String mode,String SRN,DataObject actionRow,DataObject accQry){
		
		String PID = actionRow.getString("FICODE");
		String ovrMsgId = actionRow.getString("MsgUID");
		BigDecimal ovr_Amt = actionRow.getBigDecimal("ActionAmt");
		DataObject fiSmryInfo = actionRow.getDataObject("SmryInfo");
		
		String MsgUId = SRN+"-"+KeysUtil.generateMuId();
		if(currentExtrTask.getString("channel_cd")==null || currentExtrTask.getString("channel_cd").equals(channelCodeConst.getString("B2B"))){
			currentExtrTask.setString("channel_cd",channelCodeConst.getString("B2B"));
			currentExtrTask.setString("trans_status",extrTaskStatusConst.getString("SENDING"));
		}
		else 
			currentExtrTask.setString("trans_status",extrTaskStatusConst.getString("DELIVERD"));
		
		//LogUtilities.logUtil(MsgUId,OperationNamesEnum.BLOCKSERVICE.code);
		if(mode.equals(BlockModeConst.REVERSE.code)){
			LogUtilities.logUtil("inside reverse............... "+mode, OperationNamesEnum.BLOCKSERVICE.code);
			currentExtrTask.setString("exetr_ref_no",ovrMsgId);
			currentExtrTask.setString("ovr_msguid",null);
//			currentExtrTask.setString("exetr_ref_no",MsgUId);
		}else if(mode.equals(BlockModeConst.TRANSFER.code)){
			currentExtrTask.setString("exetr_ref_no",MsgUId);
			currentExtrTask.setString("ovr_msguid",null);
			if(accQry != null){
				currentExtrTask.setDataObject("accQry",accQry);
			}
		}else{
			LogUtilities.logUtil("inside ovveride............... "+mode, OperationNamesEnum.BLOCKSERVICE.code);
			currentExtrTask.setString("exetr_ref_no",MsgUId);
			currentExtrTask.setString("ovr_msguid",ovrMsgId);
			currentExtrTask.setDataObject("FISmryInfo", fiSmryInfo);
			if(fiSmryInfo.getDataObject("Totals") != null && fiSmryInfo.getDataObject("Totals").getBigDecimal("TotAmt") != null){
				currentExtrTask.setBigDecimal("blocked_amt", fiSmryInfo.getDataObject("Totals").getBigDecimal("TotAmt"));
			}
		}
		
		currentExtrTask.setBigDecimal("ovr_amt",ovr_Amt);
		currentExtrTask.setString("trans_date", KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss.SSS"));
		currentExtrTask.setString("trans_msg_code",null );
		currentExtrTask.setInt("parent_cd",currentExtrTask.getInt("exetr_srvc_task_id"));
		currentExtrTask.setInt("task_order",currentExtrTask.getInt("task_order")+1);
		currentExtrTask.setString("task_mode",mode);
		return currentExtrTask;
	}
	
	public static DataObject prepareExtrSrvcTask(DataObject currentExtrTask ,DataObject extrTaskStatusConst,DataObject channelCodeConst,String channel,String SRN,String PID,int agcyPk){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		String MsgUId = SRN+"-"+KeysUtil.generateMuId();
		if(currentExtrTask==null)
			currentExtrTask = factory.create("http://www.sama.bea.sa/DBServices/tanfeethexetr_srvc_task","Exetr_Srvc_Task");
		
		if(channel.equals(channelCodeConst.getString("B2B"))){
			currentExtrTask.setString("trans_status",extrTaskStatusConst.getString("SENDING"));
		currentExtrTask.setString("channel_cd",channelCodeConst.getString("B2B"));
	}
		else {
			currentExtrTask.setString("trans_status",extrTaskStatusConst.getString("DELIVERD"));
			currentExtrTask.setString("channel_cd",channelCodeConst.getString("Portal"));
		}
		currentExtrTask.setInt("agcy_srvc_reqst_id",agcyPk);
		currentExtrTask.setString("fin_inst_cd",PID);
		currentExtrTask.setString("exetr_ref_no",MsgUId);
		currentExtrTask.setString("trans_date", KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss.SSS"));
		currentExtrTask.setString("trans_msg_code",null);
		currentExtrTask.setInt("task_order",0);
		return currentExtrTask;
	}
	
	public static DataObject prepareDispatchFIRq(DataObject currentExtrSrvcTask,DataObject dispatchFIInputMQRq){
		
		String msgUId = currentExtrSrvcTask.getString("exetr_ref_no");
		String PID = currentExtrSrvcTask.getString("fin_inst_cd");
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("MsgUID",msgUId);
		String msgDtTm = KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd'T'HH:mm:ss");
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("MsgDtTm",msgDtTm);
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("PID",PID);
		return dispatchFIInputMQRq;
	}
	
	public static DataObject prepareDispatchXferFIRq(DataObject currentExtrSrvcTask,DataObject dispatchFIInputMQRq,DataObject XferFinInfo){
		
		String msgUId = currentExtrSrvcTask.getString("exetr_ref_no");
		String PID = currentExtrSrvcTask.getString("fin_inst_cd");
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("MsgUID",msgUId);
		String msgDtTm = KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd'T'HH:mm:ss");
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("MsgDtTm",msgDtTm);
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("PID",PID);
		if(XferFinInfo != null && XferFinInfo.getDataObject("FIListFinInfo") != null)
			dispatchFIInputMQRq.getDataObject("FITransferRq").getDataObject("Outline").getDataObject("Amt").setBigDecimal("Val", getFIAmt(XferFinInfo,currentExtrSrvcTask.getString("fin_inst_cd")));
		return dispatchFIInputMQRq;
	}
	
	
public static DataObject prepareDispatchLiftFIRq(DataObject currentExtrSrvcTask,DataObject dispatchFIInputMQRq,DataObject execSumDetails){
		
		String msgUId = currentExtrSrvcTask.getString("exetr_ref_no");
		String PID = currentExtrSrvcTask.getString("fin_inst_cd");
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("MsgUID",msgUId);
		String msgDtTm = KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd'T'HH:mm:ss");
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("MsgDtTm",msgDtTm);
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("PID",PID);
		
		System.out.println("-------------  0 execSumDetails -------------" );

		if(execSumDetails!=null&&execSumDetails.getList("exec_sum_details")!=null&&dispatchFIInputMQRq.getDataObject("FILiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn")!=null)
		{
			int size=execSumDetails.getList("exec_sum_details").size();
			System.out.println("------------- execSumDetails size -------------" + size);

			for(int k=0;k<size;k++)
			{
				System.out.println("------------- 1  -------------" + k);
				if(((DataObject)execSumDetails.getList("exec_sum_details").get(k)).getString("fin_inst_cd").equals(PID))
				{
					System.out.println("------------- 2 -------------" );
					if(((DataObject)execSumDetails.getList("exec_sum_details").get(k)).getString("isTrans").equals("y"))
					{			    
						System.out.println("------------- 3 -------------" );
						dispatchFIInputMQRq.getDataObject("FILiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn").getDataObject("FundXfer").setBigDecimal("Amt", ((DataObject)execSumDetails.getList("exec_sum_details").get(k)).getBigDecimal("total_amt"));
					}
				}
//				else
//				{
//					System.out.println("------------- 4 -------------" );
//					dispatchFIInputMQRq.getDataObject("FILiftRq").getDataObject("Outline").setDataObject("BlockLiftCndtn", null);
//				}
			}
		}
		else
		{
			System.out.println("------------- 4 -------------" );
			dispatchFIInputMQRq.getDataObject("FILiftRq").getDataObject("Outline").setDataObject("BlockLiftCndtn", null);
		}
		return dispatchFIInputMQRq;
	}
	
	public static DataObject preparePostActionDispatchFIRq(DataObject currentExtrSrvcTask,DataObject dispatchFIInputMQRq){
		
		String msgUId = currentExtrSrvcTask.getString("exetr_ref_no");
		String ovrMsgUId = currentExtrSrvcTask.getString("ovr_msguid");
		String PID = currentExtrSrvcTask.getString("fin_inst_cd");
		String msgDtTm = KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd'T'HH:mm:ss");
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("MsgUID",msgUId);
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("MsgDtTm",msgDtTm);
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("PID",PID);
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("OvrdMsgUID",ovrMsgUId);
		dispatchFIInputMQRq.getDataObject("rqHdr").setString("ChID",currentExtrSrvcTask.getString("channel_cd"));
		return dispatchFIInputMQRq;
	}
	
public static DataObject preparePostActionDispatchFIRqData(DataObject currentExtrSrvcTask,DataObject dispatchFIInputMQRq){
	try {
		
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject	ReqExeInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ReqExeInfo");
		DataObject	ReqInqInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ReqInqInfo");
		
		LogUtilities.logObject("currentExtrSrvcTask <<<< preparePostActionDispatchFIRqData", currentExtrSrvcTask,OperationNamesEnum.BLOCKSERVICE.code);
		LogUtilities.logObject("dispatchFIInputMQRq <<<< preparePostActionDispatchFIRqData", dispatchFIInputMQRq,OperationNamesEnum.BLOCKSERVICE.code);
		DataObject FISmryInfo = currentExtrSrvcTask.getDataObject("FISmryInfo");
		DataObject AcctsSmryInfo = FISmryInfo.getDataObject("AcctsSmryInfo");
		DataObject DepotsSmryInfo = FISmryInfo.getDataObject("DepotsSmryInfo");
		DataObject SafsSmryInfo = FISmryInfo.getDataObject("SafsSmryInfo");
		ReqExeInfo.setString("Accts",AcctsSmryInfo.getString("hasAccts"));
		
		if(currentExtrSrvcTask.getBigDecimal("ovr_amt").compareTo(new BigDecimal(0))>0){
			if(DepotsSmryInfo!=null){
				ReqExeInfo.setString("Depots",DepotsSmryInfo.getString("hasDepots"));
				ReqInqInfo.setString("JntDepots",DepotsSmryInfo.getString("hasJntDepots"));
			}else{
				ReqExeInfo.setString("Depots","n");
				ReqInqInfo.setString("JntDepots","n");
			}
			if(SafsSmryInfo!=null){
				ReqExeInfo.setString("Safs",SafsSmryInfo.getString("hasSafs"));
			}else{
				ReqExeInfo.setString("Safs","n");
			}
			ReqInqInfo.setString("JntAccts",AcctsSmryInfo.getString("hasJntAccts"));
			ReqInqInfo.setString("Shrs","y");
			
			
			//dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").setBigDecimal("Val", currentExtrSrvcTask.getBigDecimal("ovr_amt"));
			// set pendingAmt AS IS
			dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").setBigDecimal("PndngAmt",currentExtrSrvcTask.getBigDecimal("ovr_amt"));
		}else{
			if (dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds") != null){
				dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").setString("Depots", null);
				dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").setString("Safs", null);
			}
			
			// set ReqExeInfo [Depost - Safs] >> n
			ReqExeInfo.setString("Depots","n");
			ReqExeInfo.setString("Safs","n");
			
			// set ReqExeInfo [JntAccts - JntDepots - Shrs] >> n
			ReqInqInfo = null;
//			ReqInqInfo.setString("JntAccts","n");
//			ReqInqInfo.setString("JntDepots","n");
//			ReqInqInfo.setString("Shrs","n");
			
			// set target amount to be blockedAmt + pendingAmt
//			dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").setBigDecimal("Val", currentExtrSrvcTask.getBigDecimal("blocked_amt").add(currentExtrSrvcTask.getBigDecimal("ovr_amt")));
			dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").setBigDecimal("Val", currentExtrSrvcTask.getBigDecimal("ovr_amt").negate());
			// set pendingAmt = 0
			dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").setBigDecimal("PndngAmt",new BigDecimal(0));
		}
		dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").setDataObject("ReqExeInfo",ReqExeInfo);
		dispatchFIInputMQRq.getDataObject("FIBlockRq").getDataObject("Outline").setDataObject("ReqInqInfo",ReqInqInfo);
	} catch (Exception e) {
		e.printStackTrace();
	}
		return dispatchFIInputMQRq;
	}
	
	public static DataObject appendToExtrTskList(DataObject extrTskList,DataObject extrSrvcTask){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		if(extrTskList==null){
			extrTskList = factory.create("http://BEA-Solution_Library/DBServices/Common","InsertFIRqstsRq");
		List lst = new ArrayList();
		lst.add(extrSrvcTask);
		extrTskList.setList("exetr_srvc_task",lst);
		}
		else{
			extrTskList.getList("exetr_srvc_task").add(extrSrvcTask);
		}
		return extrTskList;
	}
		
	
	public static DataObject prepareGarnishExecAndInqInfo(DataObject dispatchFIGarnishInputRq,DataObject dispatchFIGarnishInputMQRq, DataObject garnishQueryTypeConst, DataObject currentExtrSrvcTask, String queryType){
		try {
			
		
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		String garnishOpCode = OperationNamesEnum.GARNISHSERVICE.code;
		DataObject ReqExeInfo;
		DataObject ReqInqInfo;
		
//		LogUtilities.logObject("..... Utilities 1st - prepareGarnishExecAndInqInfo >>> dispatchFIGarnishInputMQRq ....", dispatchFIGarnishInputMQRq, garnishOpCode);
//		LogUtilities.logObject("..... Utilities 1st - prepareGarnishExecAndInqInfo >>> currentExtrSrvcTask ....", currentExtrSrvcTask, garnishOpCode);
		if(dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ReqExeInfo") ==null){
			ReqExeInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ReqExeInfo");
		}else{
			ReqExeInfo = dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ReqExeInfo");
		}	
		
		if(dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ReqInqInfo") ==null){
			ReqInqInfo = factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ReqInqInfo");
		}else{
			ReqInqInfo = dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ReqInqInfo");
		}		
//		//default exec Info
		ReqExeInfo.setString("Accts","n");
		ReqExeInfo.setString("Depots", "n");
		ReqExeInfo.setString("Safs", "n");
//		
//		//InqInfo
//		ReqInqInfo.setString("JntAccts", "n");
//		ReqInqInfo.setString("JntDepots", "n");
//		ReqInqInfo.setString("Shrs", "n");
		
		// Account case
		if( queryType.equals(garnishQueryTypeConst.getString("QT_ACC_ONLY")) ||
				queryType.equals(garnishQueryTypeConst.getString("QT_ACC_AMT")) ||
				queryType.equals(garnishQueryTypeConst.getString("QT_ID_ACC")) ||
				queryType.equals(garnishQueryTypeConst.getString("QT_ID_ACC_AMT")) ||
				queryType.equals(garnishQueryTypeConst.getString("QT_ACC_ONLY"))
			){
				ReqExeInfo.setString("Accts", "y");
				ReqExeInfo.setString("Depots", "n");	
				ReqExeInfo.setString("Safs", "n");	
				
				ReqInqInfo.setString("JntAccts", "n");
				ReqInqInfo.setString("JntDepots", "n");
				ReqInqInfo.setString("Shrs", "n");
			}
		
		//Involved party only case
		if(queryType.equals(garnishQueryTypeConst.getString("QT_ID_ONLY")))
		{ 
			ReqExeInfo.setString("Accts", "y");
			ReqExeInfo.setString("Depots", "n");	
			ReqExeInfo.setString("Safs", "n");	

			ReqInqInfo.setString("JntAccts", "y");
			ReqInqInfo.setString("JntDepots", "n");
			ReqInqInfo.setString("Shrs", "y");

			if(dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan") != null )
			{
				if(dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds") != null)
				{			
					
					//Set Depost if exists in TargetProd
					if(dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").getString("Depots") != null )
					{
							if(!dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").getString("Depots").equals(""))
							{
								ReqExeInfo.setString("Depots", "y");	
								ReqInqInfo.setString("JntDepots", "y");

							}
					}
					
					//Set Safs if exists in TargetProd
					if(dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").getString("Safs") != null )
					{
							if(!dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").getString("Safs").equals(""))
							{
								ReqExeInfo.setString("Safs", "y");	
							}
					}
				}
			}		
			
			// Set All InqInfo 
			
		}
		
		
		
		
		// InvParty + Amount case
		if(queryType.equals(garnishQueryTypeConst.getString("QT_ID_AMT")) &&currentExtrSrvcTask.getString("task_mode")!= null && currentExtrSrvcTask.getString("task_mode").equals(BlockModeConst.OVERRIDE.code)){
			DataObject FISmryInfo = currentExtrSrvcTask.getDataObject("FISmryInfo");
			DataObject AcctsSmryInfo = FISmryInfo.getDataObject("AcctsSmryInfo");
			DataObject DepotsSmryInfo = FISmryInfo.getDataObject("DepotsSmryInfo");
			DataObject SafsSmryInfo = FISmryInfo.getDataObject("SafsSmryInfo");
			// insuffecient
			if(currentExtrSrvcTask.getBigDecimal("ovr_amt").compareTo(new BigDecimal(0))>0)
			{
				
				// exec/Inq account
				if(AcctsSmryInfo != null){
					//dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").setString("Accts",AcctsSmryInfo.getString("hasAccts"));
					ReqExeInfo.setString("Accts",AcctsSmryInfo.getString("hasAccts"));
					ReqInqInfo.setString("JntAccts", AcctsSmryInfo.getString("hasJntAccts"));
				}else{
					ReqExeInfo.setString("Accts","n");
					ReqInqInfo.setString("JntAccts", "n");
				}
				// exec/Inq deposit 
				if(DepotsSmryInfo != null){
					//dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").setString("Depots",DepotsSmryInfo.getString("hasDepots"));
					ReqExeInfo.setString("Depots", DepotsSmryInfo.getString("hasDepots"));
					ReqInqInfo.setString("JntDepots", DepotsSmryInfo.getString("hasJntDepots"));
				}else{
					ReqExeInfo.setString("Depots", "n");	
					ReqInqInfo.setString("JntDepots", "n");
				}
				//exec safs
				if(SafsSmryInfo != null){
					//dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").setString("Safs",SafsSmryInfo.getString("hasSafs"));
					ReqExeInfo.setString("Safs", SafsSmryInfo.getString("hasSafs"));
				}else{
					ReqExeInfo.setString("Safs", "n");
				}
				
				// shares
				ReqInqInfo.setString("Shrs", "y");
				
				
//				DataObject tmpAmt = dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt");
//				dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").setDataObject("Amt",tmpAmt);
//				if(dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt") == null){
//					DataObject AmtBO = factory.create("http://www.sama.bea.sa/common/BaseLib","T_Amt");
//					dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").setDataObject("Amt", AmtBO);
//				}
				//set pnding
				dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").setBigDecimal("PndngAmt",currentExtrSrvcTask.getBigDecimal("ovr_amt"));
			}
			// suffecient
			else{
				// set target_prd null if amount suffecient
				if (dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds") != null){
					dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").setString("Depots", null);
					dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds").setString("Safs", null);
				}
				//exec Info
				ReqExeInfo.setString("Accts","y");
				ReqExeInfo.setString("Depots", "n");
				ReqExeInfo.setString("Safs", "n");
				
				//InqInfo
				ReqInqInfo = null;
//				ReqInqInfo.setString("JntAccts", "n");
//				ReqInqInfo.setString("JntDepots", "n");
//				ReqInqInfo.setString("Shrs", "n");
				
				// set target amount to be blockedAmt + pendingAmt
				
				
				
				DataObject tmpAmt = dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt");
				dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").setDataObject("Amt",tmpAmt);
				if(dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt") == null){
					DataObject AmtBO = factory.create("http://www.sama.bea.sa/common/BaseLib","T_Amt");
					dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").setDataObject("Amt", AmtBO);
				}
//				dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").setBigDecimal("Val", currentExtrSrvcTask.getBigDecimal("blocked_amt").add(currentExtrSrvcTask.getBigDecimal("ovr_amt")));
				dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").setBigDecimal("Val", currentExtrSrvcTask.getBigDecimal("ovr_amt").negate());
				// set pendingAmt = 0
				dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").setBigDecimal("PndngAmt",new BigDecimal(0));
				
			}
				
			
		}else if(queryType.equals(garnishQueryTypeConst.getString("QT_ID_AMT")) &&currentExtrSrvcTask.getString("task_mode")== null)
		{
			ReqExeInfo = null;
			ReqInqInfo = null;
		}
		
		dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").setDataObject("ReqExeInfo", ReqExeInfo);
		dispatchFIGarnishInputMQRq.getDataObject("FIGarnishRq").getDataObject("Outline").setDataObject("ReqInqInfo", ReqInqInfo);
		LogUtilities.logObject("..... Utilities 2nd - prepareGarnishExecAndInqInfo >>> dispatchFIGarnishInputMQRq ....", dispatchFIGarnishInputMQRq, garnishOpCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dispatchFIGarnishInputMQRq;
	}
		

	
	public static DataObject retrievGIExecSum(String xmlInput){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject fi_gi_summary_validation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_gi_summary_validation","Fi_Gi_Summary_Validation");
		
		try{
		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    InputSource is = new InputSource();
	    is.setCharacterStream(new StringReader(xmlInput));
	    Document doc = db.parse(is);
	    NodeList nodes = doc.getElementsByTagName("fi_gi_summary_validation");
   
	    
	        Element element = (Element) nodes.item(0);
	        
	        NodeList fi_gi_summary_validation_id = element.getElementsByTagName("fi_gi_summary_validation_id");
	        if(fi_gi_summary_validation_id!=null)
	        {
	        Element fi_gi_summary_validation_idValue = (Element) fi_gi_summary_validation_id.item(0);
	        fi_gi_summary_validation.setString("fi_gi_summary_validation_id",getCharacterDataFromElement( fi_gi_summary_validation_idValue));
	        }
	       
	        NodeList msg_uid = element.getElementsByTagName("msg_uid");
	        if(msg_uid!=null){
	        Element msg_uidValue = (Element) msg_uid.item(0);
	        fi_gi_summary_validation.setString("msg_uid",getCharacterDataFromElement( msg_uidValue));
	        }
	       
	     
	        
	       NodeList fi_code = element.getElementsByTagName("fi_code");
	       if(fi_code!=null)
	       {
	        Element fi_codeValue = (Element) fi_code.item(0);
	        fi_gi_summary_validation.setString("fi_code",getCharacterDataFromElement( fi_codeValue));
 
	       }
	       
	        NodeList trans_date = element.getElementsByTagName("trans_date");
	       if(trans_date!=null)
	       {
	        Element trans_dateValue = (Element) trans_date.item(0);
	        fi_gi_summary_validation.setString("trans_date",getCharacterDataFromElement( trans_dateValue));
    
	       }	        
	       
	        
	        NodeList is_involved_party = element.getElementsByTagName("is_involved_party");
	       if(is_involved_party!=null)
	       {
	        Element is_involved_partyValue = (Element) is_involved_party.item(0);
	        fi_gi_summary_validation.setString("is_involved_party",getCharacterDataFromElement( is_involved_partyValue));
	       }
	        
	        NodeList is_acc_id = element.getElementsByTagName("is_acc_id");
	       if(is_acc_id!=null)
	       {
	        Element is_acc_idValue = (Element) is_acc_id.item(0);
	        fi_gi_summary_validation.setString("is_acc_id",getCharacterDataFromElement( is_acc_idValue));
	       }
	       
	        NodeList involved_party_id = element.getElementsByTagName("involved_party_id");
	       if(involved_party_id!=null)
	       {
	        Element involved_party_idValue = (Element) involved_party_id.item(0);
	        fi_gi_summary_validation.setString("involved_party_id",getCharacterDataFromElement( involved_party_idValue));

	       }
	        
	        NodeList involved_party_id_type = element.getElementsByTagName("involved_party_id_type");
	      
	        if(involved_party_id_type!=null){
	        Element involved_party_id_typeValue = (Element) involved_party_id_type.item(0);
	        fi_gi_summary_validation.setString("involved_party_id_type",getCharacterDataFromElement( involved_party_id_typeValue));
	        }
	        
	        
	        NodeList nat_cd = element.getElementsByTagName("nat_cd");
	        if(nat_cd!=null){
	        Element nat_cdValue = (Element) nat_cd.item(0);
	        fi_gi_summary_validation.setString("nat_cd",getCharacterDataFromElement( nat_cdValue));
	        }
	        
	      //acc_qry
	        

	        NodeList acc_qry = element.getElementsByTagName("acc_qry");
	        if(acc_qry!=null)
	        {
	        Element acc_qryValue = (Element) acc_qry.item(0);
	        fi_gi_summary_validation.setString("acc_qry",getCharacterDataFromElement( acc_qryValue));

	        }
	        
	        // is_iban
	        NodeList is_iban = element.getElementsByTagName("is_iban");
	        if(is_iban!=null)
	        {
	        Element is_ibanValue = (Element) is_iban.item(0);
	        fi_gi_summary_validation.setString("is_iban",getCharacterDataFromElement( is_ibanValue));

	        }
	        
	        // involved_party_type
	        NodeList involved_party_type = element.getElementsByTagName("involved_party_type");
	        if(involved_party_type!=null)
	        {
	        Element involved_party_typeValue = (Element) involved_party_type.item(0);
	        fi_gi_summary_validation.setString("involved_party_type",getCharacterDataFromElement( involved_party_typeValue));

	        }

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	        
	      return fi_gi_summary_validation  ;
	      
		}

	public static DataObject retrievBlockSummaryValidation(String xmlInput){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject fi_Block_Summary_Validation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_block_summary_validation","Fi_Block_Summary_Validation");
		
		try{
		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    InputSource is = new InputSource();
	    is.setCharacterStream(new StringReader(xmlInput));
	    Document doc = db.parse(is);
	    NodeList nodes = doc.getElementsByTagName("fi_Block_Summary_Validation");
   
	    
	        Element element = (Element) nodes.item(0);
	        
	        NodeList fi_block_summary_validation_id = element.getElementsByTagName("fi_block_summary_validation_id");
	        if(fi_block_summary_validation_id!=null)
	        {
	        Element fi_block_summary_validation_idValue = (Element) fi_block_summary_validation_id.item(0);
	        fi_Block_Summary_Validation.setString("fi_block_summary_validation_id",getCharacterDataFromElement( fi_block_summary_validation_idValue));
	        }
	       
	        NodeList msg_uid = element.getElementsByTagName("msg_uid");
	        if(msg_uid!=null){
	        Element msg_uidValue = (Element) msg_uid.item(0);
	        fi_Block_Summary_Validation.setString("msg_uid",getCharacterDataFromElement( msg_uidValue));
	        }
	       
	        NodeList msg_mode = element.getElementsByTagName("msg_mode");
	        if(msg_mode!=null)
	        {
	        Element msg_modeValue = (Element) msg_mode.item(0);
	        fi_Block_Summary_Validation.setString("msg_mode",getCharacterDataFromElement( msg_modeValue));
	        }
	        
	       NodeList fi_code = element.getElementsByTagName("fi_code");
	       if(fi_code!=null)
	       {
	        Element fi_codeValue = (Element) fi_code.item(0);
	        fi_Block_Summary_Validation.setString("fi_code",getCharacterDataFromElement( fi_codeValue));
 
	       }
	       
	        NodeList trans_date = element.getElementsByTagName("trans_date");
	       if(trans_date!=null)
	       {
	        Element trans_dateValue = (Element) trans_date.item(0);
	        fi_Block_Summary_Validation.setString("trans_date",getCharacterDataFromElement( trans_dateValue));
    
	       }	        
	       
	        
	        NodeList is_involved_party = element.getElementsByTagName("is_involved_party");
	       if(is_involved_party!=null)
	       {
	        Element is_involved_partyValue = (Element) is_involved_party.item(0);
	        fi_Block_Summary_Validation.setString("is_involved_party",getCharacterDataFromElement( is_involved_partyValue));
	       }
	        
	        NodeList is_acc_id = element.getElementsByTagName("is_acc_id");
	       if(is_acc_id!=null)
	       {
	        Element is_acc_idValue = (Element) is_acc_id.item(0);
	        fi_Block_Summary_Validation.setString("is_acc_id",getCharacterDataFromElement( is_acc_idValue));
	       }
	       
	        NodeList involved_party_id = element.getElementsByTagName("involved_party_id");
	       if(involved_party_id!=null)
	       {
	        Element involved_party_idValue = (Element) involved_party_id.item(0);
	        fi_Block_Summary_Validation.setString("involved_party_id",getCharacterDataFromElement( involved_party_idValue));

	       }
	        
	        NodeList involved_party_id_type = element.getElementsByTagName("involved_party_id_type");
	      
	        if(involved_party_id_type!=null){
	        Element involved_party_id_typeValue = (Element) involved_party_id_type.item(0);
	        fi_Block_Summary_Validation.setString("involved_party_id_type",getCharacterDataFromElement( involved_party_id_typeValue));
	        }
	        
	        
	        NodeList nat_cd = element.getElementsByTagName("nat_cd");
	        if(nat_cd!=null){
	        Element nat_cdValue = (Element) nat_cd.item(0);
	        fi_Block_Summary_Validation.setString("nat_cd",getCharacterDataFromElement( nat_cdValue));
	        }
	        
	        NodeList amt_val = element.getElementsByTagName("amt_val");
	       if(amt_val!=null){
	        Element amt_valValue = (Element) amt_val.item(0);
	        
	        fi_Block_Summary_Validation.setString("amt_val",getCharacterDataFromElement( amt_valValue));

	        
	       }//acc_num
	        NodeList amr_cur = element.getElementsByTagName("amr_cur");
	        if(amr_cur!=null)
	        {
	        Element amr_curValue = (Element) amr_cur.item(0);
	        fi_Block_Summary_Validation.setString("amr_cur",getCharacterDataFromElement( amr_curValue));

	        }

	        NodeList acc_num = element.getElementsByTagName("acc_num");
	        if(acc_num!=null)
	        {
	        Element acc_numValue = (Element) acc_num.item(0);
	        fi_Block_Summary_Validation.setString("acc_num",getCharacterDataFromElement( acc_numValue));

	        }

		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	        
	      return fi_Block_Summary_Validation  ;
	      
		}
	public static DataObject retrievPrevLiftData(String xmlInput){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject prevblockData = factory.create("http://BEA_Solution_Lift_Module/ProcessLib/ValidateRPInput","PrevBlockData");

		try{
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xmlInput));
			Document doc = db.parse(is);
			NodeList nodes = doc.getElementsByTagName("PrevBlockData");


			Element element = (Element) nodes.item(0);

			NodeList exec_running_totals_id = element.getElementsByTagName("exec_running_totals_id");
			if(exec_running_totals_id!=null)
			{
				Element exec_running_totals_idValue = (Element) exec_running_totals_id.item(0);
				prevblockData.setString("exec_running_totals_id",getCharacterDataFromElement( exec_running_totals_idValue));
			}

			NodeList exec_summary_id = element.getElementsByTagName("exec_summary_id");
			if(exec_summary_id!=null){
				Element exec_summary_idValue = (Element) exec_summary_id.item(0);
				prevblockData.setString("exec_summary_id",getCharacterDataFromElement( exec_summary_idValue));
			}

			NodeList fin_inst_cd = element.getElementsByTagName("fin_inst_cd");
			if(fin_inst_cd!=null)
			{
				Element fin_inst_cdValue = (Element) fin_inst_cd.item(0);
				prevblockData.setString("fin_inst_cd",getCharacterDataFromElement( fin_inst_cdValue));
			}

			NodeList acc_num = element.getElementsByTagName("acc_num");
			if(acc_num!=null)
			{
				Element acc_numValue = (Element) acc_num.item(0);
				prevblockData.setString("acc_num",getCharacterDataFromElement( acc_numValue));

			}

			NodeList acc_currency = element.getElementsByTagName("acc_currency");
			if(acc_currency!=null)
			{
				Element acc_currencyValue = (Element) acc_currency.item(0);
				prevblockData.setString("acc_currency",getCharacterDataFromElement( acc_currencyValue));

			}	        

			LogUtilities.logObject("prevblockDatammmmmmmmmmmmm", prevblockData, OperationNamesEnum.LIFTSERVICE.code);

			NodeList available_amt = element.getElementsByTagName("available_amt");
			if(available_amt!=null)
			{
				Element available_amtValue = (Element) available_amt.item(0);
				prevblockData.setString("available_amt",getCharacterDataFromElement( available_amtValue));
			}
			LogUtilities.logObject("prevblockDatammmmmmmmmmmmm", prevblockData, OperationNamesEnum.LIFTSERVICE.code);

			NodeList creation_date = element.getElementsByTagName("creation_date");
			if(creation_date!=null)
			{
				Element creation_dateValue = (Element) creation_date.item(0);
				prevblockData.setString("creation_date",getCharacterDataFromElement( creation_dateValue));
			}
			LogUtilities.logObject("prevblockDatammmmmmmmmmmmm", prevblockData, OperationNamesEnum.LIFTSERVICE.code);


			NodeList srvcCode = element.getElementsByTagName("srvcCode");
			if(srvcCode!=null)
			{
				Element srvcCodeValue = (Element) srvcCode.item(0);
				prevblockData.setString("srvcCode",getCharacterDataFromElement( srvcCodeValue));

			}
			LogUtilities.logObject("prevblockDatammmmmmmmmmmmm", prevblockData, OperationNamesEnum.LIFTSERVICE.code);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage()); ;
		}

		return prevblockData  ;

	}

	
		// trial	
	public static List retrieveCommonMoreInfoParser(String xmlInput){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject t_Attributes = factory.create("http://BEA-Solution_Library/DBServices/BO","Attribute");
		
		List result = new ArrayList();
		try{
		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    InputSource is = new InputSource();
	    is.setCharacterStream(new StringReader(xmlInput));
	    Document doc = db.parse(is);
	    NodeList nodes = doc.getElementsByTagName("Attribute");
	    
		LogUtilities.logUtil("************** xmlInput **************" + xmlInput, OperationNamesEnum.COMMONSHSERVICE.code);

	    
	    for (int i = 0; i < nodes.getLength(); i++) {
	    	t_Attributes = factory.create("http://BEA-Solution_Library/DBServices/BO","Attribute");
	        Element element = (Element) nodes.item(i);
	        
	        NodeList value = element.getElementsByTagName("Value");
	        Element valueLine = (Element) value.item(0);
	        
	        NodeList name = element.getElementsByTagName("Name");
	        Element nameLine = (Element) name.item(0);
	        
	        t_Attributes.setString("Name", getCharacterDataFromElement(nameLine));
	        t_Attributes.setString("Value", getCharacterDataFromElement(valueLine));
	        
	        result.add(t_Attributes);
	        
			LogUtilities.logUtil("************** Attribute Index ************** "+ i +  "    t_Attributes    "+ t_Attributes.getString("Name")  , OperationNamesEnum.COMMONSHSERVICE.code);     
	      }
	    
		LogUtilities.logUtil("************** result **************"+ result.size(), OperationNamesEnum.COMMONSHSERVICE.code);

	    
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	
	public static String getCharacterDataFromElement(Element e) {
	  try{
		Node child = e.getFirstChild();
	    if (child instanceof CharacterData) {
	      CharacterData cd = (CharacterData) child;
	      return cd.getData();
	    }
	    return "";
	// trial}
	  }
	  catch(Exception ee)
	  {
		  
		  LogUtilities.logUtil(ee.getMessage());
		  return null;
	  }
	
	
	}
	
	private static boolean checkExistFICodeResponse(List FIRsBlock_list,String fiCode){
		boolean result = false;
		for(int i=0;i<FIRsBlock_list.size();i++){
			if(((DataObject)FIRsBlock_list.get(i)).getString("FICode").equals(fiCode)){
				result = true;
				break;
			}
		}
		
		return result;
	}
	
	
	private static List checkExistFICodeResponseThenRemove(List responses,String fiCode){
		try {
			for (int i = 0; i < responses.size(); i++) {
				if (((DataObject) responses.get(i)).getDataObject("rsHdr") != null	&& ((DataObject) responses.get(i)).getDataObject("rsHdr").getString("PID").equals(fiCode)) {
					responses.remove(i);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responses;
	}
	public static List appendToAutoLiftLst(List autoLftLst,String fiCode,int amt){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject autoLftData = factory.create("http://BEA-Solution_Library/ProcessLib/Lift","AutoLiftData");
		autoLftData.setString("FICode",fiCode);
		autoLftData.setInt("lftAmt",amt);
		if(autoLftLst==null)
			autoLftLst = new ArrayList<>();

		autoLftLst.add(autoLftData);
		return autoLftLst;
	}
	
	// build ack reply from Portal Partners
	public static DataObject prepareAckgRs(String SRN,String PID,String CRN){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject receiveFIBlockReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Block","ReceiveFIBlockReplyRq");
		DataObject rsHdr = factory.create("http://www.sama.bea.sa/common/Header","T_RsHdr");
		rsHdr.setString("PID",PID);
		rsHdr.setString("Status","S1100000");
		rsHdr.setString("SRN",SRN);
		rsHdr.setString("CRN",CRN);
		receiveFIBlockReplyRq.setDataObject("rsHdr", rsHdr);
		receiveFIBlockReplyRq.setString("instanceId",SRN);
		return receiveFIBlockReplyRq;
	}
	// build ack reply from Portal Partners
		public static DataObject prepareGarnishAckgRs(String SRN,String PID,String CRN){
			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			DataObject receiveFIBlockReplyRq = factory.create("http://BEA-Solution_Library/ProcessLib/Garnish","ReceiveFIGarnishReplyRq");
			DataObject rsHdr = factory.create("http://www.sama.bea.sa/common/Header","T_RsHdr");
			rsHdr.setString("PID",PID);
			rsHdr.setString("Status","S1100000");
			rsHdr.setString("SRN",SRN);
			rsHdr.setString("CRN",CRN);
			receiveFIBlockReplyRq.setDataObject("rsHdr", rsHdr);
			receiveFIBlockReplyRq.setString("instanceId",SRN);
			return receiveFIBlockReplyRq;
		}
	
		public static DataObject prepareFIBlockSummaryValidation(DataObject currentExtrSrvcTask,DataObject dispatchFIBlockInputRq,DataObject insertFISummaryValidation,DataObject blockQueryTypeConst){
			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			DataObject fiBlockSummaryValidation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_block_summary_validation","Fi_Block_Summary_Validation");
			String queryType = dispatchFIBlockInputRq.getDataObject("BlockInternalData").getString("blockQueryType");
//			LogUtilities.logObject("currentExtrSrvcTask", currentExtrSrvcTask, OperationNamesEnum.BLOCKSERVICE.code);
//			LogUtilities.logObject("dispatchFIBlockInputRq", dispatchFIBlockInputRq, OperationNamesEnum.BLOCKSERVICE.code);
//			LogUtilities.logObject("insertFISummaryValidation", insertFISummaryValidation, OperationNamesEnum.BLOCKSERVICE.code);
			String id = dispatchFIBlockInputRq.getDataObject("BlockInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("id");
			String idType = dispatchFIBlockInputRq.getDataObject("BlockInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("idType");
			String IndvParty=dispatchFIBlockInputRq.getDataObject("BlockInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType");
			String nationality="";
			if(dispatchFIBlockInputRq.getDataObject("BlockInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality")!=null)
			{
				 nationality = dispatchFIBlockInputRq.getDataObject("BlockInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality");
			}
			String currency = dispatchFIBlockInputRq.getDataObject("RPBlockRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").getString("Cur");
			fiBlockSummaryValidation.setString("msg_uid",currentExtrSrvcTask.getString("exetr_ref_no"));
			fiBlockSummaryValidation.setString("msg_mode",currentExtrSrvcTask.getString("task_mode"));
			fiBlockSummaryValidation.setString("fi_code",currentExtrSrvcTask.getString("fin_inst_cd"));
			fiBlockSummaryValidation.setString("trans_date",KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss"));
			if(queryType.equals(blockQueryTypeConst.getString("ID_AMT_ACC"))){
				fiBlockSummaryValidation.setString("is_acc_id","y");
				fiBlockSummaryValidation.setString("acc_num",dispatchFIBlockInputRq.getDataObject("RPBlockRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("AccId").getString("Num"));
				String isIban = dispatchFIBlockInputRq.getDataObject("RPBlockRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("AccId").getString("IBAN");
				fiBlockSummaryValidation.setString("is_iban",isIban);
			}
			else{
				fiBlockSummaryValidation.setString("is_acc_id","n");
			}
			
			fiBlockSummaryValidation.setString("involved_party_id",id);
			fiBlockSummaryValidation.setString("involved_party_id_type",idType);
			fiBlockSummaryValidation.setString("involved_party_type",IndvParty);

			fiBlockSummaryValidation.setString("nat_cd",nationality);
			fiBlockSummaryValidation.setBigDecimal("trgt_amt_val",dispatchFIBlockInputRq.getDataObject("RPBlockRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").getBigDecimal("Val"));
			
			fiBlockSummaryValidation.setString("trgt_amt_cur",currency);
			if(queryType.equals(blockQueryTypeConst.getString("ID_AMT_ACC"))){
				if(currentExtrSrvcTask.getString("task_mode")!= null && currentExtrSrvcTask.getString("task_mode").equals(BlockModeConst.OVERRIDE.code)){
					fiBlockSummaryValidation.setBigDecimal("pending_amt",currentExtrSrvcTask.getBigDecimal("ovr_amt"));
					fiBlockSummaryValidation.setBigDecimal("blocked_amt",currentExtrSrvcTask.getBigDecimal("blocked_amt"));
					if(currentExtrSrvcTask.getDataObject("FISmryInfo")!=null&&currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals")!=null){
					fiBlockSummaryValidation.setBigDecimal("sar_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtSAR"));
					fiBlockSummaryValidation.setBigDecimal("rq_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtRqCur"));
					}
				}
				fiBlockSummaryValidation.setString("trgt_acc_prd","y");
				fiBlockSummaryValidation.setString("exe_acc_flag","y");
			}else{
				DataObject target_prds = dispatchFIBlockInputRq.getDataObject("RPBlockRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds");
				if(currentExtrSrvcTask.getString("task_mode")!= null && currentExtrSrvcTask.getString("task_mode").equals(BlockModeConst.OVERRIDE.code)){
					DataObject FISmryInfo = currentExtrSrvcTask.getDataObject("FISmryInfo");
					DataObject AcctsSmryInfo = FISmryInfo.getDataObject("AcctsSmryInfo");
					DataObject DepotsSmryInfo = FISmryInfo.getDataObject("DepotsSmryInfo");
					DataObject SafsSmryInfo = FISmryInfo.getDataObject("SafsSmryInfo");
					fiBlockSummaryValidation.setString("trgt_acc_prd","y");
					fiBlockSummaryValidation.setString("exe_acc_flag",(AcctsSmryInfo.getString("hasAccts").equals("y")?"y":null));
					if(currentExtrSrvcTask.getBigDecimal("ovr_amt").compareTo(new BigDecimal(0))>0){
						if(DepotsSmryInfo!=null){
							fiBlockSummaryValidation.setString("exe_depost_flag",(DepotsSmryInfo.getString("hasDepots").equals("y")? "y":null));
							fiBlockSummaryValidation.setString("info_jnt_depost_flag",(DepotsSmryInfo.getString("hasJntDepots").equals("y")?"y":null));
						}
						if(SafsSmryInfo!=null){
							fiBlockSummaryValidation.setString("exe_safs_flag",(SafsSmryInfo.getString("hasSafs").equals("y")?"y":null));
						}
						fiBlockSummaryValidation.setString("info_jnt_acc_flag",(AcctsSmryInfo.getString("hasJntAccts").equals("y")?"y":null));
						
						fiBlockSummaryValidation.setString("info_shrs_flag","y");
						fiBlockSummaryValidation.setString("trgt_safs_prd",((target_prds.getString("Safs")!=null&&target_prds.getString("Safs").equals("y"))?"y":null));
						fiBlockSummaryValidation.setString("trgt_depost_prd",((target_prds.getString("Depots")!=null&&target_prds.getString("Depots").equals("y"))?"y":null));
						
						fiBlockSummaryValidation.setBigDecimal("blocked_amt",currentExtrSrvcTask.getBigDecimal("blocked_amt"));
						fiBlockSummaryValidation.setBigDecimal("pending_amt",currentExtrSrvcTask.getBigDecimal("ovr_amt"));
						if(currentExtrSrvcTask.getDataObject("FISmryInfo")!=null&&currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals")!=null){
					fiBlockSummaryValidation.setBigDecimal("sar_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtSAR"));
					fiBlockSummaryValidation.setBigDecimal("rq_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtRqCur"));
						}
						}else{
						fiBlockSummaryValidation.setString("trgt_safs_prd",null);
						fiBlockSummaryValidation.setString("trgt_depost_prd",null);
						//fiBlockSummaryValidation.setBigDecimal("blocked_amt",currentExtrSrvcTask.getBigDecimal("blocked_amt").add(currentExtrSrvcTask.getBigDecimal("ovr_amt")));
						fiBlockSummaryValidation.setBigDecimal("blocked_amt",currentExtrSrvcTask.getBigDecimal("ovr_amt").negate());
						fiBlockSummaryValidation.setBigDecimal("pending_amt",new BigDecimal(0));
						if(currentExtrSrvcTask.getDataObject("FISmryInfo")!=null&&currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals")!=null){
						fiBlockSummaryValidation.setBigDecimal("sar_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtSAR"));
						fiBlockSummaryValidation.setBigDecimal("rq_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtRqCur"));
						}
						
					}
					
					//fiBlockSummaryValidation.setBigDecimal("blocked_amt",currentExtrSrvcTask.getBigDecimal("blocked_amt"));
				}
				else{
					fiBlockSummaryValidation.setString("trgt_acc_prd","y");
					fiBlockSummaryValidation.setString("trgt_depost_prd",((target_prds.getString("Depots")!=null&&target_prds.getString("Depots").equals("y"))?"y":null));
					fiBlockSummaryValidation.setString("trgt_safs_prd",((target_prds.getString("Safs")!=null&&target_prds.getString("Safs").equals("y"))?"y":null));
				}
			}
			// append to list
			if (insertFISummaryValidation == null) {
				insertFISummaryValidation = factory.create("http://BEA_Solution_Block_Module/ProcessLib/DispatchFIInput","InsertFISummaryValidation");
				List lst = new ArrayList();
				lst.add(fiBlockSummaryValidation);
				insertFISummaryValidation.setList("fi_Block_Summary_Validation", lst);
			} else {
				insertFISummaryValidation.getList("fi_Block_Summary_Validation").add(fiBlockSummaryValidation);
			}
			
			return insertFISummaryValidation;
		}		
	
	

	
	
	
	
	
	public static DataObject prepareFIDenySummaryValidation(DataObject currentExtrSrvcTask, DataObject dispatchFIDenyInput,DataObject insertFISummaryValidation) 
	{
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			DataObject fiDenySummaryValidation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_deny_summary_validation","Fi_Deny_Summary_Validation");
			String id, idType, nationality, invPartyType;
			id = dispatchFIDenyInput.getDataObject("denyInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("id");
			idType = dispatchFIDenyInput.getDataObject("denyInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("idType");
			invPartyType = dispatchFIDenyInput.getDataObject("denyInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType");
			if (dispatchFIDenyInput.getDataObject("denyInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality") != null) 
			{
				nationality = dispatchFIDenyInput.getDataObject("denyInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality");
				LogUtilities.logUtil("CATCH_nationality", nationality,OperationNamesEnum.DENYSERVICE.code);
				fiDenySummaryValidation.setString("nat_cd", nationality);
			}
			LogUtilities.logUtil("ID"+ id,OperationNamesEnum.DENYSERVICE.code);
			LogUtilities.logUtil("IDTYPE"+ idType,OperationNamesEnum.DENYSERVICE.code);
			LogUtilities.logUtil("invPartyType"+invPartyType, OperationNamesEnum.DENYSERVICE.code);	
			// int amt = dispatchFIDenyInput.getDataObject("RPDenyDlngRq").getDataObject("DcsnInfo").getDataObject("Amt").getInt("Val");
			// String currency = dispatchFIBlockInputRq.getDataObject("RPBlockRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").getString("Cur");
			fiDenySummaryValidation.setString("msg_uid", currentExtrSrvcTask.getString("exetr_ref_no"));
			fiDenySummaryValidation.setString("fi_code",currentExtrSrvcTask.getString("fin_inst_cd"));
			fiDenySummaryValidation.setString("trans_date",KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss"));

			fiDenySummaryValidation.setString("involved_party_id", id);
			fiDenySummaryValidation.setString("involved_party_id_type", idType);
			fiDenySummaryValidation.setString("involved_party_type", invPartyType);

			// fiDenySummaryValidation.setInt("amt_val",amt);
			// fiDenySummaryValidation.setString("amt_cur",currency);
			// append to list
			LogUtilities.logObject("fiDenySummaryValidation",fiDenySummaryValidation, OperationNamesEnum.DENYSERVICE.code);

			if (insertFISummaryValidation == null) 
			{
				insertFISummaryValidation = factory.create("http://BEA_Solution_Deny_Module/ProcessLib/DispatchFIInput", "InsertFISummaryValidation");
				List lst = new ArrayList();
				lst.add(fiDenySummaryValidation);
				insertFISummaryValidation.setList("fi_Deny_Summary_Validation", lst);
			} 
			else 
			{
				insertFISummaryValidation.getList("fi_Deny_Summary_Validation").add(fiDenySummaryValidation);
			}
			return insertFISummaryValidation;
		}

		// ==_DENY_===ENDS===============================================================================================================

		public static DataObject prepareFIBanSummaryValidation(DataObject currentExtrSrvcTask, DataObject dispatchFIBanInput,DataObject insertFISummaryValidation) 
		{
			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			DataObject fiBanSummaryValidation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_ban_summary_validation","Fi_Ban_Summary_Validation");
			String id, idType, nationality, invPartyType;
			id = dispatchFIBanInput.getDataObject("banInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("id");
			idType = dispatchFIBanInput.getDataObject("banInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("idType");
			invPartyType = dispatchFIBanInput.getDataObject("banInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType");

			if (dispatchFIBanInput.getDataObject("banInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality") != null) 
			{
				nationality = dispatchFIBanInput.getDataObject("banInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality");
				LogUtilities.logUtil("TRY_nationality", nationality, OperationNamesEnum.BANSERVICE.code);
				fiBanSummaryValidation.setString("nat_cd", nationality);
			}
			LogUtilities.logUtil("id....", id, OperationNamesEnum.BANSERVICE.code);
			LogUtilities.logUtil("idType....", idType,OperationNamesEnum.BANSERVICE.code);
			LogUtilities.logUtil("invPartyType.....", invPartyType,OperationNamesEnum.BANSERVICE.code);

			fiBanSummaryValidation.setString("involved_party_id", id);
			fiBanSummaryValidation.setString("involved_party_id_type", idType);
			fiBanSummaryValidation.setString("involved_party_type", invPartyType);
			
			// System.out.println("-------------> after setting nationality");

			fiBanSummaryValidation.setString("msg_uid", currentExtrSrvcTask.getString("exetr_ref_no"));
			fiBanSummaryValidation.setString("fi_code", currentExtrSrvcTask.getString("fin_inst_cd"));
			fiBanSummaryValidation.setString("trans_date", KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss"));

			// append to list
			LogUtilities.logObject("fiBanSummaryValidation", fiBanSummaryValidation, OperationNamesEnum.BANSERVICE.code);
			if (insertFISummaryValidation == null) 
			{
				insertFISummaryValidation = factory.create("http://BEA_Solution_Ban_Module/ProcessLib/DispatchFIInput","InsertFISummaryValidation");
				List lst = new ArrayList();
				lst.add(fiBanSummaryValidation);
				insertFISummaryValidation.setList("fi_Ban_Summary_Validation", lst);
			} 
			else 
			{
				insertFISummaryValidation.getList("fi_Ban_Summary_Validation").add(fiBanSummaryValidation);
			}
			// System.out.println("-------------> END Of Function PrepareBanSumValidation() <-----------");
			return insertFISummaryValidation;

		}

		// ==_Ban_===ENDS===============================================================================================================

		
		
		public static DataObject prepareFIGarnishSummaryValidation(DataObject currentExtrSrvcTask,DataObject dispatchFIGarnishInputRq,DataObject insertFISummaryValidation,DataObject garnishQueryTypeConst, DataObject targetAmount){
			try{			
				
			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			DataObject fiGarnishSummaryValidation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_garnish_summary_validation","Fi_Garnish_Summary_Validation");

			String queryType = dispatchFIGarnishInputRq.getDataObject("GarnishInternalData").getString("QueryType");
			String garnishOpCode = OperationNamesEnum.GARNISHSERVICE.code;
			LogUtilities.logUtil("............. queryType: "+queryType, garnishOpCode);
//			LogUtilities.logObject(".....dispatchFIGarnishInputRq", dispatchFIGarnishInputRq, garnishOpCode);
			String id = "";
			String idType = ""; 
			String nationality="";
			String InPartyType="";
			
				if(dispatchFIGarnishInputRq.getDataObject("GarnishInternalData").getDataObject("CommonInternalData").getDataObject("commonInvParty") !=null ){
					id = dispatchFIGarnishInputRq.getDataObject("GarnishInternalData").getDataObject("CommonInternalData").getDataObject("commonInvParty").getString("id");
					idType = dispatchFIGarnishInputRq.getDataObject("GarnishInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("idType");
					InPartyType=dispatchFIGarnishInputRq.getDataObject("GarnishInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType");
					if(dispatchFIGarnishInputRq.getDataObject("GarnishInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality")!=null)
					{
						nationality = dispatchFIGarnishInputRq.getDataObject("GarnishInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality");
					}
				}
			
			
				String currency = "";
				if(dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt") != null){
					currency = dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").getString("Cur");
				}
				fiGarnishSummaryValidation.setString("msg_uid",currentExtrSrvcTask.getString("exetr_ref_no"));
				fiGarnishSummaryValidation.setString("msg_mode",currentExtrSrvcTask.getString("task_mode"));
				fiGarnishSummaryValidation.setString("fi_code",currentExtrSrvcTask.getString("fin_inst_cd"));
				fiGarnishSummaryValidation.setString("trans_date",KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss"));
				if( queryType.equals(garnishQueryTypeConst.getString("QT_ACC_ONLY")) || 
						queryType.equals(garnishQueryTypeConst.getString("QT_ACC_AMT")) ||
						queryType.equals(garnishQueryTypeConst.getString("QT_ID_ACC")) ||
						queryType.equals(garnishQueryTypeConst.getString("QT_ID_ACC_AMT")) ||
						dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("AccId") != null){
					fiGarnishSummaryValidation.setString("is_acc_id","y");
				
					fiGarnishSummaryValidation.setString("acc_num",dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("AccId").getString("Num"));
					String isIban = dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("AccId").getString("IBAN");
					fiGarnishSummaryValidation.setString("is_iban",isIban);
				}
				else{
					fiGarnishSummaryValidation.setString("is_acc_id","n");
				}
				// KH involved_party_type
				fiGarnishSummaryValidation.setString("involved_party_type",InPartyType);

				fiGarnishSummaryValidation.setString("involved_party_id",id);
				fiGarnishSummaryValidation.setString("involved_party_id_type",idType);
				fiGarnishSummaryValidation.setString("nat_cd",nationality);
				if(dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt") != null)
				{
					fiGarnishSummaryValidation.setBigDecimal("trgt_amt_val",dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("DcsnInfo").getDataObject("Amt").getBigDecimal("Val"));
					fiGarnishSummaryValidation.setString("is_amt","y");
				}

				if(!currency.equals(""))
				{
					fiGarnishSummaryValidation.setString("trgt_amt_cur",currency);		
				}
			
				
				if(targetAmount != null){
					fiGarnishSummaryValidation.setBigDecimal("trgt_amt_val",targetAmount.getBigDecimal("Val"));
					fiGarnishSummaryValidation.setString("trgt_amt_cur",targetAmount.getString("Cur"));
					fiGarnishSummaryValidation.setString("is_amt","y");
				}
				
				
				if(queryType.equals(garnishQueryTypeConst.getString("QT_ACC_ONLY")) || queryType.equals(garnishQueryTypeConst.getString("QT_ACC_AMT")) )
				{
					fiGarnishSummaryValidation.setString("is_involved_party","n");				
				}else{
					fiGarnishSummaryValidation.setString("is_involved_party","y");
				}
			
			
			//======================Matrix impl==========================================================
			LogUtilities.logUtil("Matrix impl ....", garnishOpCode);
			DataObject target_prds = dispatchFIGarnishInputRq.getDataObject("RPGarnishRq").getDataObject("Outline").getDataObject("ExePlan").getDataObject("TrgtPrds");
			
			
			//InvParty only
			if(queryType.equals(garnishQueryTypeConst.getString("QT_ID_ONLY"))){
				LogUtilities.logUtil("Matrix impl - InvParty_Only  ....", garnishOpCode);
				//targetPrdt
				fiGarnishSummaryValidation.setString("trgt_acc_prd","y");
				if(target_prds != null){
					fiGarnishSummaryValidation.setString("trgt_depost_prd",((target_prds.getString("Depots")!=null&&target_prds.getString("Depots").equals("y"))?"y":null));
					fiGarnishSummaryValidation.setString("trgt_safs_prd",((target_prds.getString("Safs")!=null&&target_prds.getString("Safs").equals("y"))?"y":null));
					
					//executionInfo
					fiGarnishSummaryValidation.setString("exe_acc_flag","y");
					fiGarnishSummaryValidation.setString("exe_depost_flag",((target_prds.getString("Depots")!=null&&target_prds.getString("Depots").equals("y"))?"y":null));
					fiGarnishSummaryValidation.setString("exe_safs_flag",((target_prds.getString("Safs")!=null&&target_prds.getString("Safs").equals("y"))?"y":null));
				}
				
				
				//InqrInfo
				fiGarnishSummaryValidation.setString("info_jnt_acc_flag","y");
				fiGarnishSummaryValidation.setString("info_jnt_depost_flag","y");
				fiGarnishSummaryValidation.setString("info_shrs_flag","y");	
				
			}
			
			//[ Acount only , Acount+InvParty , Acount_Amt , Acount+InvParty_Amt ]
			if(queryType.equals(garnishQueryTypeConst.getString("QT_ACC_ONLY")) ||
				queryType.equals(garnishQueryTypeConst.getString("QT_ID_ACC")) ||
				queryType.equals(garnishQueryTypeConst.getString("QT_ACC_AMT")) ||
				queryType.equals(garnishQueryTypeConst.getString("QT_ID_ACC_AMT")) 
				){
				LogUtilities.logUtil("Matrix impl - [Acc_Only, Acc_InvParty, Acc_Amt, Acc_InvParty_Amt]  ....", garnishOpCode);
				//targetPrdt
				fiGarnishSummaryValidation.setString("trgt_acc_prd","y");
				fiGarnishSummaryValidation.setString("trgt_depost_prd",null);
				fiGarnishSummaryValidation.setString("trgt_safs_prd",null);
				
				//executionInfo
				fiGarnishSummaryValidation.setString("exe_acc_flag","y");
				fiGarnishSummaryValidation.setString("exe_depost_flag",null);
				fiGarnishSummaryValidation.setString("exe_safs_flag",null);
				
				//InqrInfo
				fiGarnishSummaryValidation.setString("info_jnt_acc_flag",null);
				fiGarnishSummaryValidation.setString("info_jnt_depost_flag",null);
				fiGarnishSummaryValidation.setString("info_shrs_flag",null);
			}
			
			// InvParty + Amt
			if(queryType.equals(garnishQueryTypeConst.getString("QT_ID_AMT")))
			{
				LogUtilities.logUtil("Matrix impl - InvParty_Amt  ....", garnishOpCode);
				//1st callback
				if(currentExtrSrvcTask.getString("task_mode")== null )
				{
					LogUtilities.logUtil("Matrix impl - InvParty_Amt (1st callback) ....", garnishOpCode);
					//targetPrdt
					fiGarnishSummaryValidation.setString("trgt_acc_prd","y");
					if(target_prds != null){
						fiGarnishSummaryValidation.setString("trgt_depost_prd",((target_prds.getString("Depots")!=null&&target_prds.getString("Depots").equals("y"))?"y":null));
						fiGarnishSummaryValidation.setString("trgt_safs_prd",((target_prds.getString("Safs")!=null&&target_prds.getString("Safs").equals("y"))?"y":null));
						}
				
				}
				//2nd callback
				else
				{
					
					
					
					
					
					DataObject FISmryInfo = currentExtrSrvcTask.getDataObject("FISmryInfo");
					DataObject AcctsSmryInfo = FISmryInfo.getDataObject("AcctsSmryInfo");
					DataObject DepotsSmryInfo = FISmryInfo.getDataObject("DepotsSmryInfo");
					DataObject SafsSmryInfo = FISmryInfo.getDataObject("SafsSmryInfo");
					
					
					LogUtilities.logUtil("Matrix impl - InvParty_Amt (2nd callback) ....", garnishOpCode);
					// Insuffecient pendingAmt > 0 same as 1st callback
					if(currentExtrSrvcTask.getBigDecimal("ovr_amt").compareTo(new BigDecimal(0))>0)
					{
							LogUtilities.logUtil("Matrix impl - InvParty_Amt (2nd callback) - InSuffecient (same as 1st callback)....", garnishOpCode);
							//targetPrdt
							fiGarnishSummaryValidation.setString("trgt_acc_prd","y");
							if(target_prds != null){
								fiGarnishSummaryValidation.setString("trgt_depost_prd",((target_prds.getString("Depots")!=null&&target_prds.getString("Depots").equals("y"))?"y":null));
								fiGarnishSummaryValidation.setString("trgt_safs_prd",((target_prds.getString("Safs")!=null&&target_prds.getString("Safs").equals("y"))?"y":null));
							}
							
							//executionInfo
							if(AcctsSmryInfo != null){
								fiGarnishSummaryValidation.setString("exe_acc_flag",AcctsSmryInfo.getString("hasAccts").equals("y")?"y":null);
							}else{
								fiGarnishSummaryValidation.setString("exe_acc_flag",null);
							}
							if(DepotsSmryInfo != null){
								fiGarnishSummaryValidation.setString("exe_depost_flag",(DepotsSmryInfo.getString("hasDepots").equals("y")?"y":null));
							}else{
								fiGarnishSummaryValidation.setString("exe_depost_flag",null);
							}
							if(SafsSmryInfo != null){
								fiGarnishSummaryValidation.setString("exe_safs_flag",(SafsSmryInfo.getString("hasSafs").equals("y")?"y":null));
							}else{
								fiGarnishSummaryValidation.setString("exe_safs_flag",null);
							}
							
							//InqrInfo
							if(AcctsSmryInfo != null){
								fiGarnishSummaryValidation.setString("info_jnt_acc_flag",(AcctsSmryInfo.getString("hasJntAccts").equals("y")?"y":null));
							}
							if(DepotsSmryInfo != null){
								fiGarnishSummaryValidation.setString("info_jnt_depost_flag",(DepotsSmryInfo.getString("hasJntDepots").equals("y")?"y":null));
							}
							
							fiGarnishSummaryValidation.setString("info_shrs_flag","y");	
							
							// setting blocked and pending amount
							fiGarnishSummaryValidation.setBigDecimal("blocked_amt",currentExtrSrvcTask.getBigDecimal("blocked_amt"));
							fiGarnishSummaryValidation.setBigDecimal("pending_amt",currentExtrSrvcTask.getBigDecimal("ovr_amt"));
							
							
							if(currentExtrSrvcTask.getDataObject("FISmryInfo")!=null&&currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals")!=null){
								fiGarnishSummaryValidation.setBigDecimal("sar_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtSAR"));
								fiGarnishSummaryValidation.setBigDecimal("rq_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtRqCur"));
							}
							
							
							
							
						
					}
					//suffecient
					else
					{
						LogUtilities.logUtil("Matrix impl - InvParty_Amt (2nd callback) - Suffecient....", garnishOpCode);
						//targetPrdt
						fiGarnishSummaryValidation.setString("trgt_acc_prd","y");
						fiGarnishSummaryValidation.setString("trgt_depost_prd",null); 
						fiGarnishSummaryValidation.setString("trgt_safs_prd",null); 
						 
						//executionInfo
						fiGarnishSummaryValidation.setString("exe_acc_flag","y");
						fiGarnishSummaryValidation.setString("exe_depost_flag",null);
						fiGarnishSummaryValidation.setString("exe_safs_flag",null);
						
						//InqrInfo
						fiGarnishSummaryValidation.setString("info_jnt_acc_flag",null);
						fiGarnishSummaryValidation.setString("info_jnt_depost_flag",null);
						fiGarnishSummaryValidation.setString("info_shrs_flag",null);	
						
						
						// setting blocked and pending amount
//						fiGarnishSummaryValidation.setBigDecimal("blocked_amt",currentExtrSrvcTask.getBigDecimal("blocked_amt").add(currentExtrSrvcTask.getBigDecimal("ovr_amt")));
						fiGarnishSummaryValidation.setBigDecimal("blocked_amt",currentExtrSrvcTask.getBigDecimal("ovr_amt").negate());
						fiGarnishSummaryValidation.setBigDecimal("pending_amt",new BigDecimal(0));
						if(currentExtrSrvcTask.getDataObject("FISmryInfo")!=null&&currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals")!=null){
							fiGarnishSummaryValidation.setBigDecimal("sar_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtSAR"));
							fiGarnishSummaryValidation.setBigDecimal("rq_total_amt",currentExtrSrvcTask.getDataObject("FISmryInfo").getDataObject("Totals").getBigDecimal("AmtRqCur"));
						}
						
					}
				}
			}
			
//			LogUtilities.logObject("...Matrix impl End - fiGarnishSummaryValidation....", fiGarnishSummaryValidation, garnishOpCode);
			//======================Matrix impl==========================================================
			
			
			// append to list
			if (insertFISummaryValidation == null) {
				insertFISummaryValidation = factory.create("http://BEA_Solution_Garnish_Module/ProcessLib/DispatchFIInput","InsertFISummaryValidation");
				List lst = new ArrayList();
				lst.add(fiGarnishSummaryValidation);
				insertFISummaryValidation.setList("fi_Garnish_Summary_Validation", lst);
			} else {
				insertFISummaryValidation.getList("fi_Garnish_Summary_Validation").add(fiGarnishSummaryValidation);
			}
			

			}
			catch(Exception e){
				e.printStackTrace();
			}
			return insertFISummaryValidation;
		}	
		// ==_Garnish_===ENDS===============================================================================================================
	
	


		
		
		
		
		//Transfer_FI_SUMMARY_VALIDATION
		public static DataObject prepareFITransferSummaryValidation(DataObject currentExtrSrvcTask, DataObject dispatchFITransferInput,DataObject insertFISummaryValidation) 
		{
			String transferOpCode = OperationNamesEnum.TRANSFERSERVICE.code;
			BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
			DataObject fiTransferSummaryValidation = factory.create("http://BEA-Solution_Library/DBServices/BO","Fi_Xfer_Summary_Validation");
			String id=null, idType=null, nationality=null, invPartyType=null, isInvolvedParty=null, isAcc=null, busSrvcCd=null, accNum=null, isIban=null, baiBIC=null , prev_SRN=null,is_pre_tanfeeth="n";
			DataObject xferAmt = dispatchFITransferInput.getDataObject("TransferInternalData").getDataObject("xferAmt");
			if(dispatchFITransferInput.getDataObject("TransferInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty") != null){
				LogUtilities.logUtil("............. commonInvParty not null ................: ", transferOpCode);
				id = dispatchFITransferInput.getDataObject("TransferInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("id");
				idType = dispatchFITransferInput.getDataObject("TransferInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("idType");
				invPartyType = dispatchFITransferInput.getDataObject("TransferInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType");
				if (dispatchFITransferInput.getDataObject("TransferInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality") != null) 
				{
					LogUtilities.logUtil("............. nationality not null ................: ", transferOpCode);
					nationality = dispatchFITransferInput.getDataObject("TransferInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality");
					fiTransferSummaryValidation.setString("nat_cd", nationality);
				}
				
			}
			isInvolvedParty = dispatchFITransferInput.getDataObject("TransferInternalData").getString("isInvolvedParty");
			isAcc = dispatchFITransferInput.getDataObject("TransferInternalData").getString("isAcc");
			busSrvcCd = dispatchFITransferInput.getDataObject("TransferInternalData").getString("busSrvcCd");
			LogUtilities.logUtil("............. isInvolvedParty  ................: " + isInvolvedParty, transferOpCode);
			LogUtilities.logUtil("............. isAcc  ................: " + isAcc, transferOpCode);
			LogUtilities.logUtil("............. busSrvcCd  ................: "+ busSrvcCd, transferOpCode);

			if(isAcc.equals("y")){
					accNum = dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferFinInfo").getDataObject("AccFinInfo").getDataObject("AccId").getString("Num");
					isIban = dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferFinInfo").getDataObject("AccFinInfo").getDataObject("AccId").getString("IBAN");
					fiTransferSummaryValidation.setBigDecimal("amt_val", xferAmt.getBigDecimal("Val"));
			}else if(dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferFinInfo") != null){
				// get amt for each FICode
				fiTransferSummaryValidation.setBigDecimal("amt_val", getFIAmt(dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferFinInfo"),currentExtrSrvcTask.getString("fin_inst_cd")));
			}
			else{
				// No Amount
				fiTransferSummaryValidation.setBigDecimal("amt_val", null);
			}
			
			//BENEF_BIC 
			if(dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Benf") != null){
				baiBIC = dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Benf").getString("BIC");
			}
			
			
			// prevSRN
			if(dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferDcsnInfo") != null){
				if(dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferDcsnInfo").getDataObject("SrvcRefInfo") !=null){
					if(dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferDcsnInfo").getDataObject("SrvcRefInfo").getDataObject("Tanfeeth") != null){
						prev_SRN = dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferDcsnInfo").getDataObject("SrvcRefInfo").getDataObject("Tanfeeth").getString("SRN");
					}else if(dispatchFITransferInput.getDataObject("RPTransferRq").getDataObject("Outline").getDataObject("XferDcsnInfo").getDataObject("SrvcRefInfo").getDataObject("PreTanfeeth") != null){
						is_pre_tanfeeth = "y";
					}
				}
			}
			
			
			
			// involved party details
			fiTransferSummaryValidation.setString("is_involved_party", isInvolvedParty);
			fiTransferSummaryValidation.setString("involved_party_id", id);
			fiTransferSummaryValidation.setString("involved_party_id_type", idType);
			fiTransferSummaryValidation.setString("inv_party_type", invPartyType);
			
			// BAI details
			fiTransferSummaryValidation.setString("is_acc_id", isAcc);
			fiTransferSummaryValidation.setString("acc_num", accNum);
			fiTransferSummaryValidation.setString("is_Iban", isIban);
			fiTransferSummaryValidation.setString("benfBic", baiBIC);
			
			fiTransferSummaryValidation.setString("prev_SRN", prev_SRN);
			
			fiTransferSummaryValidation.setString("busCode", busSrvcCd);
			if(xferAmt != null)
				fiTransferSummaryValidation.setString("amr_cur", xferAmt.getString("Cur"));
			fiTransferSummaryValidation.setString("is_pre_tanfeeth", is_pre_tanfeeth);
			
			fiTransferSummaryValidation.setString("msg_uid", currentExtrSrvcTask.getString("exetr_ref_no"));
			fiTransferSummaryValidation.setString("fi_code", currentExtrSrvcTask.getString("fin_inst_cd"));
			fiTransferSummaryValidation.setString("trans_date", KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss"));

				
			
			// append to list
			if (insertFISummaryValidation == null) 
			{
				insertFISummaryValidation = factory.create("http://BEA_Solution_Transfer_Module/ProcessLib/DispatchFIInput","InsertFISummaryValidation");
				List lst = new ArrayList();
				lst.add(fiTransferSummaryValidation);
				insertFISummaryValidation.setList("fi_Xfer_Summary_Validation", lst);
			} 
			else 
			{
				insertFISummaryValidation.getList("fi_Xfer_Summary_Validation").add(fiTransferSummaryValidation);
			}
			// System.out.println("-------------> END Of Function PrepareBanSumValidation() <-----------");
			return insertFISummaryValidation;

		}


		
		
		
		
		
		
	
	public static DataObject prepareFIGISummaryValidation(DataObject currentExtrSrvcTask,DataObject dispatchFIGIInputRq,DataObject insertFISummaryValidation){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject fiGISummaryValidation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_gi_summary_validation","Fi_Gi_Summary_Validation");
		
		LogUtilities.logObject("currentExtrSrvcTask", currentExtrSrvcTask, OperationNamesEnum.GETACCOUNTINFO.code);
		LogUtilities.logObject("dispatchFIBlockInputRq", dispatchFIGIInputRq, OperationNamesEnum.GETACCOUNTINFO.code);
		LogUtilities.logObject("insertFISummaryValidation", insertFISummaryValidation, OperationNamesEnum.GETACCOUNTINFO.code);
		String operationCode = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName");
		String involved_Party_Type = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType");
		String id = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("id");
		String idType = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("idType");
		String nationality="";
		if(dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality")!=null)
		{
			 nationality = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality");
		}
		fiGISummaryValidation.setString("msg_uid",currentExtrSrvcTask.getString("exetr_ref_no"));
		fiGISummaryValidation.setString("fi_code",currentExtrSrvcTask.getString("fin_inst_cd"));
		fiGISummaryValidation.setString("trans_date",KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss"));
		if(dispatchFIGIInputRq.getDataObject("GIInternalData").getBoolean("IsAccQry")){
			if(operationCode.equals(OperationNamesEnum.GETACCOUNTINFO.code)){
				String isIban = dispatchFIGIInputRq.getDataObject("RPAcctsInfoRq").getDataObject("AccQry").getString("IBAN");
				fiGISummaryValidation.setString("is_iban",isIban.equals("y") ? "1" : "0");
				fiGISummaryValidation.setString("acc_qry",dispatchFIGIInputRq.getDataObject("RPAcctsInfoRq").getDataObject("AccQry").getString("AccNum"));
			}else if (operationCode.equals(OperationNamesEnum.GETBALSINFO.code)){
				String isIban = dispatchFIGIInputRq.getDataObject("giInput").getDataObject("RPGetBalsInfoRq").getDataObject("AccQry").getString("IBAN");
				fiGISummaryValidation.setString("is_iban",isIban.equals("y") ? "1" : "0");
				fiGISummaryValidation.setString("acc_qry",dispatchFIGIInputRq.getDataObject("giInput").getDataObject("RPGetBalsInfoRq").getDataObject("AccQry").getString("AccNum"));
			}else if (operationCode.equals(OperationNamesEnum.GETDEPOTSINFO.code)){
				fiGISummaryValidation.setString("acc_qry",dispatchFIGIInputRq.getDataObject("giInput").getDataObject("RPGetDepotssInfoRq").getString("DepotQry"));
			}else if (operationCode.equals(OperationNamesEnum.GETSAFSINFO.code)){
				fiGISummaryValidation.setString("acc_qry",dispatchFIGIInputRq.getDataObject("giInput").getDataObject("RPGetSafsInfoRq").getString("SafQry"));
			}
			fiGISummaryValidation.setString("is_acc_id","1");
		}
		else
			fiGISummaryValidation.setString("is_acc_id","0");
		
		if(dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType").equals(InvolvedPartyEnum.NONE.code)){
			fiGISummaryValidation.setString("is_involved_party","0");
		}else{
			fiGISummaryValidation.setString("is_involved_party","1");
			fiGISummaryValidation.setString("involved_party_type",involved_Party_Type);
			fiGISummaryValidation.setString("involved_party_id",id);
			fiGISummaryValidation.setString("involved_party_id_type",idType);
		}
		fiGISummaryValidation.setString("nat_cd",nationality);
		// append to list
		if (insertFISummaryValidation == null) {
			insertFISummaryValidation = factory.create("http://BEA_Solution_GI_Module/ProcessLib/DispatchFIInput","InsertFISummaryValidation");
			List lst = new ArrayList();
			lst.add(fiGISummaryValidation);
			insertFISummaryValidation.setList("fi_GI_Summary_Validation", lst);
		} else {
			insertFISummaryValidation.getList("fi_GI_Summary_Validation").add(fiGISummaryValidation);
		}
		
		return insertFISummaryValidation;
	}
	
	
	
	
	
	
	
	//PERFORMANCE FI_GI_SUMMRY_VALIDATION For All services.
	public static DataObject prepareFIGISummaryValidationPerformance(DataObject currentExtrSrvcTask,DataObject dispatchFIGIInputRq,DataObject insertFISummaryValidation){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject fiGISummaryValidation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_gi_summary_validation","Fi_Gi_Summary_Validation");
		
		String operationCode = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("OPList").getString("opName");
		String involved_Party_Type = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType");
		String id = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("id");
		String idType = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("idType");
		String nationality="";
		if(dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality")!=null)
		{
			 nationality = dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality");
		}
		fiGISummaryValidation.setString("msg_uid",currentExtrSrvcTask.getString("exetr_ref_no"));
		fiGISummaryValidation.setString("fi_code",currentExtrSrvcTask.getString("fin_inst_cd"));
		fiGISummaryValidation.setString("trans_date",KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss"));
		if(dispatchFIGIInputRq.getDataObject("GIInternalData").getBoolean("IsAccQry")){
			if(operationCode.equals(OperationNamesEnum.GETACCOUNTINFO.code)){
				String isIban = dispatchFIGIInputRq.getDataObject("RPAcctsInfoRq").getDataObject("AccQry").getString("IBAN");
				fiGISummaryValidation.setString("is_iban",isIban.equals("y") ? "1" : "0");
				fiGISummaryValidation.setString("acc_qry",dispatchFIGIInputRq.getDataObject("RPAcctsInfoRq").getDataObject("AccQry").getString("AccNum"));
			}else if (operationCode.equals(OperationNamesEnum.GETBALSINFO.code)){
				String isIban = dispatchFIGIInputRq.getDataObject("RPBalsInfoRq").getDataObject("AccQry").getString("IBAN");
				fiGISummaryValidation.setString("is_iban",isIban.equals("y") ? "1" : "0");
				fiGISummaryValidation.setString("acc_qry",dispatchFIGIInputRq.getDataObject("RPBalsInfoRq").getDataObject("AccQry").getString("AccNum"));
			}else if (operationCode.equals(OperationNamesEnum.GETDEPOTSINFO.code)){
				fiGISummaryValidation.setString("acc_qry",dispatchFIGIInputRq.getDataObject("RPDepotssInfoRq").getString("DepotQry"));
			}else if (operationCode.equals(OperationNamesEnum.GETSAFSINFO.code)){
				fiGISummaryValidation.setString("acc_qry",dispatchFIGIInputRq.getDataObject("RPSafsInfoRq").getString("SafQry"));
			}
			fiGISummaryValidation.setString("is_acc_id","1");
		}
		else
			fiGISummaryValidation.setString("is_acc_id","0");
		
		if(dispatchFIGIInputRq.getDataObject("GIInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType").equals(InvolvedPartyEnum.NONE.code)){
			fiGISummaryValidation.setString("is_involved_party","0");
		}else{
			fiGISummaryValidation.setString("is_involved_party","1");
			fiGISummaryValidation.setString("involved_party_type",involved_Party_Type);
			fiGISummaryValidation.setString("involved_party_id",id);
			fiGISummaryValidation.setString("involved_party_id_type",idType);
		}
		fiGISummaryValidation.setString("nat_cd",nationality);
		// append to list
		
		if (insertFISummaryValidation == null) {
			//insertFISummaryValidation = factory.create("http://BEA_Solution_GI_Module/ProcessLib/DispatchFIInput","InsertFISummaryValidation");
			insertFISummaryValidation = factory.create("http://BEA_Solution_Library/ProcessLib/GI","InsertFISummaryValidation");
			
			LogUtilities.logObject("^^^^^^^^^^^^ IF InsertSum_NULL^^^fiGISummaryValidation", fiGISummaryValidation, OperationNamesEnum.GETBALSINFO.code);
			List lst = new ArrayList();
			lst.add(fiGISummaryValidation);
			insertFISummaryValidation.setList("fi_GI_Summary_Validation", lst);
		} else {
			LogUtilities.logObject("^^^^^^^^^^^^ELSE InsertSum_NULL^^^fiGISummaryValidation", fiGISummaryValidation, OperationNamesEnum.GETBALSINFO.code);
			insertFISummaryValidation.getList("fi_GI_Summary_Validation").add(fiGISummaryValidation);
		}
		
		return insertFISummaryValidation;
	}
	
	
	
	
	public static String ValidatePrdUsrList(DataObject prdUsrList,DataObject fiSummary,String isJntAcc ,boolean byPassData )
	{
		String result="valid";
		List userOnfo =prdUsrList.getList("UsrInfo");
		String is_Acc=fiSummary.getString("is_acc_id");
		String is_Inv=fiSummary.getString("is_involved_party");
		String involved_party_type=fiSummary.getString("involved_party_type");
		int countOwners=0;
		int allUsrLst = 0;
		DataObject accOwner=null;
		for(int i=0; i <userOnfo.size();i++)
		{
			allUsrLst =allUsrLst+1;
			if(((DataObject)userOnfo.get(i)).getString("UsrType").equals("01")){
				countOwners=countOwners+1;
				accOwner=(DataObject)userOnfo.get(i);
			}
		}
		LogUtilities.logUtil("number of Users   "+allUsrLst);
		LogUtilities.logUtil("number of countOwners   "+countOwners);
		LogUtilities.logUtil("is_Inv  "+is_Inv);
		LogUtilities.logUtil("is_Acc  "+is_Acc);
		LogUtilities.logUtil("isJntAcc  "+isJntAcc);
		LogUtilities.logUtil("involved_party_type  "+involved_party_type);
		LogUtilities.logUtil("is_Inv.equals(1)  "+is_Inv.equals("1"));
		LogUtilities.logUtil("is_Acc.equals(0) "+is_Acc.equals("0"));
		LogUtilities.logUtil("isJntAcc.equals(n)  "+isJntAcc.equals("n"));

		if(isJntAcc.equals("l")){
			if(allUsrLst!=1 || countOwners !=1){
				result="invalid_Prd_owners_count";
			}
			else if((!accOwner.getString("Id").equalsIgnoreCase(fiSummary.getString("involved_party_id")) || !accOwner.getString("IdType").equalsIgnoreCase(fiSummary.getString("involved_party_id_type"))) && byPassData==false){
				result="invalid_Prd_owner_data";
			}
		}else{
		// 50 for count
		//51 for data
		if(is_Inv.equals("1") && is_Acc.equals("0"))
		{
			LogUtilities.logUtil("inv 1 acc 0");

			if(countOwners!=1){
				result="invalid_Prd_owners_count";
			}else if(isJntAcc.equals("y")&&allUsrLst>1){
				result="invalid_Prd_owners_count";
			}
			else if((!accOwner.getString("Id").equalsIgnoreCase(fiSummary.getString("involved_party_id"))||   !accOwner.getString("IdType").equalsIgnoreCase(fiSummary.getString("involved_party_id_type")))&& byPassData==false){
				result="invalid_Prd_owner_data";
			}
		}else if(is_Acc.equals("1")){
			LogUtilities.logUtil("is_Acc 1");
			if(isJntAcc.equals("n")){
				if(countOwners!=1){
					result="invalid_Prd_owners_count";
				}
			}
			else {
				if(countOwners<2){
					result="invalid_Prd_owners_count";
				}
			}
		}
	}
		return result;
	}
	
	public static DataObject validateCallbackBlockDetails(DataObject validateFIBlockCallbackRq,DataObject fi_Block_Summary_Validation,DataObject callBackErrorCodeConst,DataObject validateFICallbackRs){
		
		if(validateFIBlockCallbackRq.getDataObject("FIBlockCallBackRq").getDataObject("BlocksList")==null || validateFIBlockCallbackRq.getDataObject("FIBlockCallBackRq").getDataObject("BlocksList").getList("AccBlockInfo")== null || validateFIBlockCallbackRq.getDataObject("FIBlockCallBackRq").getDataObject("BlocksList").getList("AccBlockInfo").isEmpty()){
			validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("EmptyBlockList"));
		}
		else{
				int tmpSrcAmt = 0;
				int tmpBlockAmt=0;
				int isAccId = Integer.parseInt(fi_Block_Summary_Validation.getString("is_acc_id"));
				int rqstAmt=fi_Block_Summary_Validation.getInt("amt_val");
				String rqstCur = fi_Block_Summary_Validation.getString("amt_cur");
				int callbackSmryAmt=validateFIBlockCallbackRq.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo").getInt("TotAmt");
				int blockListSize=validateFIBlockCallbackRq.getDataObject("FIBlockCallBackRq").getDataObject("BlocksList").getList("AccBlockInfo").size();
				if(isAccId==1 && blockListSize>1){
					validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("InvalidBlockListCount"));
				}else if(isAccId==1 && blockListSize==1){
					// to check RequestAccNum with the blockedAccNum [InvalidAccNumber]
					System.out.println("to be validate RequestAccNum with the blockedAccNum");
				}else{
				boolean valid = true;
				boolean allActsSameCurr = true;
				for(int i=0;i<blockListSize;i++){
					DataObject accBlockInfo = ((DataObject)validateFIBlockCallbackRq.getDataObject("FIBlockCallBackRq").getDataObject("BlocksList").getList("AccBlockInfo").get(i));
					String jntAcc = accBlockInfo.getString("JntAcc");
						if(isAccId==0 && jntAcc.equals("y")){
							validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("InvalidBlockedAccount"));
							valid = false;
							break;
						}
						if(rqstCur.equals(accBlockInfo.getString("AccCur"))){
							if(accBlockInfo.getInt("FXRate")!=1){
								validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("InvalidFXRate"));
								valid = false;
								break;
							}
							tmpSrcAmt = tmpSrcAmt+accBlockInfo.getInt("SrcAmt");
						}else{
							allActsSameCurr = false;
						}
						tmpBlockAmt=tmpBlockAmt+ accBlockInfo.getInt("BlockAmt");
						String validationResult = ValidatePrdUsrList(accBlockInfo.getDataObject("PrdUsrsList"),fi_Block_Summary_Validation,jntAcc,true);
						if(!validationResult.equals("valid")){
							valid = false;
						
							if(validationResult.equals("invalid_Prd_owners_count")){
								validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("InvaldPrdCount"));
								break;
							}
							else if (validationResult.equals("invalid_Prd_owner_data")){
								validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("InvalidPrdData"));
								break;
							}
					}
				}
					
					if(valid==true){
						if(tmpBlockAmt != rqstAmt){
							validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("InvalidTotalBlockedAmt"));
						}else if (callbackSmryAmt != rqstAmt){
							validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("InvalidSummaryTotAmt"));
						}else if (callbackSmryAmt != tmpBlockAmt){
							validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("BlockedAmt_Mismatch_SummaryTotAmt"));
						}else if (allActsSameCurr==true && tmpSrcAmt != rqstAmt){
							validateFICallbackRs.setString("status_code",callBackErrorCodeConst.getString("InvalidTotalSRCAmt"));
						}
					}
				}
			}
		return validateFICallbackRs;
	}
	
	
	//prepareValidateRPTransferReturnValue
//	public static String getStadningRequestsTransfer(String outputValidateRPTransfer)
//	{
//		//VALID,007,008,010,011_02_90080,9005%n
//		//VALID,02_90080,9005
//		//VALID,00_%n
//		outputValidateRPTransfer = outputValidateRPTransfer.substring(6,outputValidateRPTransfer.length());
//		String [] data = outputValidateRPTransfer.split("_");
//		return data[0];
//	}
	
	public static String getCaseTypeTransfer(String outputValidateRPTransfer)
	{
		//VALID_02_90080,9005%y
		//VALID_00_90040
		//VALID_00_%n
		//VALID_00
		String Output ="";
//		outputValidateRPTransfer = outputValidateRPTransfer.substring(6,outputValidateRPTransfer.length());
		String [] data = outputValidateRPTransfer.split("_");
		Output= data[1];
		return Output;
	}
	public static String getGarnishAmountType(String outputValidateRPTransfer)
	{
		//VALID_02_90080,9005%y
		//VALID_00_90040
		//VALID_00_%n
		//VALID_00
		String outPutData="n";
//		outputValidateRPTransfer = outputValidateRPTransfer.substring(6,outputValidateRPTransfer.length());
		if(outputValidateRPTransfer.contains("%"))
		{
			String [] data = outputValidateRPTransfer.split("%");
			outPutData =data[1];
		}
		
		return outPutData;
	}
	
	public static boolean validateRPTransferFiCodes(String outputValidateRPTransfer, DataObject FIListFinInfo)
	{
		//VALID_02_|90080,9005_%y
		//VALID_00_|90040
		//VALID_00_%n
		//VALID_00
		boolean result = false;
//		String [] data = outputValidateRPTransfer.split("_");
		
		List currentFiFinInfo = FIListFinInfo.getList("FIFinInfo");
		if(outputValidateRPTransfer.contains("|"))
		{
			String [] data = outputValidateRPTransfer.split("_");
			System.out.println("_ data list length: " + data.length + " (1)");
			System.out.println("data[2]" + data[2]);
			data[2] = data[2].substring(1,data[2].length());
			List<String> exec_sum_details_codes = Arrays.asList(data[2].split(","));
			if (FIListFinInfo != null)
			{				
				System.out.println(" fi list not null (2) ");
				for(int i= 0; i<currentFiFinInfo.size(); i++)
				{
					if(!exec_sum_details_codes.contains(((DataObject)currentFiFinInfo.get(i)).getString("FICode")))
					{
						System.out.println("FICodes===>: " + ((DataObject)currentFiFinInfo.get(i)).getString("FICode"));
						result = true;
						break;
					}
				}
				
				
			}	
		}else {
			if(currentFiFinInfo != null && currentFiFinInfo.size() > 0 )
			{
				System.out.println("exec_summary_details fi list is empty and request sent with banks - invalid reject");
				result = true;
			}
		}
		
		return result;
	}
	
	
	
	//getFiCodesFromValidateDuplicateTransfer
	public static boolean checkIfFiCodesDuplicated(String outputValidateDuplicateTransfer, DataObject FIListFinInfo)
	{
		//10100180521001001000676_90005,90080
		String fiCodes = "";
		boolean result = false;
		String [] data = outputValidateDuplicateTransfer.split("_");
		fiCodes = data[1];
		List<String> datafiCodesList = Arrays.asList(fiCodes.split(","));
		
		
		if (FIListFinInfo != null)
		{
			List fiFinInfo = FIListFinInfo.getList("FIFinInfo");
			for(int i= 0; i<fiFinInfo.size(); i++){
				if(datafiCodesList.contains(((DataObject)fiFinInfo.get(i)).getString("FICode")))
				{
					result = true;
					break;
				}
				
			}
		}
		
		
		return result;
	}
	
	public static String getSRNFromValidateDuplicateTransfer(String outputValidateDuplicateTransfer, String currentSRN)
	{
		//10100180521001001000676_90005,90080
		String SRN = "";
		String [] data = outputValidateDuplicateTransfer.split("_");
		SRN = currentSRN + "-" + data[0];
		return SRN;
	}
	
	
	
	
	
	public static String validateRPLift(DataObject ValidateRPLiftRq,DataObject ExecRunTot,String lftType)
		{
		
		int accCount=ExecRunTot.getList("TanfeethExec_Running_TotalsBG").size();
			if(lftType.equals("part"))
			{
				if(accCount==1)
				{
					return "AccQryRq";
				}
				else
				{
					return "";
				}
			}
			else
			{
				return "";
				
			}
			
		
		}
	public static DataObject prepareExecutionRunningTotal(DataObject insertExecutionSummary,String ficode,DataObject FIRsBlockDtls){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		boolean exist = false;
		List exec_Running_Totals_lst = null;
		if(insertExecutionSummary.getList("exec_Running_Totals")==null){
			exec_Running_Totals_lst = new ArrayList<>();
		}else{
			exec_Running_Totals_lst = insertExecutionSummary.getList("exec_Running_Totals");
		}
		LogUtilities.logUtil("FIRsBlockDtls.getList(FIRsBlockInfo).size()>>>>"+FIRsBlockDtls.getList("FIRsBlockInfo").size(), OperationNamesEnum.BLOCKSERVICE.code);
		//XfersList -BlocksInqLists
		for(int i=0;i<FIRsBlockDtls.getList("FIRsBlockInfo").size();i++){
			if(((DataObject)FIRsBlockDtls.getList("FIRsBlockInfo").get(i)).getDataObject("BlockDtlsInfo")!=null&&ficode.equals(((DataObject)FIRsBlockDtls.getList("FIRsBlockInfo").get(i)).getString("FICode"))){
				LogUtilities.logUtil("FICode exist in List>>>>"+ficode, OperationNamesEnum.BLOCKSERVICE.code);
				DataObject BlockDtls = ((DataObject)FIRsBlockDtls.getList("FIRsBlockInfo").get(i)).getDataObject("BlockDtlsInfo");
				if(BlockDtls.getDataObject("BlocksInqLists").getDataObject("BlocksList")!= null && BlockDtls.getDataObject("BlocksInqLists").getDataObject("BlocksList").getDataObject("AcctsList")!= null){
					List AcctsList = BlockDtls.getDataObject("BlocksInqLists").getDataObject("BlocksList").getDataObject("AcctsList").getList("AccInfo");
					exec_Running_Totals_lst = PrepareRunningTotalAccts(ficode,AcctsList,exec_Running_Totals_lst);
					exist = true;
				}
				if(BlockDtls.getDataObject("BlocksInqLists").getDataObject("BlocksList")!= null && BlockDtls.getDataObject("BlocksInqLists").getDataObject("BlocksList").getDataObject("DepotsList")!= null){
					List DepostList = BlockDtls.getDataObject("BlocksInqLists").getDataObject("BlocksList").getDataObject("DepotsList").getList("DepotInfo");
					exec_Running_Totals_lst = PrepareRunningTotalDepost (ficode,DepostList,exec_Running_Totals_lst);
					exist = true;
				}
			}
			
		}
		if(exist == false){
			LogUtilities.logUtil("FICode notexist in List>............>>"+ficode, OperationNamesEnum.BLOCKSERVICE.code);
			DataObject Exec_Running_Totals = factory.create("http://www.sama.bea.sa/DBServices/tanfeethexec_running_totals","Exec_Running_Totals");
			Exec_Running_Totals.setString("fin_inst_cd", ficode);		
			exec_Running_Totals_lst.add(Exec_Running_Totals);
		}
		insertExecutionSummary.setList("exec_Running_Totals",exec_Running_Totals_lst);
		
		return insertExecutionSummary;
	}
	
	
	
	/////////////////////////		START XFER 		//////////////////////////////////////////////
	public static DataObject prepareExecutionRunningTotalTransfer(DataObject insertExecutionSummary,DataObject dispatchRPTransferReplyRq){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		List exec_Running_Totals_lst = null;
		String ficode =null;
		String prvSrn =null;

		LogUtilities.logUtil("RPTransferCallBackRq>>>>"+dispatchRPTransferReplyRq.getDataObject("RPTransferCallBackRq"), OperationNamesEnum.TRANSFERSERVICE.code);
		//XfersList - BlocksInqLists - XferInfo
//		for(int i=0;i<dispatchRPTransferReplyRq.getDataObject("RPTransferCallBackRq").getList("FIRsTransferDtls").size();i++)
//		{
//			if(((DataObject)dispatchRPTransferReplyRq.getDataObject("RPTransferCallBackRq").getList("FIRsTransferDtls").get(i)).getDataObject("FIRsTransferInfo")!=null){
//				ficode = ((DataObject)dispatchRPTransferReplyRq.getDataObject("RPTransferCallBackRq").getList("FIRsTransferDtls").get(i)).getString("FICode");
//				LogUtilities.logUtil("FICode exist in List>>>>"+ficode, OperationNamesEnum.TRANSFERSERVICE.code);
//				DataObject xferDtls = ((DataObject)dispatchRPTransferReplyRq.getDataObject("RPTransferCallBackRq").getList("FIRsTransferDtls").get(i)).getDataObject("FIRsTransferInfo");
//				if(xferDtls.getDataObject("XfersList")!= null && xferDtls.getDataObject("XfersList").getList("XferInfo")!= null){
//					// Code Here .............................
//					DataObject AccInfo =  factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ExeAccInfo");
//					List AcctsList = new ArrayList<>();
//					for (int m=0; m<xferDtls.getDataObject("XfersList").getList("XferInfo").size(); m++)
//					{
//						DataObject raw = ((DataObject)xferDtls.getDataObject("XfersList").getList("XferInfo").get(m));
//						AccInfo.setString("AccNum", raw.getString("AccNum"));
//						AccInfo.setString("IBAN", raw.getString("IBAN"));
//						AccInfo.setString("Inst", raw.getString("Inst"));
//						AccInfo.setString("SrcAmt", raw.getString("SrcAmt"));
//						AccInfo.setString("JntAcc", raw.getString("JntAcc"));
//						AccInfo.setString("BlockAmt", raw.getString("BlockAmt"));
//						AccInfo.setString("FXRate", raw.getString("FXRate"));
//						AccInfo.setString("BlockDtTm", raw.getString("XferDtTm"));
//						AccInfo.setDataObject("PrdUsrsList", raw.getDataObject("PrdUsrsList"));
//						AcctsList.add(AccInfo);
//					
//					}
//						exec_Running_Totals_lst = PrepareRunningTotalAccts(ficode,AcctsList,exec_Running_Totals_lst);
//				}
//			}
			prvSrn = dispatchRPTransferReplyRq.getDataObject("TransferInternalData").getString("prvSrn");
			insertExecutionSummary.setString("prvSrn", prvSrn);
			LogUtilities.logUtil("prvSrn exist in List>>>>>>>>>>>>>>>>"+prvSrn, OperationNamesEnum.TRANSFERSERVICE.code);
			
//		}

		//insertExecutionSummary.setList("exec_Running_Totals",exec_Running_Totals_lst);
		
		return insertExecutionSummary;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	////////////////////////////////	END OF XFER		//////////////////////////////////////////////
	
	
	
	public static DataObject prepareExecutionRunningTotalXFR(DataObject insertExecutionSummary,String ficode,DataObject FIRsBlockDtls){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		List exec_Running_Totals_lst = null;
		if(insertExecutionSummary.getList("exec_Running_Totals")==null){
			exec_Running_Totals_lst = new ArrayList<>();
		}else{
			exec_Running_Totals_lst = insertExecutionSummary.getList("exec_Running_Totals");
		}
		LogUtilities.logUtil("FIRsBlockDtls.getList(FIRsBlockInfo).size()>>>>"+FIRsBlockDtls.getList("FIRsBlockInfo").size(), OperationNamesEnum.BLOCKSERVICE.code);
		//XfersList - BlocksInqLists - XferInfo
		for(int i=0;i<FIRsBlockDtls.getList("FIRsBlockInfo").size();i++)
		{
			if(((DataObject)FIRsBlockDtls.getList("FIRsBlockInfo").get(i)).getDataObject("BlockDtlsInfo")!=null&&ficode.equals(((DataObject)FIRsBlockDtls.getList("FIRsBlockInfo").get(i)).getString("FICode"))){
				
				LogUtilities.logUtil("FICode exist in List>>>>"+ficode, OperationNamesEnum.BLOCKSERVICE.code);
				DataObject BlockDtls = ((DataObject)FIRsBlockDtls.getList("FIRsBlockInfo").get(i)).getDataObject("BlockDtlsInfo");
				if(BlockDtls.getDataObject("XfersList")!= null && BlockDtls.getDataObject("XfersList").getList("XferInfo")!= null){
					// Code Here .............................
					DataObject AccInfo =  factory.create("http://www.sama.bea.sa/execution/services/ExecutionLib","T_ExeAccInfo");
					List AcctsList = new ArrayList<>();
					for (int m=0; m<BlockDtls.getDataObject("XfersList").getList("XferInfo").size(); m++)
					{
						DataObject raw = ((DataObject)BlockDtls.getDataObject("XfersList").getList("XferInfo").get(m));
						AccInfo.setString("AccNum", raw.getString("AccNum"));
						AccInfo.setString("IBAN", raw.getString("IBAN"));
						AccInfo.setString("Inst", raw.getString("Inst"));
						AccInfo.setString("SrcAmt", raw.getString("SrcAmt"));
						AccInfo.setString("JntAcc", raw.getString("JntAcc"));
						AccInfo.setString("BlockAmt", raw.getString("BlockAmt"));
						AccInfo.setString("FXRate", raw.getString("FXRate"));
						AccInfo.setString("BlockDtTm", raw.getString("XferDtTm"));
						AccInfo.setDataObject("PrdUsrsList", raw.getDataObject("PrdUsrsList"));
						AcctsList.add(AccInfo);
					
					}
						exec_Running_Totals_lst = PrepareRunningTotalAccts(ficode,AcctsList,exec_Running_Totals_lst);
				}
			}
			
		}

		insertExecutionSummary.setList("exec_Running_Totals",exec_Running_Totals_lst);
		
		return insertExecutionSummary;
	}
	
	
	
	
	public static DataObject prepareExecutionSummaryDetails(DataObject insertExecutionSummary,String ficode,DataObject fiTotals){
	
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		List exec_Summary_Details_lst = null;
		if(insertExecutionSummary.getList("exec_Summary_Details")==null){
			exec_Summary_Details_lst = new ArrayList<>();
		}else{
			exec_Summary_Details_lst = insertExecutionSummary.getList("exec_Summary_Details");
		}
		if(fiTotals!=null){
		for(int i=0;i<fiTotals.getList("FITotal").size();i++){
			if(((DataObject)fiTotals.getList("FITotal").get(i)).getDataObject("Totals")!=null&&ficode.equals(((DataObject)fiTotals.getList("FITotal").get(i)).getString("FICODE"))){
//  				LogUtilities.logUtil("fiTotals.(FITotal).size()>>>>"+fiTotals.getList("FITotal").size(), OperationNamesEnum.BLOCKSERVICE.code);
//					LogUtilities.logUtil("FICode exist in List>>>>"+ficode, OperationNamesEnum.BLOCKSERVICE.code);
					BigDecimal zeroValue = new BigDecimal(0);
					DataObject Totals = ((DataObject)fiTotals.getList("FITotal").get(i)).getDataObject("Totals");
//					System.out.println("Totals.getBigDecimal(TotAmt)"+Totals.getBigDecimal("TotAmt"));
//					System.out.println("Totals.getBigDecimal(AmtSAR)"+Totals.getBigDecimal("AmtSAR"));
//					System.out.println("Totals.getBigDecimal(AmtRqCur)"+Totals.getBigDecimal("AmtRqCur"));
//					System.out.println("Totals.getBigDecimal(AmtRqCur)"+Totals.getBigDecimal("AmtRqCur"));
					String hasAccts = ((DataObject)fiTotals.getList("FITotal").get(i)).getString("hasAccts");
					if( Totals.getBigDecimal("TotAmt").compareTo(zeroValue)==0 && Totals.getBigDecimal("AmtSAR").compareTo(zeroValue)==0
							&& Totals.getBigDecimal("AmtRqCur").compareTo(zeroValue)==0 && hasAccts.equals("n")){
						continue;
					}else{
						DataObject Exec_Summary_Details = factory.create("http://BEA-Solution_Library/DBServices/BO","Exec_Summary_Details");
						Exec_Summary_Details.setString("fin_inst_cd", ficode);
						Exec_Summary_Details.setBigDecimal("total_amt", Totals.getBigDecimal("TotAmt"));
						Exec_Summary_Details.setBigDecimal("sar_total_amt", Totals.getBigDecimal("AmtSAR"));
						Exec_Summary_Details.setBigDecimal("rq_total_amt", Totals.getBigDecimal("AmtRqCur"));
						exec_Summary_Details_lst.add(Exec_Summary_Details);
					}
				}
			}
		}
		
		insertExecutionSummary.setList("exec_Summary_Details",exec_Summary_Details_lst);
		return insertExecutionSummary;
	}
	
	public static DataObject prepareExecutionSummaryDetailsWithOutAmt(DataObject insertExecutionSummary){
		
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		List exec_Summary_Details_lst = null;
		BigDecimal zeroValue = new BigDecimal(0);
		if(insertExecutionSummary.getList("exec_Summary_Details")==null){
			exec_Summary_Details_lst = new ArrayList<>();
		}else{
			exec_Summary_Details_lst = insertExecutionSummary.getList("exec_Summary_Details");
		}
		if(insertExecutionSummary.getList("exec_Running_Totals")!=null){
		for(int i=0;i<insertExecutionSummary.getList("exec_Running_Totals").size();i++){
			DataObject Exec_Summary_Details = factory.create("http://BEA-Solution_Library/DBServices/BO","Exec_Summary_Details");
			
			Exec_Summary_Details.setString("fin_inst_cd", ((DataObject)insertExecutionSummary.getList("exec_Running_Totals").get(i)).getString("fin_inst_cd"));
			Exec_Summary_Details.setBigDecimal("total_amt",zeroValue);
			Exec_Summary_Details.setBigDecimal("sar_total_amt", zeroValue);
			Exec_Summary_Details.setBigDecimal("rq_total_amt", zeroValue);
			exec_Summary_Details_lst.add(Exec_Summary_Details);
			
				
			}
		}
		
		insertExecutionSummary.setList("exec_Summary_Details",exec_Summary_Details_lst);
		return insertExecutionSummary;
	}
	
	private static List PrepareRunningTotalAccts(String ficode, List acctsList,List exec_Running_Totals_lst) {
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		for(int j=0;j<acctsList.size();j++){
			DataObject Exec_Running_Totals = factory.create("http://www.sama.bea.sa/DBServices/tanfeethexec_running_totals","Exec_Running_Totals");
			Exec_Running_Totals.setString("fin_inst_cd", ficode);
			Exec_Running_Totals.setString("acc_num", ((DataObject)acctsList.get(j)).getString("AccNum"));
			Exec_Running_Totals.setString("acc_currency", ((DataObject)acctsList.get(j)).getString("AccCur"));
			Exec_Running_Totals.setString("available_amt", ((DataObject)acctsList.get(j)).getString("BlockAmt"));	
			Exec_Running_Totals.setString("iban", ((DataObject)acctsList.get(j)).getString("IBAN"));
			Exec_Running_Totals.setString("src_amt", ((DataObject)acctsList.get(j)).getString("SrcAmt"));
			exec_Running_Totals_lst.add(Exec_Running_Totals);
		}
		return exec_Running_Totals_lst;
	}
	
	private static List PrepareRunningTotalDepost (String ficode, List DepostList,List exec_Running_Totals_lst){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		for(int k=0;k<DepostList.size();k++){
			DataObject Exec_Running_Totals = factory.create("http://www.sama.bea.sa/DBServices/tanfeethexec_running_totals","Exec_Running_Totals");
			Exec_Running_Totals.setString("fin_inst_cd", ficode);
			Exec_Running_Totals.setString("depost_num", ((DataObject)DepostList.get(k)).getString("DepotNum"));
			exec_Running_Totals_lst.add(Exec_Running_Totals);
		}
		return exec_Running_Totals_lst;
	}

	public static DataObject prepareGarnishExecutionRunningTotal(DataObject insertExecutionSummary,String ficode,DataObject FIRsGarnishDtls){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		boolean exist = false;
		List exec_Running_Totals_lst = null;
		if(insertExecutionSummary.getList("exec_Running_Totals")==null){
			exec_Running_Totals_lst = new ArrayList<>();
		}else{
			exec_Running_Totals_lst = insertExecutionSummary.getList("exec_Running_Totals");
		}
		LogUtilities.logUtil("FIRsBlockDtls.getList(FIRsGarnishInfo).size()>>>>"+FIRsGarnishDtls.getList("FIRsGarnishInfo").size(), OperationNamesEnum.BLOCKSERVICE.code);
		for(int i=0;i<FIRsGarnishDtls.getList("FIRsGarnishInfo").size();i++){
			if(((DataObject)FIRsGarnishDtls.getList("FIRsGarnishInfo").get(i)).getDataObject("GarnishDtlsInfo")!=null&&ficode.equals(((DataObject)FIRsGarnishDtls.getList("FIRsGarnishInfo").get(i)).getString("FICode"))){
				LogUtilities.logUtil("FICode exist in List>>>>"+ficode, OperationNamesEnum.GARNISHSERVICE.code);
				DataObject GarnishDtlsInfo = ((DataObject)FIRsGarnishDtls.getList("FIRsGarnishInfo").get(i)).getDataObject("GarnishDtlsInfo");
				
				if(GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo")!= null && GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("AcctsList")!= null){
				List AcctsList = GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("AcctsList").getList("AccInfo");
				exec_Running_Totals_lst = PrepareRunningTotalAccts(ficode,AcctsList,exec_Running_Totals_lst);
				exist = true;
			}
				if(GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo")!= null && GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("DepotsList")!= null){
					List DepostList = GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfo").getDataObject("DepotsList").getList("DepotInfo");
					exec_Running_Totals_lst = PrepareRunningTotalDepost (ficode,DepostList,exec_Running_Totals_lst);
					exist = true;
				}
				
				if(GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF")!= null && GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("AcctsList")!= null){
					List AcctsList = GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("AcctsList").getList("AccInfo");
					for(int j=0;j<AcctsList.size();j++){
						DataObject Exec_Running_Totals = factory.create("http://www.sama.bea.sa/DBServices/tanfeethexec_running_totals","Exec_Running_Totals");
						Exec_Running_Totals.setString("fin_inst_cd", ficode);
						Exec_Running_Totals.setString("acc_num", ((DataObject)AcctsList.get(j)).getString("AccNum"));
						Exec_Running_Totals.setString("iban", ((DataObject)AcctsList.get(j)).getString("IBAN"));
						exec_Running_Totals_lst.add(Exec_Running_Totals);
						exist = true;
					}
				}
				if(GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF")!= null && GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("DepotsList")!= null){
					List DepostList = GarnishDtlsInfo.getDataObject("GarnishExeDtlsInfo").getDataObject("DtlsInfoNF").getDataObject("DepotsList").getList("DepotInfo");
					exec_Running_Totals_lst = PrepareRunningTotalDepost(ficode,DepostList,exec_Running_Totals_lst);
					exist = true;
				}
				
				
			}
			
		}
		if(exist == false){
			LogUtilities.logUtil("FICode notexist in List>............>>"+ficode, OperationNamesEnum.BLOCKSERVICE.code);
			DataObject Exec_Running_Totals = factory.create("http://www.sama.bea.sa/DBServices/tanfeethexec_running_totals","Exec_Running_Totals");
			Exec_Running_Totals.setString("fin_inst_cd", ficode);		
			exec_Running_Totals_lst.add(Exec_Running_Totals);
		}
		insertExecutionSummary.setList("exec_Running_Totals",exec_Running_Totals_lst);
		
		return insertExecutionSummary;
	}
	
	
	////////////////////////////////////////////////////
	
	public static DataObject getMatchedACCRecord(int accCount, DataObject ExecRunTot, DataObject acc) {
		// boolean accMatched = false;
		DataObject matchedAcc = null;
		LogUtilities.logUtil("matched Acc -------count  " + String.valueOf(accCount), OperationNamesEnum.LIFTSERVICE.code);
		for (int i = 0; i < accCount; i++) {

			DataObject execTotRecord = (DataObject) ((DataObject) ExecRunTot.getList("TanfeethExec_Running_TotalsBG").get(i)).getDataObject("TanfeethExec_Running_Totals");
			String isIban = acc.getString("IBAN");
			LogUtilities.logUtil("matched Acc -------isIban  " + String.valueOf(isIban), OperationNamesEnum.LIFTSERVICE.code);

			if (isIban.equals("y")) {
				if (execTotRecord.getString("iban")!=null&&execTotRecord.getString("iban").equals(acc.getString("Num")) && execTotRecord.getString("fin_inst_cd").equals(acc.getString("BIC"))) {
					LogUtilities.logUtil("matched Acc -------y  ", OperationNamesEnum.LIFTSERVICE.code);

					matchedAcc = execTotRecord;
					// accMatched=true;
					break;
				}
			} else

			{
				LogUtilities.logUtil("matched Acc -------n  ", OperationNamesEnum.LIFTSERVICE.code);

				if (execTotRecord.getString("acc_num") != null && execTotRecord.getString("acc_num").equals(acc.getString("Num")) && execTotRecord.getString("fin_inst_cd").equals(acc.getString("BIC"))) {
					// accMatched=true;

					LogUtilities.logUtil("matched Acc -------n  ", OperationNamesEnum.LIFTSERVICE.code);

					matchedAcc = execTotRecord;
					LogUtilities.logObject("InsideUtils--------------matched record", matchedAcc, OperationNamesEnum.LIFTSERVICE.code);

					break;

				}

			}
		}
		return matchedAcc;
	}

	public static DataObject getMatchedDepotRecord(int accCount, DataObject ExecRunTot, DataObject depot) {
		// boolean accMatched = false;
		DataObject matchedDepot = null;

		for (int i = 0; i < accCount; i++) {

			DataObject execTotRecord = (DataObject) ((DataObject) ExecRunTot.getList("TanfeethExec_Running_TotalsBG").get(i)).get("TanfeethExec_Running_Totals");
			if (execTotRecord.getString("depot_num")!=null&& execTotRecord.getString("depot_num").equals(depot.getString("Num")) && execTotRecord.getString("fin_inst_cd").equals(depot.getString("BIC"))) {

				matchedDepot = execTotRecord;
				// accMatched=true;
				break;
			}

		}
		return matchedDepot;
	}

	/*
	 * Lift is two types: Partial , and Full
	 * Partial lift: is done on account , deposit
	 * Full lift: is done on account, involved party
	 * */
	public static ValidateRPLiftOut validateRPLift(DataObject execPlan, DataObject ExecRunTot, String lftType, DataObject errorCodeConst,String prevSrvcCode,int invPartyCount) {
		LogUtilities.logObject("TanfeethExec_Running_TotalsBG", ExecRunTot, OperationNamesEnum.LIFTSERVICE.code);
		int accCount = ExecRunTot.getList("TanfeethExec_Running_TotalsBG").size();
		LogUtilities.logObject("validateRPLift", execPlan, OperationNamesEnum.LIFTSERVICE.code);
		ValidateRPLiftOut result = new ValidateRPLiftOut();
		result.errorCode = "VALID";

		// In partial lift we check in running total the rows and validate for the account and deposit .
		if (lftType.equals("PLFT")) {
			LogUtilities.logUtil("InsideUtils--------------part", OperationNamesEnum.LIFTSERVICE.code);

			boolean isAcc = ((DataObject) execPlan.get("Part")).get("AccId") != null;
			boolean isDepot = ((DataObject) execPlan.get("Part")).get("Depot") != null;
			// in case of lift on account
			if (isAcc) {

				DataObject acc = (DataObject) ((DataObject) execPlan.get("Part")).get("AccId");
				DataObject matchedAcc = null;
				// if we have only 1 account then we cannot do partial lift on it , it must be a full lift.
				if (accCount == 1) {
					result.errorCode = errorCodeConst.getString("Plft_On_AccQry_NotAllowed");
					return result;
				} else {
					matchedAcc = getMatchedACCRecord(accCount, ExecRunTot, acc);
					result.matchedRecord = matchedAcc;
					// after we get the matched account from all the returned account of running total
					// if we didn't found the related bank then we cannot lift on it
					// for example if we have accounts 1,2,3 and lift request is on account 4 then its a validation error.
					if (matchedAcc == null) {

						result.errorCode = errorCodeConst.getString("PliftAcc_Num_Not_Related_To_SRN");
						return result;
					} else {
						// if the status of the matched record is already lift, we cannot lift an already lifted account.
						if (matchedAcc.getString("status").equals("lft"))

							result.errorCode = errorCodeConst.getString("Acc_Plft_Before");
						return result;

					}
				}
				
				
			} 
			// Lift on Deposit case.
			// Similar validation done on account is also applied to the deposit, 
			// as the running total table has record for each account and deposit.
			else {

				DataObject depot = (DataObject) ((DataObject) execPlan.get("Part")).get("Depot");
				DataObject matcheddepot = null;
				if (accCount == 1) {

					result.errorCode = errorCodeConst.getString("Plft_On_AccQry_NotAllowed");
					return result;
				} else {
					matcheddepot = getMatchedDepotRecord(accCount, ExecRunTot, depot);
					result.matchedRecord = matcheddepot;
					if (matcheddepot == null) {

						result.errorCode = errorCodeConst.getString("Depot_Num_Not_Related_To_SRN");
						return result;
					} else {
						if (matcheddepot.getString("status").equals("lft"))

							result.errorCode = errorCodeConst.getString("Depot_Plft_Before");
						return result;

					}
				}

			}

		} 
		// in case of FULL Lift
		else {
			LogUtilities.logUtil("InsideUtils--------------full", OperationNamesEnum.LIFTSERVICE.code);

			boolean isAcc = false;
			LogUtilities.logObject("execPlan", execPlan, OperationNamesEnum.LIFTSERVICE.code);
			// check if it is with account by checking the element existence. 
			if (((DataObject) execPlan.get("Full")).getDataObject("AccId") != null) {
				LogUtilities.logUtil("InsideUtils--------------isAcc", OperationNamesEnum.LIFTSERVICE.code);

				isAcc = true;
			}

			if (isAcc) {
				/////////checkServiceCode
				// unnecessary check, because the block service will always come with invParty. 
				if(prevSrvcCode.equals(OperationNamesEnum.BLOCKSERVICE.code))
				{
					LogUtilities.logUtil("InsideUtils--------------inv accQry On Block", OperationNamesEnum.LIFTSERVICE.code);

					result.errorCode = errorCodeConst.getString("Flft_By_account_NotAllowedFor_NonAccQry");
					return result;
				}
				// in garnish case, if there were an involved party then its not an account only request
				// so we cannot full lift with account on a non account request, and return validation error.
				if(prevSrvcCode.equals(OperationNamesEnum.GARNISHSERVICE.code))
				{
					if(invPartyCount>0)
					{
					LogUtilities.logUtil("InsideUtils--------------inv accQry On Block", OperationNamesEnum.LIFTSERVICE.code);

					result.errorCode = errorCodeConst.getString("Flft_By_account_NotAllowedFor_NonAccQry");
					return result;
					}
				}
				// in case it was a garnish with account query, we have to check if it is the matched account
				DataObject acc = (DataObject) ((DataObject) execPlan.get("Full")).get("AccId");
				DataObject matchedAcc = null;
				if (accCount != 1) {

					LogUtilities.logUtil("InsideUtils--------------inv count", OperationNamesEnum.LIFTSERVICE.code);

					result.errorCode = errorCodeConst.getString("Flft_By_account_NotAllowedFor_NonAccQry");
					return result;
				} else {
					LogUtilities.logUtil("InsideUtils--------------matched record", OperationNamesEnum.LIFTSERVICE.code);

					matchedAcc = getMatchedACCRecord(accCount, ExecRunTot, acc);
					LogUtilities.logObject("InsideUtils--------------matched record", matchedAcc, OperationNamesEnum.LIFTSERVICE.code);

					result.matchedRecord = matchedAcc;
					if (matchedAcc == null) {

						result.errorCode = errorCodeConst.getString("Acc_Num_Not_Related_To_SRN");
						return result;
					} 
					// if it was the matched account, we check its status not already lifted.
					else {
						if (matchedAcc.getString("status").equals("lft"))

							result.errorCode = "acc_lifted";
						return result;

					}
				}
			}
		}
		result.errorCode = "VALID";
		return result;
	}

	public static DataObject validateCallbackLiftDetails(DataObject ValidateFILiftCallbackRq, DataObject fi_lift_summary_validation, DataObject callBackErrorCodeConst, DataObject validateFICallbackRs) {

		if (ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo") == null) {
			validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("EmptyTransferList"));
			return validateFICallbackRs;
		} else {
			if (ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getList("XfersList") == null) {
				validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("EmptyTransferList"));
				return validateFICallbackRs;
			} else if (ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("XfersList").getList("XferInfo").size() == 0) {
				validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("EmptyTransferList"));
				return validateFICallbackRs;
			} else {
				// check is_Acc_ID

				int totSrcAmt = 0;
				int summaryTotalAmt = Integer.parseInt(ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("SmryInfo").getString("TotAmt"));
				int PrevblockedAmt = Integer.parseInt(fi_lift_summary_validation.getString("amt_val"));
				int transerListSize = ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("XfersList").getList("XferInfo").size();
				int BlockAmt = 0;
				String blockCurr = fi_lift_summary_validation.getString("amr_cur");

				boolean AllReturnedCurrAreEqual = true;
				String blockAccNum = fi_lift_summary_validation.getString("acc_num");
				String is_iban = fi_lift_summary_validation.getString("is_iban");
				for (int i = 0; i < transerListSize; i++) {
					totSrcAmt = totSrcAmt + Integer.parseInt(((DataObject) ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("XfersList").getList("XferInfo").get(i)).getString("SrcAmt"));
					BlockAmt = BlockAmt + Integer.parseInt(((DataObject) ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("XfersList").getList("XferInfo").get(i)).getString("BlockAmt"));
					String accCurr = ((DataObject) ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("XfersList").getList("XferInfo").get(i)).getString("AccCur");

					if (blockCurr.equals(accCurr)) {
						int fxRate = ((DataObject) ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("XfersList").getList("XferInfo").get(i)).getInt("FXRate");
						if (fxRate != 1) {
							validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("InvalidFXRate"));
							return validateFICallbackRs;

						}

					} else {
						AllReturnedCurrAreEqual = false;
					}

					String accNum = ((DataObject) ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("XfersList").getList("XferInfo").get(i)).getString("AccNum");
					String trns_isiban = ((DataObject) ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getDataObject("XfersList").getList("XferInfo").get(i)).getString("IBAN");

					if (is_iban.equals("0")) {
						if (!blockAccNum.equals(accNum)) {
							validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("InvalidAccNumber"));
							return validateFICallbackRs;
						}

					}
					if (is_iban.equals("1")) {

						if (!blockAccNum.equals(trns_isiban)) {
							validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("MissingIBAN"));

							return validateFICallbackRs;
						}

					}

				}

				if (fi_lift_summary_validation.getString("is_acc_id").equals("1") && ValidateFILiftCallbackRq.getDataObject("FILiftCallBackRq").getDataObject("BlockLiftInfo").getList("XfersList").size() > 1) {
					validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("InvalidNumOfTransList"));
					// check acc num
					return validateFICallbackRs;
				}

				if (AllReturnedCurrAreEqual) {
					if (fi_lift_summary_validation.getString("is_acc_id").equals("0")) {
						if (summaryTotalAmt > PrevblockedAmt) {
							validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("InvalidSummaryTotAmt"));
							return validateFICallbackRs;
						} else if (totSrcAmt > PrevblockedAmt) {
							validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("InvalidTotalSRCAmt"));
							return validateFICallbackRs;
						} else if (BlockAmt > PrevblockedAmt) {
							validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("InvalidTotalBlockedAmt"));
							return validateFICallbackRs;
						}
					} else {
						if (summaryTotalAmt != PrevblockedAmt) {
							validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("InvalidSummaryTotAmt"));
							return validateFICallbackRs;
						} else if (totSrcAmt != PrevblockedAmt) {
							validateFICallbackRs.setString("status_code", callBackErrorCodeConst.getString("InvalidTotalSRCAmt"));
							return validateFICallbackRs;
						}

					}

				}

			}
		}

		return validateFICallbackRs;
	}

	public static DataObject prepareFILiftSummaryValidation(DataObject currentExtrSrvcTask, DataObject dispatchFILiftInputRq, DataObject insertFISummaryValidation, String msgMode, Double autoLiftAmt, String isAccID, String isIBan,String acc_num,DataObject execSumDetails) {
		//LogUtilities.logObject("checkNameSpace1", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
	//	LogUtilities.logObject("checkNameSpace2", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

		DataObject fiLiftSummaryValidation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_lift_summary_validation", "Fi_Lift_Summary_Validation");

		LogUtilities.logObject("currentExtrSrvcTask", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);
		LogUtilities.logObject("dispatchFILiftInputRq", dispatchFILiftInputRq, OperationNamesEnum.LIFTSERVICE.code);
		LogUtilities.logObject("insertFISummaryValidation", insertFISummaryValidation, OperationNamesEnum.LIFTSERVICE.code);
		String id = dispatchFILiftInputRq.getDataObject("LiftInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("id");
		String idType = dispatchFILiftInputRq.getDataObject("LiftInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("idType");
		String busCode = dispatchFILiftInputRq.getDataObject("LiftInternalData").getString("BusCode");
		String isInvParty = dispatchFILiftInputRq.getDataObject("LiftInternalData").getString("isInvParty");

		//	LogUtilities.logObject("checkNameSpace3", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);
		String lftType = dispatchFILiftInputRq.getDataObject("LiftInternalData").getString("lftType");

		String invPartyType = dispatchFILiftInputRq.getDataObject("LiftInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("invPartyType");
	//	LogUtilities.logObject("checkNameSpace4", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

		if (dispatchFILiftInputRq.getDataObject("LiftInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality") != null) {
		//	LogUtilities.logObject("checkNameSpace5", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

			String nationality = dispatchFILiftInputRq.getDataObject("LiftInternalData").getDataObject("commonInternalData").getDataObject("commonInvParty").getString("nationality");
			fiLiftSummaryValidation.setString("nat_cd", nationality);
		}
		fiLiftSummaryValidation.setString("lift_type", lftType);
		fiLiftSummaryValidation.setString("msg_mode", msgMode);

		
		if (dispatchFILiftInputRq.getDataObject("RPLiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn") != null) {
			String accCurr=dispatchFILiftInputRq.getDataObject("LiftInternalData").getString("block_Currency");
					fiLiftSummaryValidation.setString("amt_cur", accCurr);
			if (autoLiftAmt != null) {
				LogUtilities.logObject("checkNameSpace7", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

				fiLiftSummaryValidation.setDouble("amt_val", autoLiftAmt.doubleValue());
				if(dispatchFILiftInputRq.getDataObject("RPLiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn").getDataObject("FundXfer").getDataObject("Benf")!=null){
					LogUtilities.logObject("checkNameSpace8", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

					String benfBic=dispatchFILiftInputRq.getDataObject("RPLiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn").getDataObject("FundXfer").getDataObject("Benf").getString("BIC");
					fiLiftSummaryValidation.setString("benfBic", benfBic);
					}

			} else if (dispatchFILiftInputRq.getDataObject("RPLiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn").getDataObject("FundXfer") != null) {
				LogUtilities.logObject("execSumDetails9", execSumDetails, OperationNamesEnum.LIFTSERVICE.code);

				
				int size=execSumDetails.getList("exec_sum_details").size();
				System.out.println("-------------- execSumDetails size in prepareFILiftSummaryValidation   -------------" + size);

				for(int k=0;k<size;k++)
				{
					if(((DataObject)execSumDetails.getList("exec_sum_details").get(k)).getString("fin_inst_cd").equals(currentExtrSrvcTask.getString("fin_inst_cd")))
					{
						LogUtilities.logObject("(DataObject)execSumDetails", (DataObject)execSumDetails.getList("exec_sum_details").get(k), OperationNamesEnum.LIFTSERVICE.code);

						if(((DataObject)execSumDetails.getList("exec_sum_details").get(k)).getString("isTrans").equals("y"))
						{
							System.out.println("-------------- XFER  -------------");
							LogUtilities.logObject("(DataObject)execSumDetails", (DataObject)execSumDetails.getList("exec_sum_details").get(k), OperationNamesEnum.LIFTSERVICE.code);

							BigDecimal amt = ((DataObject)execSumDetails.getList("exec_sum_details").get(k)).getBigDecimal("total_amt");
							fiLiftSummaryValidation.setBigDecimal("amt_val", amt);

						}
						else
						{System.out.println("-------------- XYZ  NOR  -------------");
							fiLiftSummaryValidation.setString("msg_mode", "NOR");
	
						}
						
					}
					else
					{    System.out.println("-------------- ABC  NOR  -------------");

						fiLiftSummaryValidation.setString("msg_mode", "NOR");

					}
				}
				//double amt = dispatchFILiftInputRq.getDataObject("RPLiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn").getDataObject("FundXfer").getDouble("Amt");
				//LogUtilities.logObject("checkNameSpace10", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

				if(dispatchFILiftInputRq.getDataObject("RPLiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn").getDataObject("FundXfer").getDataObject("Benf")!=null){
//					LogUtilities.logObject("checkNameSpace11", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

					String benfBic=dispatchFILiftInputRq.getDataObject("RPLiftRq").getDataObject("Outline").getDataObject("BlockLiftCndtn").getDataObject("FundXfer").getDataObject("Benf").getString("BIC");
				fiLiftSummaryValidation.setString("benfBic", benfBic);
				}
				
			}
		}

		fiLiftSummaryValidation.setString("msg_uid", currentExtrSrvcTask.getString("exetr_ref_no"));
		fiLiftSummaryValidation.setString("fi_code", currentExtrSrvcTask.getString("fin_inst_cd"));
		fiLiftSummaryValidation.setString("trans_date", KeysUtil.getCurrentDateTimeFormatted("yyyy-MM-dd HH:mm:ss"));
	
		fiLiftSummaryValidation.setString("acc_num", acc_num);

		fiLiftSummaryValidation.setString("is_acc_id", isAccID);
		fiLiftSummaryValidation.setString("is_iban", isIBan);

		
		LogUtilities.logObject("bbbinsertFISummaryValidation", insertFISummaryValidation, OperationNamesEnum.LIFTSERVICE.code);
		fiLiftSummaryValidation.setString("busCode", busCode);

		fiLiftSummaryValidation.setString("involved_party_id", id);
		fiLiftSummaryValidation.setString("involved_party_id_type", idType);
		fiLiftSummaryValidation.setString("INVOLVED_PARTY_TYPE", invPartyType);
		LogUtilities.logObject("checkNameSpace12", currentExtrSrvcTask, OperationNamesEnum.LIFTSERVICE.code);

if(currentExtrSrvcTask.getDataObject("accQry")!=null&&currentExtrSrvcTask.getDataObject("accQry").getString("AccNum")!=null){
		fiLiftSummaryValidation.setString("acc_num", currentExtrSrvcTask.getDataObject("accQry").getString("AccNum"));
		fiLiftSummaryValidation.setString("is_iban", currentExtrSrvcTask.getDataObject("accQry").getString("IS_IBAN"));
		fiLiftSummaryValidation.setString("is_acc_id", "y");

		LogUtilities.logObject("fffinsertFISummaryValidation", insertFISummaryValidation, OperationNamesEnum.LIFTSERVICE.code);
}
	
				fiLiftSummaryValidation.setString("is_involved_party", isInvParty);

	
		// append to list
		if (insertFISummaryValidation == null) {
			insertFISummaryValidation = factory.create("http://BEA_Solution_Lift_Module/ProcessLib/DispatchFIInput", "InsertFISummaryValidation");
			List lst = new ArrayList();
			lst.add(fiLiftSummaryValidation);
			insertFISummaryValidation.setList("fi_Lift_Summary_Validation", lst);
		} else {
			insertFISummaryValidation.getList("fi_Lift_Summary_Validation").add(fiLiftSummaryValidation);
		}

		return insertFISummaryValidation;
	}

	public static DataObject retrievExecSum(String xmlInput) {
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject fi_lift_summary_validation = factory.create("http://www.sama.bea.sa/DBServices/tanfeethfi_lift_summary_validation", "Fi_Lift_Summary_Validation");

		try {
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xmlInput));
			Document doc = db.parse(is);
			NodeList nodes = doc.getElementsByTagName("Fi_Lift_Summary_Validation");

			Element element = (Element) nodes.item(0);

			NodeList fi_lift_summary_validation_id = element.getElementsByTagName("fi_lift_summary_validation_id");
			if (fi_lift_summary_validation_id != null) {
				Element fi_lift_summary_validation_idValue = (Element) fi_lift_summary_validation_id.item(0);
				fi_lift_summary_validation.setString("fi_lift_summary_validation_id", getCharacterDataFromElement(fi_lift_summary_validation_idValue));
			}

			NodeList msg_uid = element.getElementsByTagName("msg_uid");
			if (msg_uid != null) {
				Element msg_uidValue = (Element) msg_uid.item(0);
				fi_lift_summary_validation.setString("msg_uid", getCharacterDataFromElement(msg_uidValue));
			}

			NodeList msg_mode = element.getElementsByTagName("msg_mode");
			if (msg_mode != null) {
				Element msg_modeValue = (Element) msg_mode.item(0);
				fi_lift_summary_validation.setString("msg_mode", getCharacterDataFromElement(msg_modeValue));
			}

			NodeList fi_code = element.getElementsByTagName("fi_code");
			if (fi_code != null) {
				Element fi_codeValue = (Element) fi_code.item(0);
				fi_lift_summary_validation.setString("fi_code", getCharacterDataFromElement(fi_codeValue));

			}

			NodeList trans_date = element.getElementsByTagName("trans_date");
			if (trans_date != null) {
				Element trans_dateValue = (Element) trans_date.item(0);
				fi_lift_summary_validation.setString("trans_date", getCharacterDataFromElement(trans_dateValue));

			}

			NodeList is_involved_party = element.getElementsByTagName("is_involved_party");
			if (is_involved_party != null) {
				Element is_involved_partyValue = (Element) is_involved_party.item(0);
				fi_lift_summary_validation.setString("is_involved_party", getCharacterDataFromElement(is_involved_partyValue));
			}

			NodeList is_acc_id = element.getElementsByTagName("is_acc_id");
			if (is_acc_id != null) {
				Element is_acc_idValue = (Element) is_acc_id.item(0);
				fi_lift_summary_validation.setString("is_acc_id", getCharacterDataFromElement(is_acc_idValue));
			}

			NodeList involved_party_id = element.getElementsByTagName("involved_party_id");
			if (involved_party_id != null) {
				Element involved_party_idValue = (Element) involved_party_id.item(0);
				fi_lift_summary_validation.setString("involved_party_id", getCharacterDataFromElement(involved_party_idValue));

			}

			NodeList involved_party_id_type = element.getElementsByTagName("involved_party_id_type");

			if (involved_party_id_type != null) {
				Element involved_party_id_typeValue = (Element) involved_party_id_type.item(0);
				fi_lift_summary_validation.setString("involved_party_id_type", getCharacterDataFromElement(involved_party_id_typeValue));
			}

			NodeList nat_cd = element.getElementsByTagName("nat_cd");
			if (nat_cd != null) {
				Element nat_cdValue = (Element) nat_cd.item(0);
				fi_lift_summary_validation.setString("nat_cd", getCharacterDataFromElement(nat_cdValue));
			}

			NodeList amt_val = element.getElementsByTagName("amt_val");
			if (amt_val != null) {
				Element amt_valValue = (Element) amt_val.item(0);

				fi_lift_summary_validation.setString("amt_val", getCharacterDataFromElement(amt_valValue));

			}// acc_num
			NodeList amr_cur = element.getElementsByTagName("amr_cur");
			if (amr_cur != null) {
				Element amr_curValue = (Element) amr_cur.item(0);
				fi_lift_summary_validation.setString("amr_cur", getCharacterDataFromElement(amr_curValue));

			}

			NodeList acc_num = element.getElementsByTagName("acc_num");
			if (acc_num != null) {
				Element acc_numValue = (Element) acc_num.item(0);
				fi_lift_summary_validation.setString("acc_num", getCharacterDataFromElement(acc_numValue));

			}

			NodeList is_iban = element.getElementsByTagName("is_iban");
			if (is_iban != null) {
				Element is_ibanValue = (Element) is_iban.item(0);
				fi_lift_summary_validation.setString("is_iban", getCharacterDataFromElement(is_ibanValue));

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
			;
		}

		return fi_lift_summary_validation;

	}

	public static List prepareOverrideActions(BigDecimal targetAmt,BigDecimal blockedTotAmt,List actionDataLst,List fiCodeSmryLst, String opCode){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		BigDecimal pendingAmt = targetAmt.subtract(blockedTotAmt);
		for(int i=0;i<actionDataLst.size();i++){
			DataObject FICodeSmry = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FICodeSmry");
			DataObject response = (DataObject)actionDataLst.get(i);
			FICodeSmry.setString("FICODE", response.getDataObject("rqHdr").getString("PID"));
			FICodeSmry.setBigDecimal("ActionAmt",pendingAmt);
			FICodeSmry.setString("Action", BlockModeConst.OVERRIDE.code);
			FICodeSmry.setString("MsgUID",response.getDataObject("rqHdr").getString("CRN"));
			if(opCode.equals(OperationNamesEnum.GARNISHSERVICE.code)){
				FICodeSmry.setDataObject("SmryInfo",response.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo"));
			}else if(opCode.equals(OperationNamesEnum.BLOCKSERVICE.code)){
				FICodeSmry.setDataObject("SmryInfo",response.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo"));
			}
			fiCodeSmryLst.add(FICodeSmry);
		}
		return fiCodeSmryLst;
	}
	
	public static boolean checkExistFICodeSmry(List fiCodeSmryLst,DataObject FICodeSmry){
		boolean result = false;
		for(int i=0;i<fiCodeSmryLst.size();i++){
			if(((DataObject)fiCodeSmryLst.get(i)).getString("FICODE").equals(FICodeSmry.getString("FICODE"))){
				result = true;
				break;
			}
		}
		
		return result;
	}
	
	public static List prepareReverseActions(BigDecimal targetAmt,BigDecimal blockedTotAmt,List noActionDataLst,List noActionNoDataLst,List fiCodeSmryLst){
		String blockCode=OperationNamesEnum.BLOCKSERVICE.code;
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		for(int i=0;i<noActionDataLst.size();i++){
			DataObject FICodeSmry = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FICodeSmry");
			DataObject response = (DataObject)noActionDataLst.get(i);
			FICodeSmry.setString("FICODE", response.getDataObject("rqHdr").getString("PID"));
			FICodeSmry.setString("Action", BlockModeConst.REVERSE.code);
			FICodeSmry.setString("MsgUID",response.getDataObject("rqHdr").getString("CRN"));
			LogUtilities.logObject("FICodeSmry",FICodeSmry, blockCode);
			fiCodeSmryLst.add(FICodeSmry);
		}
//		LogUtilities.logUtil("noActionNoDataLst()>>"+noActionNoDataLst.size(), blockCode);
		for(int i=0;i<noActionNoDataLst.size();i++){
			DataObject FICodeSmry = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FICodeSmry");
			DataObject response = (DataObject)noActionNoDataLst.get(i);
			if(response.getDataObject("rqHdr")!=null){
				FICodeSmry.setString("FICODE", response.getDataObject("rqHdr").getString("PID"));
				FICodeSmry.setString("MsgUID",response.getDataObject("rqHdr").getString("CRN"));
			}
			else{
				FICodeSmry.setString("FICODE", response.getDataObject("rsHdr").getString("PID"));
				FICodeSmry.setString("MsgUID",response.getDataObject("rsHdr").getString("CRN"));
			}
			FICodeSmry.setString("Action", BlockModeConst.REVERSE.code);
			LogUtilities.logObject("FICodeSmry",FICodeSmry, blockCode);
			if(checkExistFICodeSmry(fiCodeSmryLst,FICodeSmry)==false){
				fiCodeSmryLst.add(FICodeSmry);
			}
		}
		return fiCodeSmryLst;
	}
	
	public static List prepareTransferActions(BigDecimal targetAmt,List<FIAmtBO> fiAmtLst,List fiCodeSmryLst,String targetCurrency){
		String blockCode=OperationNamesEnum.BLOCKSERVICE.code;
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		System.out.println("transfeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeer");

		boolean completedAmt = false;
		BigDecimal transferAmt = targetAmt;
		boolean frstRound = true;
		
		for (int i = 0; i < fiAmtLst.size(); i++) {
			System.out.println("fiAmtLst.size()>>"+fiAmtLst.size());
			System.out.println("fiAmtLst.get(i).getFiCode()"+fiAmtLst.get(i).getFiCode()+">>>i>>>>>>>>>>>>>>>>>>"+i);
			DataObject FICodeSmry = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FICodeSmry");
			FICodeSmry.setString("FICODE", fiAmtLst.get(i).getFiCode());
			 System.out.println("transferAmt>>"+transferAmt);
			 System.out.println("completedAmt>>"+completedAmt);
//			 if (transferAmt.compareTo(new BigDecimal(0)) == 0){
//				 completedAmt = true;
//			 }
			if (completedAmt == false && frstRound == true) {
				System.out.println("frstRound>>"+frstRound);
				FICodeSmry.setString("Action", BlockModeConst.TRANSFER.code);
				if (transferAmt.compareTo(fiAmtLst.get(i).getTotRqCurAmt()) <= 0) {
					System.out.println("fiAmtLst.get(i).getTotRqCurAmt() sufficeient>>"+fiAmtLst.get(i).getTotRqCurAmt());
					FICodeSmry.setBigDecimal("ActionAmt", transferAmt);
					completedAmt = true;
					fiCodeSmryLst.add(FICodeSmry);
				} else if (transferAmt.compareTo(fiAmtLst.get(i).getTotRqCurAmt()) > 0 && fiAmtLst.get(i).getTotRqCurAmt().compareTo(new BigDecimal(0)) != 0) {
					FICodeSmry.setBigDecimal("ActionAmt", fiAmtLst.get(i).getTotRqCurAmt());
					fiAmtLst.get(i).setAmt(fiAmtLst.get(i).getAmt().subtract(fiAmtLst.get(i).getTotRqCurAmt()));
					System.out.println("fiAmtLst.get(i).getTotRqCurAmt() insufficeient>>"+fiAmtLst.get(i).getTotRqCurAmt());
					transferAmt = transferAmt.subtract(fiAmtLst.get(i).getTotRqCurAmt());
					fiAmtLst.get(i).setTotRqCurAmt(new BigDecimal(0));
					if(targetCurrency.equals("SAR"))
					{
						
						fiAmtLst.get(i).setTotSarAmt(new BigDecimal(0));

					}
					fiCodeSmryLst.add(FICodeSmry);
				}
			}
			else if (completedAmt == false && frstRound == false) {
				System.out.println("frstRound>>"+frstRound);
				
				if (transferAmt.compareTo(fiAmtLst.get(i).getAmt()) <=0 ) {
					System.out.println("fiAmtLst.get(i).getAmt() sufficeient>>"+fiAmtLst.get(i).getAmt());
					FICodeSmry.setBigDecimal("ActionAmt",transferAmt);
					completedAmt = true;
				} else if (transferAmt.compareTo(fiAmtLst.get(i).getAmt())> 0) {
					System.out.println("fiAmtLst.get(i).getAmt() insufficeient>>"+fiAmtLst.get(i).getAmt());
					FICodeSmry.setBigDecimal("ActionAmt",fiAmtLst.get(i).getAmt());
					transferAmt = transferAmt.subtract(fiAmtLst.get(i).getAmt());
				}
				FICodeSmry.setString("Action", BlockModeConst.TRANSFER.code);
				fiCodeSmryLst = addFICodeSmryToExisting(fiCodeSmryLst,FICodeSmry);
			}
			else {
				System.out.println("FiCode >>> Reverse>>"+fiAmtLst.get(i).getFiCode());
				FICodeSmry.setString("MsgUID", fiAmtLst.get(i).getMsgUId());
				FICodeSmry.setString("Action", BlockModeConst.REVERSE.code);
				fiCodeSmryLst = addFICodeSmryToExisting(fiCodeSmryLst,FICodeSmry);
			}
//			LogUtilities.logObject("FICodeSmry", FICodeSmry, blockCode);
			
			if ((i == fiAmtLst.size()-1) && completedAmt == false) {
				System.out.println("i == (fiAmtLst.size()-1)>>"+completedAmt);
				Collections.sort(fiAmtLst);
				System.out.println("wooooooooooooooooooooooooooooooooo");

				for(int j=0; j<fiAmtLst.size(); j++){
				//	LogUtilities.logObject("####################______$$$______##################fiCodeSmryLst" ,(DataObject) fiCodeSmryLst.get(j), OperationNamesEnum.BLOCKSERVICE.code);
			System.out.println(fiAmtLst.get(j).toString());
				}

				i = -1;
				frstRound = false;
			}
			
			
		}
		return fiCodeSmryLst;
	}
	
	private static List addFICodeSmryToExisting(List fiCodeSmryLst,DataObject FICodeSmry) {
		boolean exist = false;
		for (int i = 0; i < fiCodeSmryLst.size(); i++) {
			DataObject raw = ((DataObject) fiCodeSmryLst.get(i));
			if (raw.getString("FICODE").equals(FICodeSmry.getString("FICODE"))&& FICodeSmry.getString("Action").equals(BlockModeConst.TRANSFER.code)) {
				System.out.println("existing(Action)>>"+FICodeSmry.getString("Action"));
				System.out.println("FICodeSmry(ActionAmt)>>"+FICodeSmry.getBigDecimal("ActionAmt"));
				System.out.println("before(raw)>>"+raw.getBigDecimal("ActionAmt"));
				raw.setBigDecimal("ActionAmt",raw.getBigDecimal("ActionAmt").add(FICodeSmry.getBigDecimal("ActionAmt")));
				System.out.println("after(raw)>>"+raw.getBigDecimal("ActionAmt"));
				exist = true;
			}
			else if (raw.getString("FICODE").equals(FICodeSmry.getString("FICODE"))&& FICodeSmry.getString("Action").equals(BlockModeConst.OVERRIDE.code)) {
				System.out.println("existing(Action)>>"+FICodeSmry.getString("Action"));
				System.out.println("FICodeSmry(ActionAmt)>>"+FICodeSmry.getBigDecimal("ActionAmt"));
				System.out.println("before(raw)>>"+raw.getBigDecimal("ActionAmt"));
				raw.setBigDecimal("ActionAmt",raw.getBigDecimal("ActionAmt").add(FICodeSmry.getBigDecimal("ActionAmt")));
				System.out.println("after(raw)>>"+raw.getBigDecimal("ActionAmt"));
				exist = true;
			}
			else if (raw.getString("FICODE").equals(FICodeSmry.getString("FICODE")) && raw.getString("Action").equals(BlockModeConst.TRANSFER.code) && FICodeSmry.getString("Action").equals(BlockModeConst.REVERSE.code) && raw.getBigDecimal("ActionAmt").compareTo(new BigDecimal(0))>0) {
//				raw.setBigDecimal("ActionAmt",null);
//				raw.setString("Action", BlockModeConst.REVERSE.code);
				exist = true;
			}
//			else if (raw.getString("FICODE").equals(FICodeSmry.getString("FICODE")) && raw.getString("Action").equals(BlockModeConst.OVERRIDE.code) && FICodeSmry.getString("Action").equals(BlockModeConst.REVERSE.code) && raw.getBigDecimal("ActionAmt").compareTo(new BigDecimal(0))==0) {
			else if (raw.getString("FICODE").equals(FICodeSmry.getString("FICODE")) && raw.getString("Action").equals(BlockModeConst.OVERRIDE.code) && FICodeSmry.getString("Action").equals(BlockModeConst.REVERSE.code)) {
//				raw.setBigDecimal("ActionAmt",null);
//				raw.setString("Action", BlockModeConst.REVERSE.code);
				exist = true;
			}
		}
		if(exist ==false){
			fiCodeSmryLst.add(FICodeSmry);
		}
		return fiCodeSmryLst;
	}

	public static List prepareOverrideCrossCurencyActions(BigDecimal targetAmt,List<FIAmtBO> fiAmtLst,List fiCodeSmryLst,List noActionDataLst,List noActionNoDataLst, String opCode,String targetCurrency){
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		boolean frstRound = true;
		boolean completedAmt = false;
		BigDecimal transferAmt = targetAmt;
		System.out.println("oveeeeeeeeeeeeeeeeerideeeeeeeeeeee");

		for(int j=0; j<fiAmtLst.size(); j++){
			//	LogUtilities.logObject("####################______$$$______##################fiCodeSmryLst" ,(DataObject) fiCodeSmryLst.get(j), OperationNamesEnum.BLOCKSERVICE.code);
		System.out.println(fiAmtLst.get(j).toString());
			}
		
		
		for (int i = 0; i < fiAmtLst.size(); i++) {
			DataObject FICodeSmry = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FICodeSmry");
			FICodeSmry.setString("FICODE", fiAmtLst.get(i).getFiCode());
			LogUtilities.logUtil("transferAmt>>"+transferAmt+"fiAmtLst.get(i).getAmt()>>"+fiAmtLst.get(i).getAmt(), opCode);
			LogUtilities.logUtil("completedAmt>>"+completedAmt, opCode);
			if (completedAmt == false && frstRound == true) {
				System.out.println("frstRound>>"+frstRound);
				FICodeSmry.setString("MsgUID",fiAmtLst.get(i).getMsgUId());
				FICodeSmry.setString("Action", BlockModeConst.OVERRIDE.code);
//				if(opCode.equals(OperationNamesEnum.GARNISHSERVICE.code)){
//					FICodeSmry.setDataObject("SmryInfo",getFICodeSmryInfoGarnish(actionDataLst,fiAmtLst.get(i).getFiCode()));
//				}else{
//					FICodeSmry.setDataObject("SmryInfo",getFICodeSmryInfo(actionDataLst,fiAmtLst.get(i).getFiCode()));
//				}
				if (transferAmt.compareTo(fiAmtLst.get(i).getTotRqCurAmt()) <= 0) {
					System.out.println("fiAmtLst.get(i).getTotRqCurAmt() sufficeient frstRound>>"+fiAmtLst.get(i).getTotRqCurAmt());
					FICodeSmry.setBigDecimal("ActionAmt", transferAmt.negate());
					completedAmt = true;
					System.out.println("<<FICodeSmry>>"+FICodeSmry.getBigDecimal("ActionAmt")+"<<<FICOde>>"+fiAmtLst.get(i).getFiCode());
					fiCodeSmryLst.add(FICodeSmry);
				} else if (transferAmt.compareTo(fiAmtLst.get(i).getTotRqCurAmt()) > 0 && fiAmtLst.get(i).getTotRqCurAmt().compareTo(new BigDecimal(0)) != 0) {
					FICodeSmry.setBigDecimal("ActionAmt",fiAmtLst.get(i).getTotRqCurAmt().negate());
					fiAmtLst.get(i).setAmt(fiAmtLst.get(i).getAmt().subtract(fiAmtLst.get(i).getTotRqCurAmt()));
					
					System.out.println("fiAmtLst.get(i).getTotRqCurAmt() insufficeient frstRound>>"+fiAmtLst.get(i).getTotRqCurAmt());
					transferAmt = transferAmt.subtract(fiAmtLst.get(i).getTotRqCurAmt());
					fiAmtLst.get(i).setTotRqCurAmt(new BigDecimal(0));
					if(targetCurrency.equals("SAR"))
					{
						
						fiAmtLst.get(i).setTotSarAmt(new BigDecimal(0));

					}
					fiCodeSmryLst.add(FICodeSmry);
				}
			}
			else if (completedAmt == false && frstRound == false) {
				FICodeSmry.setString("MsgUID",fiAmtLst.get(i).getMsgUId());
				FICodeSmry.setString("Action", BlockModeConst.OVERRIDE.code);
				if (transferAmt.compareTo(fiAmtLst.get(i).getAmt()) <=0 ) {
					System.out.println("transferAmtCompare(fiAmtLst <=0 >> condition ");
					FICodeSmry.setBigDecimal("ActionAmt",transferAmt.negate());
					completedAmt = true;
				} else if (transferAmt.compareTo(fiAmtLst.get(i).getAmt())> 0) {
					System.out.println("transferAmtCompare(fiAmtLst <=0 >> else condition ");
					FICodeSmry.setBigDecimal("ActionAmt",fiAmtLst.get(i).getAmt().negate());
					transferAmt = transferAmt.subtract(fiAmtLst.get(i).getAmt());
				}
				fiCodeSmryLst = addFICodeSmryToExisting(fiCodeSmryLst,FICodeSmry);
				LogUtilities.logObject("################## FICodeSmry 22 override", FICodeSmry, OperationNamesEnum.GARNISHSERVICE.code);
			}else{
				FICodeSmry.setString("MsgUID",fiAmtLst.get(i).getMsgUId());
				FICodeSmry.setString("Action", BlockModeConst.REVERSE.code);
				fiCodeSmryLst = addFICodeSmryToExisting(fiCodeSmryLst,FICodeSmry);
				LogUtilities.logObject("################## FICodeSmry 33 reverse", FICodeSmry, OperationNamesEnum.GARNISHSERVICE.code);
			}
//			
//			for(int j=0; j<fiCodeSmryLst.size(); j++){
//				LogUtilities.logObject("####################______$$$______##################fiCodeSmryLst" ,(DataObject) fiCodeSmryLst.get(j), OperationNamesEnum.GARNISHSERVICE.code);
//			}
//			
			if ((i == fiAmtLst.size()-1) && completedAmt == false) {
				System.out.println("i == (fiAmtLst.size()-1)>>"+completedAmt);
				Collections.sort(fiAmtLst);
				System.out.println("weeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");

				for(int j=0; j<fiAmtLst.size(); j++){
					//	LogUtilities.logObject("####################______$$$______##################fiCodeSmryLst" ,(DataObject) fiCodeSmryLst.get(j), OperationNamesEnum.BLOCKSERVICE.code);
				System.out.println(fiAmtLst.get(j).toString());
					}
				i = -1;
				frstRound = false;
			}
			
		}
		
		for(int i=0;i<noActionDataLst.size();i++){
			DataObject FICodeSmry = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FICodeSmry");
			DataObject response = (DataObject)noActionDataLst.get(i);
			FICodeSmry.setString("FICODE", response.getDataObject("rqHdr").getString("PID"));
			FICodeSmry.setString("Action", BlockModeConst.REVERSE.code);
			FICodeSmry.setString("MsgUID",response.getDataObject("rqHdr").getString("CRN"));
			LogUtilities.logObject("FICodeSmry",FICodeSmry, opCode);
			fiCodeSmryLst.add(FICodeSmry);
		}
//		LogUtilities.logUtil("noActionNoDataLst()>>"+noActionNoDataLst.size(), blockCode);
		for(int i=0;i<noActionNoDataLst.size();i++){
			DataObject FICodeSmry = factory.create("http://BEA-Solution_Library/ProcessLib/Block","FICodeSmry");
			DataObject response = (DataObject)noActionNoDataLst.get(i);
			if(response.getDataObject("rqHdr")!=null){
				FICodeSmry.setString("FICODE", response.getDataObject("rqHdr").getString("PID"));
				FICodeSmry.setString("MsgUID",response.getDataObject("rqHdr").getString("CRN"));
			}
			else{
				FICodeSmry.setString("FICODE", response.getDataObject("rsHdr").getString("PID"));
				FICodeSmry.setString("MsgUID",response.getDataObject("rsHdr").getString("CRN"));
			}
			FICodeSmry.setString("Action", BlockModeConst.REVERSE.code);
//			LogUtilities.logObject("FICodeSmry",FICodeSmry, opCode);
			if(checkExistFICodeSmry(fiCodeSmryLst,FICodeSmry)==false){
				fiCodeSmryLst.add(FICodeSmry);
			}
		}
		
		return fiCodeSmryLst;
	}
	
	
	
	public static DataObject getFICodeSmryInfoGarnish(List actionDataLst,String FICode) {
		DataObject result = null;
		for(int i=0;i<actionDataLst.size();i++){
			DataObject response = (DataObject)actionDataLst.get(i);
			if(FICode.equals(response.getDataObject("rqHdr").getString("PID"))){
				result = response.getDataObject("FIGarnishCallBackRq").getDataObject("SmryInfo");
				break;
			}
		}
		return result;
	}

	public static DataObject getFICodeSmryInfo(List actionDataLst,String FICode) {
		DataObject result = null;
		for(int i=0;i<actionDataLst.size();i++){
			DataObject response = (DataObject)actionDataLst.get(i);
			if(FICode.equals(response.getDataObject("rqHdr").getString("PID"))){
				result = response.getDataObject("FIBlockCallBackRq").getDataObject("SmryInfo");
				break;
			}
		}
		return result;
	}
	
	public static Totals GetNewTotals(BigDecimal totalAmt,BigDecimal totalSar,BigDecimal totalCurr,String AccCur,String BlockCurr,BigDecimal srcAmt,BigDecimal blkAmt)
	{
		Totals result=new Totals();
		result.setTotal_amt(totalAmt);
		result.setSar_total_amt(totalSar);
		result.setRq_total_amt(totalCurr);
		if(AccCur.equals(BlockCurr)&&AccCur.equals("SAR"))
		{
			result.setTotal_amt(totalAmt.subtract(blkAmt));
			result.setSar_total_amt(totalSar.subtract( blkAmt));
			result.setRq_total_amt(totalCurr.subtract(blkAmt));
			
			
		}
		else if(AccCur.equals(BlockCurr)&&!AccCur.equals("SAR"))
		{
			
				result.setTotal_amt(totalAmt.subtract(blkAmt));
				result.setSar_total_amt(totalSar);
				result.setRq_total_amt(totalCurr.subtract(blkAmt));
					
		}
		else if(!AccCur.equals(BlockCurr)&&AccCur.equals("SAR"))
		{
			
				result.setTotal_amt(totalAmt.subtract(blkAmt));
				result.setSar_total_amt(totalSar.subtract(srcAmt));
				result.setRq_total_amt(totalCurr);
					
		}
		else if(!AccCur.equals(BlockCurr)&&!AccCur.equals("SAR"))
		{
			
				result.setTotal_amt(totalAmt.subtract(blkAmt));
				result.setSar_total_amt(totalSar);
				result.setRq_total_amt(totalCurr);
					
		}
		
		return result;
	}
	
	/* 
	 * This functions calculate the amount to be lifted from the banks
	 * getting the amounts from the running total and add them to the fiAmtLst, then sort it and loop to get the needed amount
	 * the idea is when we have multiple banks when we get the amount from one bank them we send lift with amount to this bank 
	 * and the other banks we send lift without amount.
	 */
	public static DataObject calcLiftAmounts(DataObject ExecSumDetails,BigDecimal availAmt)
	{
		LogUtilities.logObject("ExecSumDetails---inside util", ExecSumDetails, OperationNamesEnum.LIFTSERVICE.code);
		int size=ExecSumDetails.getList("exec_sum_details").size();	
		// sufficientAmount
		List<FIAmtBO> fiAmtLst = new ArrayList<FIAmtBO>();
		LogUtilities.logUtil("availAmt"+ availAmt, OperationNamesEnum.LIFTSERVICE.code);

		for(int k=0;k<size;k++){
			FIAmtBO fiAmtBO = new FIAmtBO();
			BigDecimal accAmt=((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).getBigDecimal("total_amt");
			BigDecimal accSar=((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).getBigDecimal("totalSar");
			BigDecimal accCurr=((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).getBigDecimal("totalCurr");
			LogUtilities.logUtil("BigDecimal"+ accAmt+", "+accSar +", "+accCurr, OperationNamesEnum.LIFTSERVICE.code);

			BigDecimal amtRqCur =  accCurr;

			BigDecimal amtSar =  accSar;

			BigDecimal totAmt = accAmt;
			
			LogUtilities.logUtil("BigDecimal2"+ amtRqCur+", "+amtSar +", "+totAmt, OperationNamesEnum.LIFTSERVICE.code);

			fiAmtBO.setFiCode(((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).getString("fin_inst_cd"));
			fiAmtBO.setTotRqCurAmt(amtRqCur);
			fiAmtBO.setTotSarAmt(amtSar);
			fiAmtBO.setAmt(totAmt);
			fiAmtLst.add(fiAmtBO);
		}
		Collections.sort(fiAmtLst);

		LogUtilities.logUtil("fiAmtLst"+ fiAmtLst.toString(), OperationNamesEnum.LIFTSERVICE.code);

		for(int k=0;k<size;k++){
			FIAmtBO fiAmtBO =fiAmtLst.get(k);
			BigDecimal accAmt=fiAmtBO.getAmt();
			((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).setBigDecimal("total_amt",accAmt);
			BigDecimal accSar=fiAmtBO.getTotSarAmt();
			((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).setBigDecimal("totalSar",accSar);
			BigDecimal accCurr=fiAmtBO.getTotRqCurAmt();
			((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).setBigDecimal("totalCurr",accCurr);

			((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).setString("fin_inst_cd",fiAmtBO.getFiCode());
			((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).setString("isTrans", "n");

		}
		LogUtilities.logObject("ExecSumDetails", ExecSumDetails, OperationNamesEnum.LIFTSERVICE.code);

		BigDecimal sum=new BigDecimal(0);
		for(int k=0;k<size;k++)
		{
			BigDecimal accAmt=((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).getBigDecimal("total_amt");
			LogUtilities.logUtil("accAmt----------"+ accAmt, OperationNamesEnum.LIFTSERVICE.code);

			sum=sum.add(accAmt);
			LogUtilities.logUtil("sum"+ sum, OperationNamesEnum.LIFTSERVICE.code);

			((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).setString("isTrans", "y");
			if(sum.compareTo(availAmt)>=0)
			{
				LogUtilities.logUtil("accAmt-(sum-accAmt)"+ (accAmt.subtract((sum.subtract(availAmt)))), OperationNamesEnum.LIFTSERVICE.code);

				((DataObject)ExecSumDetails.getList("exec_sum_details").get(k)).setBigDecimal("total_amt",accAmt.subtract((sum.subtract(availAmt))));
				break;
		
			}
			
		}
		LogUtilities.logObject("ExecSumDetails ---end calc", ExecSumDetails, OperationNamesEnum.LIFTSERVICE.code);

		return ExecSumDetails;
	
	}
	
	private static DataObject prepareGarnishReply(DataObject receiveFIGarnishReplyParam) {
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject reply = factory.create("http://BEA-Solution_Library/ProcessLib/Garnish","ReceiveFIGarnishReplyRq");
		reply.setDataObject("rqHdr", receiveFIGarnishReplyParam.getDataObject("rqHdr"));
		reply.setDataObject("rsHdr", receiveFIGarnishReplyParam.getDataObject("rsHdr"));
		reply.setDataObject("FIGarnishCallBackRq", receiveFIGarnishReplyParam.getDataObject("FIGarnishCallBackRq"));
		return reply;
	}
	private static DataObject prepareBlockReply(DataObject receiveFIBlockReplyParam) {
		BOFactory factory = (BOFactory) ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		DataObject reply = factory.create("http://BEA-Solution_Library/ProcessLib/Block","ReceiveFIBlockReplyRq");
		reply.setDataObject("rqHdr", receiveFIBlockReplyParam.getDataObject("rqHdr"));
		reply.setDataObject("rsHdr", receiveFIBlockReplyParam.getDataObject("rsHdr"));
		reply.setDataObject("FIBlockCallBackRq", receiveFIBlockReplyParam.getDataObject("FIBlockCallBackRq"));
		return reply;
	}
	
	private static BigDecimal getFIAmt(DataObject XferFinInfo,String FICode) {
		BigDecimal amt = new BigDecimal(0);
		if(XferFinInfo.getDataObject("FIListFinInfo") != null && XferFinInfo.getDataObject("FIListFinInfo").getList("FIFinInfo") != null){
			for(int i=0; i < XferFinInfo.getDataObject("FIListFinInfo").getList("FIFinInfo").size();i++){
				if(((DataObject)XferFinInfo.getDataObject("FIListFinInfo").getList("FIFinInfo").get(i)).getString("FICode").equals(FICode)){
					amt = ((DataObject)XferFinInfo.getDataObject("FIListFinInfo").getList("FIFinInfo").get(i)).getDataObject("Amt").getBigDecimal("Val");
					break;
				}
			}
		}
		return amt;
	}
	
	public static List<String> prepareTrasnferSuccess(String type){
//		FileUtilities fileUtilities = new FileUtilities();
		List<String> result = new ArrayList<>();
		String codes = "";
		if(type.equals("WB")){
			System.out.println("transfer.status.codes.WB>>>>>>");
			codes = FileUtilities.readPropertyValue("transfer.status.codes.WB");		
		}else{
			System.out.println("transfer.status.codes.NB>>>>>>");
			codes = FileUtilities.readPropertyValue("transfer.status.codes.NB");
		}
		String[] codesList = codes.split(",") ;
		result = Arrays.asList(codesList);		
		return result;
	}
	
	public static String convertStringToDate(String input) {

		String output = input.substring(0, 10);  // Output : 2012/01/20
		return output;
	}
}
