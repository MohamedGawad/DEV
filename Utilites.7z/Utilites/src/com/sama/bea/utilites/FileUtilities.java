package com.sama.bea.utilites;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.naming.NamingException;

import com.sama.bea.config.Config;

public class FileUtilities {

	private static String CONFIGURATION_JNDI = "tanfeethResourceProvider/configurationPath";
	private static String CONFIGURATION_KEY = "configurationPath"; 
	static Properties prop = loadProperties();

	public static String readPropertyValue(String propertyKey) {
		String value = "";

		try {
			System.out.println("inside readPropertyValue");
			value = prop.get(propertyKey).toString();
		} catch (Exception e) {
			System.out.println("ould not find Property");
			e.printStackTrace();
		}
		return value;
	}

	public static String getSystemProperty(final String key, final String def) {
		try {
			return System.getProperty(key, def);
		} catch (Throwable e) {
			System.out.println("Was not allowed to read system property \""
					+ key + "\".");
			return def;
		}
	}

	public static Properties loadProperties() {
		javax.naming.Context ic;
		Properties propLoc = new Properties();
		String config_path = "";
		try {
			Config config = new Config();
			ic = new javax.naming.InitialContext();
//			System.out.println("ic.lookup(configurationFileName) >>>> " + ic.lookup(CONFIGURATION_JNDI));
			config =  (Config) ic.lookup(CONFIGURATION_JNDI);
//			System.out.println("configurationOptionStr >>> " + CONFIGURATION_PATH);
//			System.out.println("attribute >>> " + config.getAttribute(CONFIGURATION_KEY));
			config_path =  (String) config.getAttribute(CONFIGURATION_KEY);
			System.out.println("----------------------------------------");
			FileInputStream in = new FileInputStream(config_path);
//			System.out.println("url.openStream()");
			propLoc.load(new BufferedInputStream(in));
			in.close();
			
		} catch (IOException | NamingException e) {
			System.out.println("Could not find resource: ["
					+ config_path + "].");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return propLoc;
	}

}
