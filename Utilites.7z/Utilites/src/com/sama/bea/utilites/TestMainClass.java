package com.sama.bea.utilites;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import conm.sama.bea.domains.FIAmtBO;

public class TestMainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<FIAmtBO> fiAmtLst = new ArrayList<FIAmtBO>();
		// TODO Auto-generated method stub
		FIAmtBO fiAmtBO1 = new FIAmtBO();
		fiAmtBO1.setTotRqCurAmt(new BigDecimal(1000));
		fiAmtBO1.setTotSarAmt(new BigDecimal(4000));
		fiAmtBO1.setAmt(new BigDecimal(2000));
		fiAmtLst.add(fiAmtBO1);
		
		FIAmtBO fiAmtBO2 = new FIAmtBO();
		fiAmtBO2.setTotRqCurAmt(new BigDecimal(3000));
		fiAmtBO2.setTotSarAmt(new BigDecimal(1000));
		fiAmtBO2.setAmt(new BigDecimal(3500));
		fiAmtLst.add(fiAmtBO2);
		
		FIAmtBO fiAmtBO3 = new FIAmtBO();
		fiAmtBO3.setTotRqCurAmt(new BigDecimal(1000));
		fiAmtBO3.setTotSarAmt(new BigDecimal(5000));
		fiAmtBO3.setAmt(new BigDecimal(2500));
		fiAmtLst.add(fiAmtBO3);
		
		FIAmtBO fiAmtBO4 = new FIAmtBO();
		fiAmtBO4.setTotRqCurAmt(new BigDecimal(1000));
		fiAmtBO4.setTotSarAmt(new BigDecimal(5000));
		fiAmtBO4.setAmt(new BigDecimal(3500));
		fiAmtLst.add(fiAmtBO4);
		
		Collections.sort(fiAmtLst);
		
		for (FIAmtBO fiAmtBO : fiAmtLst) {
			System.out.println(fiAmtBO);
		}
	}

}
