package com.sama.bea.utilites;

import commonj.sdo.DataObject;

public class ValidateRPLiftOut {
	public	String errorCode;
	public	DataObject matchedRecord;
}
