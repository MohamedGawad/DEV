package com.sama.bea.constant;

import java.util.HashMap;
import java.util.Map;

public enum ServiceNamesEnum {

	GENERALINQUIRY("General Inquiry","001"),
	EXECUTION("Execution","002");
	
	
	/** The operation name English. */
	public final String name; 

	
	/** The code. */
	public final String code;
	
	ServiceNamesEnum(String name,String code)
	{
		this.name =name;
		this.code = code;

	}
	/** The Constant map. */
	private static final Map<String, ServiceNamesEnum> map;
	static
	{
		map = new HashMap<String, ServiceNamesEnum>();
		for(ServiceNamesEnum v : ServiceNamesEnum.values())
		{
			map.put(v.code, v);
		}
	}

	

	public static Map<String, ServiceNamesEnum> getMap()
	{
		return map;
	}
	
	public static ServiceNamesEnum findByKey(String i)
	{
		return map.get(i);
	}
}
