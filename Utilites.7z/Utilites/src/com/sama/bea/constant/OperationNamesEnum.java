package com.sama.bea.constant;

import java.util.HashMap;
import java.util.Map;

public enum OperationNamesEnum {
	
	GETACCOUNTINFO("Get Acoount Info","001"),
	GETBALSINFO("Get Balance Info","002"),
	GETDEPOTSINFO("Get Deposits Info","003"),
	GETSAFSINFO("Get Safes Info","004"),
	GETLIABSINFO("Get Liabilities Info","005"),
	DENYSERVICE("Exec Deny","007"),
	BANSERVICE("Exec Ban","008"),
	LIFTSERVICE("Exec Lift","009"),
	BLOCKSERVICE("Exec Block","010"),
	GARNISHSERVICE("Exec Garnish","011"),
	TRANSFERSERVICE("Exec Transfer", "019"),
	COMMONSHSERVICE("Common Module","000");

	
	/** The operation name English. */
	public final String name;

	
	/** The code. */
	public final String code;
	
	OperationNamesEnum(String name,String code)
	{
		this.name =name;
		this.code = code;

	}
	/** The Constant map. */
	private static final Map<String, OperationNamesEnum> map;
	static
	{
		map = new HashMap<String, OperationNamesEnum>();
		for(OperationNamesEnum v : OperationNamesEnum.values())
		{
			map.put(v.code, v);
		}
	}

	

	public static Map<String, OperationNamesEnum> getMap()
	{
		return map;
	}
	
	public static OperationNamesEnum findByKey(String i)
	{
		return map.get(i);
	}
	

}
