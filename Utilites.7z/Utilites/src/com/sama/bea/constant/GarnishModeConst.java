package com.sama.bea.constant;



public enum GarnishModeConst {
	NORMAL("NORMAL", "NOR"),
	OVERRIDE("OVERRIDE", "OVR"),
	REVERSE("REVERSE", "REV");
	
	/** The operation name English. */
	public final String name;
	
	/** The code. */
	public final String code;

	GarnishModeConst(String name, String code) {
		this.name = name;
		this.code = code;

	}

}
