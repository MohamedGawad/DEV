package com.sama.bea.constant;

import java.util.HashMap;
import java.util.Map;

public enum MoreInfoKeysEnum {

	B2B_FI_CODES("B2B FI Codes", "B2BCODES"),
	ALL_BANK_CODES("All Banks Codes", "ALLBANKCODES"),
	BlockedAmountIncreased("Blocked Amount Increased", "BlockedAmountIncreased");

	/** The operation name English. */
	public final String name;

	/** The code. */
	public final String code;

	MoreInfoKeysEnum(String name, String code) {
		this.name = name;
		this.code = code;

	}

	/** The Constant map. */
	private static final Map<String, InvolvedPartyEnum> map;
	static {
		map = new HashMap<String, InvolvedPartyEnum>();
		for (InvolvedPartyEnum v : InvolvedPartyEnum.values()) {
			map.put(v.code, v);
		}
	}

	public static Map<String, InvolvedPartyEnum> getMap() {
		return map;
	}

	public static InvolvedPartyEnum findByKey(String i) {
		return map.get(i);
	}
	
}
