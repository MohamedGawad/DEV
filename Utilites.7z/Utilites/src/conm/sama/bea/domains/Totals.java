package conm.sama.bea.domains;

import java.math.BigDecimal;

public class Totals {

BigDecimal	total_amt;
public BigDecimal getTotal_amt() {
	return total_amt;
}
public void setTotal_amt(BigDecimal total_amt) {
	this.total_amt = total_amt;
}
public BigDecimal getSar_total_amt() {
	return sar_total_amt;
}
public void setSar_total_amt(BigDecimal sar_total_amt) {
	this.sar_total_amt = sar_total_amt;
}
public BigDecimal getRq_total_amt() {
	return rq_total_amt;
}
public void setRq_total_amt(BigDecimal rq_total_amt) {
	this.rq_total_amt = rq_total_amt;
}
BigDecimal	sar_total_amt;
BigDecimal	rq_total_amt;
	
}
