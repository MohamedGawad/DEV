package conm.sama.bea.domains;

import java.math.BigDecimal;

public class FIAmtBO implements Comparable{
	
	private String fiCode;
	
	private  BigDecimal totRqCurAmt;
	
	private BigDecimal totSarAmt;
	
	private BigDecimal amt;

	private String msgUId;

	public String getFiCode() {
		return fiCode;
	}

	public void setFiCode(String fiCode) {
		this.fiCode = fiCode;
	}


	public BigDecimal getTotSarAmt() {
		return totSarAmt;
	}

	public void setTotSarAmt(BigDecimal totSarAmt) {
		this.totSarAmt = totSarAmt;
	}
	
	public BigDecimal getTotRqCurAmt() {
		return totRqCurAmt;
	}

	public void setTotRqCurAmt(BigDecimal totRqCurAmt) {
		this.totRqCurAmt = totRqCurAmt;
	}
	
	public String getMsgUId() {
		return msgUId;
	}

	public void setMsgUId(String msgUId) {
		this.msgUId = msgUId;
	}

	public BigDecimal getAmt() {
		return amt;
	}

	public void setAmt(BigDecimal amt) {
		this.amt = amt;
	}
	
	
	

	@Override
	public String toString() {
		return "FIAmtBO [fiCode=" + fiCode + ", totRqCurAmt=" + totRqCurAmt
				+ ", totSarAmt=" + totSarAmt + ", amt=" + amt + "]";
	}

	@Override
	public int compareTo(Object compareFI) {
		int result = 0;
		BigDecimal compareAmt=((FIAmtBO)compareFI).getTotRqCurAmt();
		 result = compareAmt.compareTo(this.totRqCurAmt);
		 if(result==0){
			 compareAmt=((FIAmtBO)compareFI).getTotSarAmt();
			 result = compareAmt.compareTo( this.totSarAmt);
			 if(result==0){
				 compareAmt=((FIAmtBO)compareFI).getAmt();
				 result = compareAmt.compareTo(this.amt);
			 }
		 }
	        /* For Ascending order*/
	        return result;
	}



}
